import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import AuthOverlay from './components/AuthOverlay';
import AppShell from './components/AppShell';
import Home from './pages/Home';
import Discover from './pages/Discover';
import Rooms from './pages/Rooms';
import Diary from './pages/Diary';
import Messages from './pages/Messages';
import Profile from './pages/Profile';
import Premium from './pages/Premium';
import Settings from './pages/Settings';
import MovieDetail from './pages/MovieDetail';

export default function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', minHeight: '100vh' }}>
        <div className="spinner" />
      </div>
    );
  }

  // Not signed in -> full-screen auth overlay (matches original behavior).
  if (!user) return <AuthOverlay />;

  // Signed in -> routed app inside the sidebar/topbar shell.
  return (
    <AppShell>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/discover" element={<Discover />} />
        <Route path="/rooms" element={<Rooms />} />
        <Route path="/diary" element={<Diary />} />
        <Route path="/messages" element={<Messages />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/premium" element={<Premium />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/movie/:name" element={<MovieDetail />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AppShell>
  );
}
