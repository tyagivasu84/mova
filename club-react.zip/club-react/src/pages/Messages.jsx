// reconstructed — this page was not visible in any screenshot. Built to
// match the loading/empty-state pattern used by every other page
// (Diary, Rooms, Discover) so it's visually and structurally consistent.
import { useEffect, useState } from 'react';

export default function Messages() {
  const [threads, setThreads] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // No dedicated backend route was visible in the screenshots for chat
    // threads, so this starts empty rather than guessing an endpoint shape.
    setLoading(false);
  }, []);

  return (
    <div>
      <div className="section-head">
        <h2>Messages</h2>
        <span>Direct messages with your friends</span>
      </div>

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : threads.length ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {threads.map((t) => (
            <div key={t.id}>{t.name}</div>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">💬</div>
          <h3>No messages yet</h3>
          <p>Join a room or add friends to start a conversation.</p>
        </div>
      )}
    </div>
  );
}
