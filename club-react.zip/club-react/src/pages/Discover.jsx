import { useEffect, useState } from 'react';
import { catalogApi } from '../api/catalog';
import PosterCard from '../components/PosterCard';

export default function Discover() {
  const [platforms, setPlatforms] = useState([]);
  const [titles, setTitles] = useState([]);
  const [active, setActive] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    catalogApi.platforms().then(setPlatforms).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    const filters = active === 'All' ? undefined : { platform: active };
    catalogApi
      .titles(filters)
      .then(setTitles)
      .catch(() => setTitles([]))
      .finally(() => setLoading(false));
  }, [active]);

  const chips = ['All', ...platforms];

  return (
    <div>
      <div className="section-head">
        <h2>Discover</h2>
        <span>Browse what's trending across every service</span>
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 }}>
        {chips.map((p) => (
          <button
            key={p}
            className={active === p ? 'btn btn-primary' : 'btn btn-ghost'}
            style={{ fontSize: 12.5, padding: '8px 14px' }}
            onClick={() => setActive(p)}
          >
            {p}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : titles.length ? (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
            gap: 14,
          }}
        >
          {titles.map((t) => (
            <PosterCard key={t.title} title={t} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">🔍</div>
          <h3>Nothing here yet</h3>
          <p>No titles found on {active}. Try another service.</p>
        </div>
      )}
    </div>
  );
}
