import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { catalogApi } from '../api/catalog';
import { useToast } from '../context/ToastContext';

export default function MovieDetail() {
  const { name } = useParams();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [title, setTitle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    catalogApi
      .title(name)
      .then(setTitle)
      .catch((e) => setError(e.message || 'Title not found'))
      .finally(() => setLoading(false));
  }, [name]);

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 80 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (error || !title) {
    return (
      <div className="empty-state">
        <div className="emoji">🎬</div>
        <h3>Title not found</h3>
        <p>{error}</p>
        <button className="btn btn-primary" onClick={() => navigate('/')}>
          Back home
        </button>
      </div>
    );
  }

  return (
    <div>
      <button
        className="btn btn-ghost"
        style={{ marginBottom: 20 }}
        onClick={() => navigate(-1)}
      >
        ← Back
      </button>

      <div style={{ display: 'flex', gap: 28, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <div
          style={{
            flex: '0 0 220px',
            height: 320,
            borderRadius: 14,
            background: `linear-gradient(160deg, ${title.accent}, #181818)`,
            border: '1px solid var(--border)',
          }}
        />
        <div style={{ flex: 1, minWidth: 280 }}>
          <h1 style={{ fontFamily: 'Archivo Black', fontSize: 34, marginBottom: 10 }}>
            {title.title}
          </h1>
          <div
            style={{
              display: 'flex',
              gap: 14,
              flexWrap: 'wrap',
              color: 'var(--text-muted)',
              fontSize: 13,
              marginBottom: 18,
            }}
          >
            <span>{title.year}</span>
            <span>{title.genre}</span>
            <span>{title.runtime}</span>
            <span style={{ color: 'var(--gold)', fontWeight: 800 }}>★ {title.imdb} IMDb</span>
            <span style={{ color: '#5ad1a0', fontWeight: 800 }}>{title.tmdb} TMDB</span>
          </div>

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 22 }}>
            {(title.platforms || []).map((p) => (
              <span
                key={p}
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  padding: '5px 11px',
                  borderRadius: 100,
                  background: 'rgba(255,255,255,0.06)',
                  border: '1px solid var(--border)',
                  color: 'var(--text-muted)',
                }}
              >
                {p}
              </span>
            ))}
          </div>

          <p style={{ color: 'var(--text-muted)', lineHeight: 1.6, marginBottom: 24 }}>
            A standout {title.genre.toLowerCase()} title from {title.year}. Start a synced
            room and watch it together with friends — everyone streams from their own
            account while CLUB keeps playback in sync.
          </p>

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <button className="btn btn-primary" onClick={() => navigate('/rooms')}>
              ▶ Watch Together
            </button>
            <button
              className="btn btn-ghost"
              onClick={() => showToast(`Added ${title.title} to your watchlist`)}
            >
              + Watchlist
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
