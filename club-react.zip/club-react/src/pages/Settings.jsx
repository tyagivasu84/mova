import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

function Toggle({ label, desc, checked, onChange }) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '14px 0',
        borderBottom: '1px solid var(--border)',
      }}
    >
      <div>
        <b style={{ fontSize: 14 }}>{label}</b>
        {desc && (
          <div style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 2 }}>{desc}</div>
        )}
      </div>
      <button
        onClick={() => onChange(!checked)}
        aria-label={label}
        style={{
          width: 42,
          height: 24,
          borderRadius: 100,
          border: 'none',
          cursor: 'pointer',
          background: checked ? 'var(--green)' : 'var(--bg-raised)',
          position: 'relative',
          transition: 'background .15s',
        }}
      >
        <span
          style={{
            position: 'absolute',
            top: 3,
            left: checked ? 21 : 3,
            width: 18,
            height: 18,
            borderRadius: '50%',
            background: '#fff',
            transition: 'left .15s',
          }}
        />
      </button>
    </div>
  );
}

export default function Settings() {
  const { logout } = useAuth();
  const { showToast } = useToast();
  const [privateProfile, setPrivateProfile] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [dmOnlyFriends, setDmOnlyFriends] = useState(true);

  return (
    <div style={{ maxWidth: 560 }}>
      <div className="section-head">
        <h2>Settings</h2>
        <span>Privacy, safety &amp; preferences</span>
      </div>

      <h3 style={{ fontSize: 14, margin: '18px 0 4px', color: 'var(--text-muted)' }}>
        Privacy
      </h3>
      <Toggle
        label="Private profile"
        desc="Only approved followers can see your activity."
        checked={privateProfile}
        onChange={(v) => {
          setPrivateProfile(v);
          showToast(v ? 'Profile is now private' : 'Profile is now public');
        }}
      />
      <Toggle
        label="Only friends can DM me"
        desc="Limit who can start a conversation with you."
        checked={dmOnlyFriends}
        onChange={setDmOnlyFriends}
      />

      <h3 style={{ fontSize: 14, margin: '26px 0 4px', color: 'var(--text-muted)' }}>
        Accessibility
      </h3>
      <Toggle
        label="Reduce motion"
        desc="Minimize animations across the app."
        checked={reduceMotion}
        onChange={(v) => {
          setReduceMotion(v);
          showToast(v ? 'Reduced motion on' : 'Reduced motion off');
        }}
      />

      <h3 style={{ fontSize: 14, margin: '26px 0 10px', color: 'var(--text-muted)' }}>
        Account
      </h3>
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <button className="btn btn-ghost" onClick={() => logout().then(() => showToast('Logged out'))}>
          ↪ Log out
        </button>
        <button
          className="btn btn-ghost"
          style={{ color: '#ff6b6b', borderColor: '#5a2020' }}
          onClick={() =>
            showToast('Account deletion requested — check your email to confirm')
          }
        >
          Delete account
        </button>
      </div>
    </div>
  );
}
