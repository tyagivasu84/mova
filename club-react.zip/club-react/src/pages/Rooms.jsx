import { useEffect, useState } from 'react';
import { catalogApi } from '../api/catalog';
import RoomCard from '../components/RoomCard';

const FILTERS = [
  { label: 'All rooms', value: undefined },
  { label: 'Watch', value: 'watch' },
  { label: 'Play', value: 'game' },
];

export default function Rooms() {
  const [rooms, setRooms] = useState([]);
  const [type, setType] = useState(undefined);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    catalogApi
      .rooms(type ? { type } : undefined)
      .then(setRooms)
      .catch(() => setRooms([]))
      .finally(() => setLoading(false));
  }, [type]);

  return (
    <div>
      <div className="section-head">
        <h2>Live rooms</h2>
        <span>Jump into a synced watch party or game lobby</span>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        {FILTERS.map((f) => (
          <button
            key={f.label}
            className={type === f.value ? 'btn btn-primary' : 'btn btn-ghost'}
            style={{ fontSize: 12.5, padding: '8px 14px' }}
            onClick={() => setType(f.value)}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : rooms.length ? (
        <div className="rooms-grid">
          {rooms.map((r) => (
            <RoomCard key={r.id} room={r} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">🛋️</div>
          <h3>No live rooms right now</h3>
          <p>Be the first — host a room and invite friends to watch together.</p>
        </div>
      )}
    </div>
  );
}
