import { useEffect, useState } from 'react';
import { catalogApi } from '../api/catalog';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';

const PLANS = [
  {
    id: 'free',
    name: 'Free',
    price: '₹0',
    period: '',
    perks: ['Join public rooms', 'Basic diary & watchlist', 'Daily streak rewards'],
    highlight: false,
  },
  {
    id: 'premium',
    name: 'Premium',
    price: '₹199',
    period: '/mo',
    perks: ['Host unlimited rooms', 'Voice + video calls', 'Priority queue skip', 'Custom theme'],
    highlight: true,
  },
  {
    id: 'director',
    name: 'Director',
    price: '₹1,499',
    period: '/yr',
    perks: ['Everything in Premium', 'Verified badge', 'Room boosts included', 'Early feature access'],
    highlight: false,
  },
];

export default function Premium() {
  const { points, shopOwned, redeemShopItem, addPoints } = useAppState();
  const { showToast } = useToast();
  const [shop, setShop] = useState([]);
  const [busyId, setBusyId] = useState(null);
  const [currentPlan, setCurrentPlan] = useState('free');

  useEffect(() => {
    catalogApi.shop().then(setShop).catch(() => {});
  }, []);

  async function handleRedeem(item) {
    setBusyId(item.id);
    try {
      await redeemShopItem(item.id);
      showToast(`Redeemed ${item.name} 🎁`);
    } catch (err) {
      showToast(err.message || 'Could not redeem');
    } finally {
      setBusyId(null);
    }
  }

  async function handleBuyPoints(amount) {
    try {
      await addPoints(amount);
      showToast(`+${amount.toLocaleString()} pts added`);
    } catch (err) {
      showToast(err.message || 'Could not add points');
    }
  }

  return (
    <div>
      <div className="section-head">
        <h2>Premium</h2>
        <span>★ {points.toLocaleString()} pts available</span>
      </div>

      {/* Plans */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
          gap: 20,
          maxWidth: 1040,
          marginBottom: 40,
        }}
      >
        {PLANS.map((plan) => {
          const isCurrent = currentPlan === plan.id;
          return (
            <div
              key={plan.id}
              style={{
                position: 'relative',
                background: 'var(--bg-card)',
                border: plan.highlight ? '2px solid var(--red)' : '1px solid var(--border)',
                borderRadius: 16,
                padding: '30px 26px',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              <h3 style={{ fontSize: 18, marginBottom: 6 }}>{plan.name}</h3>
              <div style={{ marginBottom: 18 }}>
                <span style={{ fontFamily: 'Archivo Black', fontSize: 30 }}>{plan.price}</span>
                <span style={{ color: 'var(--text-dim)', fontSize: 13 }}>{plan.period}</span>
              </div>
              <ul style={{ listStyle: 'none', marginBottom: 22, flex: 1 }}>
                {plan.perks.map((perk) => (
                  <li
                    key={perk}
                    style={{ fontSize: 13, color: 'var(--text-muted)', padding: '6px 0' }}
                  >
                    ✓ {perk}
                  </li>
                ))}
              </ul>
              <button
                className={plan.highlight ? 'btn btn-primary' : 'btn btn-ghost'}
                style={{ width: '100%' }}
                disabled={isCurrent}
                onClick={() => {
                  setCurrentPlan(plan.id);
                  showToast(`Switched to ${plan.name} 🎉`);
                }}
              >
                {isCurrent ? 'Current plan' : `Choose ${plan.name}`}
              </button>
            </div>
          );
        })}
      </div>

      {/* Buy points */}
      <div className="section-head">
        <h2>Top up points</h2>
        <span>Spend on cosmetics &amp; perks below</span>
      </div>
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 40 }}>
        {[500, 1000, 2500].map((amt) => (
          <button key={amt} className="btn btn-ghost" onClick={() => handleBuyPoints(amt)}>
            + {amt.toLocaleString()} pts
          </button>
        ))}
      </div>

      {/* Points shop */}
      <div className="section-head">
        <h2>Points shop</h2>
        <span>Redeem your points</span>
      </div>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))',
          gap: 14,
        }}
      >
        {shop.map((item) => {
          const owned = shopOwned.includes(item.id);
          const canAfford = points >= item.price;
          return (
            <div
              key={item.id}
              style={{
                background: 'var(--bg-card)',
                border: '1px solid var(--border)',
                borderRadius: 12,
                padding: 16,
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 26, marginBottom: 8 }}>{item.icon}</div>
              <h4 style={{ fontSize: 13, marginBottom: 4 }}>{item.name}</h4>
              <p style={{ fontSize: 11.5, color: 'var(--text-dim)', marginBottom: 10 }}>
                {item.desc}
              </p>
              <div style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--gold)', marginBottom: 10 }}>
                ★ {item.price.toLocaleString()} pts
              </div>
              <button
                className={owned ? 'btn btn-ghost' : 'btn btn-primary'}
                style={{ width: '100%', fontSize: 12, padding: 8 }}
                disabled={owned || !canAfford || busyId === item.id}
                onClick={() => handleRedeem(item)}
              >
                {owned ? 'Owned ✓' : canAfford ? 'Redeem' : 'Not enough pts'}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
