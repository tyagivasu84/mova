import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { catalogApi } from '../api/catalog';
import { useAppState, deriveStreakView } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import PosterCard from '../components/PosterCard';
import RoomCard from '../components/RoomCard';
import styles from './Home.module.css';

// The hero showcases the week's top title. It's derived from the catalog once
// titles load (highest-rated), so it stays data-driven rather than hard-coded.
function pickHero(titles) {
  if (!titles?.length) return null;
  return [...titles].sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating))[0];
}

export default function Home() {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { streak, claimStreak } = useAppState();

  const [titles, setTitles] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [apps, setApps] = useState([]);
  const [inWatchlist, setInWatchlist] = useState(false);
  const [claiming, setClaiming] = useState(false);

  useEffect(() => {
    catalogApi.titles().then(setTitles).catch(() => {});
    catalogApi.rooms().then((r) => setRooms(r.slice(0, 6))).catch(() => {});
    catalogApi.trendingApps().then(setApps).catch(() => {});
  }, []);

  const hero = pickHero(titles);
  const view = deriveStreakView(streak);

  async function handleClaim() {
    setClaiming(true);
    try {
      const { reward, dayOfWeek } = await claimStreak();
      showToast(`+${reward} pts — day ${dayOfWeek} streak!`);
    } catch (err) {
      showToast(err.message || 'Already claimed today');
    } finally {
      setClaiming(false);
    }
  }

  return (
    <div>
      {hero && (
        <div
          className={styles.hero}
          style={{ '--ha': hero.accent || hero.a || '#5a3a1e' }}
        >
          <div className={styles.heroBg} />
          <div className={styles.heroScrim} />
          <div className={styles.heroInner}>
            <div className={styles.heroEyebrow}>
              <span className={styles.liveDot} /> Top pick this week
            </div>
            <h1>{hero.title}</h1>
            <p className={styles.heroLogline}>{hero.logline || hero.meta}</p>
            <div className={styles.heroMeta}>
              <span className={styles.rate}>★ {hero.rating}</span>
              <span>{hero.genre}</span>
              <span>{hero.year}</span>
            </div>
            <div className={styles.heroActions}>
              <button
                className="btn btn-primary"
                onClick={() => navigate(`/movie/${encodeURIComponent(hero.title)}`)}
              >
                ▶ Watch Together
              </button>
              <button
                className="btn btn-ghost"
                onClick={() => {
                  setInWatchlist((v) => !v);
                  showToast(
                    inWatchlist
                      ? `Removed ${hero.title} from watchlist`
                      : `Added ${hero.title} to watchlist`
                  );
                }}
              >
                {inWatchlist ? '✓ In Watchlist' : '+ Watchlist'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* reward strip */}
      <div className={styles.rewardStrip}>
        <div>
          <div className={styles.rsStreak}>{view.dayLabel}</div>
          <div className={styles.rsSub}>{view.sub}</div>
        </div>
        <div className={styles.rsDots}>
          {view.dots.map((d, i) => (
            <span
              key={i}
              className={`${styles.rsDot} ${d.done ? styles.rsDotDone : ''} ${
                d.today ? styles.rsDotToday : ''
              }`}
            />
          ))}
        </div>
        <button
          className="btn btn-primary"
          disabled={view.claimedToday || claiming}
          onClick={handleClaim}
        >
          {view.claimedToday ? 'Claimed' : `Claim +${view.claimReward}`}
        </button>
      </div>

      <div className="section-head">
        <h2>Trending titles</h2>
        <span>What everyone's watching right now</span>
      </div>
      <div style={{ display: 'flex', gap: 14, overflowX: 'auto', marginBottom: 40, paddingBottom: 4 }}>
        {titles.slice(0, 10).map((t) => (
          <PosterCard key={t.title} title={t} />
        ))}
      </div>

      <div className="section-head">
        <h2>Live rooms</h2>
        <span>Jump into a synced watch party</span>
      </div>
      <div className="rooms-grid" style={{ marginBottom: 40 }}>
        {rooms.map((r) => (
          <RoomCard key={r.id} room={r} />
        ))}
      </div>

      {apps.length > 0 && (
        <>
          <div className="section-head">
            <h2>Trending apps</h2>
            <span>Popular on CLUB right now</span>
          </div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {apps.map((a) => (
              <span key={a.name} className={styles.appChip}>
                {a.icon} {a.name}
              </span>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
