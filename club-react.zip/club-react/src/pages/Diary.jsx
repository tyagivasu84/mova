import { useEffect, useState } from 'react';
import { catalogApi } from '../api/catalog';

export default function Diary() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    catalogApi
      .events()
      .then(setEvents)
      .catch(() => setEvents([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="section-head">
        <h2>Diary</h2>
        <span>Your upcoming watch parties</span>
      </div>

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : events.length ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {events.map((e) => (
            <div
              key={e.id}
              style={{
                display: 'flex',
                gap: 16,
                alignItems: 'center',
                background: 'var(--bg-card)',
                border: '1px solid var(--border)',
                borderRadius: 12,
                padding: 16,
              }}
            >
              <div
                style={{
                  textAlign: 'center',
                  minWidth: 54,
                  padding: '8px 4px',
                  background: 'var(--bg-raised)',
                  borderRadius: 10,
                  border: '1px solid var(--border)',
                }}
              >
                <div style={{ fontSize: 10, color: 'var(--text-dim)' }}>{e.month}</div>
                <div style={{ fontFamily: 'Archivo Black', fontSize: 20 }}>{e.day}</div>
              </div>
              <div style={{ flex: 1 }}>
                <h3 style={{ fontSize: 15, marginBottom: 3 }}>{e.title}</h3>
                <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>{e.meta}</div>
              </div>
              <div style={{ fontSize: 11.5, color: 'var(--gold)', fontWeight: 700 }}>
                {e.countdown}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">📔</div>
          <h3>Nothing logged yet</h3>
          <p>Log your first movie or show to start building your taste profile.</p>
        </div>
      )}
    </div>
  );
}
