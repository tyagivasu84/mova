import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';

const inputStyle = {
  width: '100%',
  background: 'var(--bg-raised)',
  border: '1px solid var(--border)',
  borderRadius: 8,
  padding: '11px 14px',
  color: '#fff',
  fontSize: 13,
  margin: '4px 0 14px',
};

function Stat({ label, value }) {
  return (
    <div
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: 12,
        padding: 18,
      }}
    >
      <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--gold)' }}>{value}</div>
      <div style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 4 }}>{label}</div>
    </div>
  );
}

export default function Profile() {
  const { user, updateProfile } = useAuth();
  const { points, shopOwned } = useAppState();
  const { showToast } = useToast();

  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [username, setUsername] = useState(user?.username || '');
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    try {
      await updateProfile({ displayName, username });
      showToast('Profile updated ✓');
      setEditing(false);
    } catch (err) {
      showToast(err.message || 'Could not update profile');
    } finally {
      setSaving(false);
    }
  }

  const initial = (user?.displayName || 'U').charAt(0).toUpperCase();

  return (
    <div>
      <div
        style={{
          display: 'flex',
          gap: 22,
          alignItems: 'center',
          flexWrap: 'wrap',
          marginBottom: 32,
        }}
      >
        <div className="avatar-sm" style={{ width: 84, height: 84, fontSize: 32 }}>
          {initial}
        </div>
        <div style={{ flex: 1, minWidth: 220 }}>
          <h1 style={{ fontFamily: 'Archivo Black', fontSize: 26 }}>{user?.displayName}</h1>
          <div style={{ color: 'var(--text-dim)', fontSize: 13, marginBottom: 4 }}>
            {user?.username}
          </div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>{user?.email}</div>
        </div>
        <button className="btn btn-ghost" onClick={() => setEditing((v) => !v)}>
          {editing ? 'Cancel' : 'Edit profile'}
        </button>
      </div>

      {editing && (
        <div
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            borderRadius: 14,
            padding: 22,
            maxWidth: 420,
            marginBottom: 32,
          }}
        >
          <label style={{ fontSize: 12, color: 'var(--text-dim)' }}>Display name</label>
          <input
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            style={inputStyle}
          />
          <label style={{ fontSize: 12, color: 'var(--text-dim)' }}>Username</label>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={inputStyle}
          />
          <button
            className="btn btn-primary"
            style={{ width: '100%', marginTop: 8 }}
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? 'Saving…' : 'Save changes'}
          </button>
        </div>
      )}

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
          gap: 16,
        }}
      >
        <Stat label="Points" value={`★ ${points.toLocaleString()}`} />
        <Stat label="Items owned" value={shopOwned.length} />
        <Stat
          label="Member since"
          value={new Date(user?.createdAt || Date.now()).getFullYear()}
        />
      </div>
    </div>
  );
}
