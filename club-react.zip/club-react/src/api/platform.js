// reconstructed — maps a streaming/gaming platform name to a display color,
// used for the small dot shown next to trend tags and platform pills.
const COLORS = {
  Netflix: '#e50914',
  'Prime Video': '#00a8e1',
  'Disney+': '#113ccf',
  'HBO Max': '#8b2be2',
  Hulu: '#1ce783',
  'Apple TV+': '#a3a3a3',
  Twitch: '#9146ff',
  Steam: '#66c0f4',
  YouTube: '#ff0000',
};

export function platformDot(name) {
  return COLORS[name] || 'var(--text-dim)';
}
