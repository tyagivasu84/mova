import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import { catalogApi } from '../api/catalog';
import styles from './AppShell.module.css';

const NAV = [
  { to: '/', page: 'home', tip: 'Home', icon: (
    <path d="M3 11.5 12 4l9 7.5" />
  ) },
  { to: '/discover', page: 'discover', tip: 'Search', icon: (
    <circle cx="11" cy="11" r="6.5" />
  ) },
  { to: '/rooms', page: 'rooms', tip: 'Rooms', icon: (
    <rect x="3" y="5" width="18" height="14" rx="2" />
  ) },
  { to: '/diary', page: 'diary', tip: 'Diary', icon: (
    <path d="M5 4h11a2 2 0 0 1 2 2v14h7 12h-12z" />
  ) },
  { to: '/messages', page: 'messages', tip: 'Chat', icon: (
    <path d="M4 5h16v11h-4z" />
  ) },
  { divider: true },
  { to: '/profile', page: 'profile', tip: 'Profile', icon: (
    <g><circle cx="12" cy="8" r="3.5" /><path d="M5 20c1-4.5 6-6 7-6s6 1.5 7 6" /></g>
  ) },
  { to: '/premium', page: 'premium', tip: 'Premium', icon: (
    <path d="M12 2 15 8 21 9 16.5 13.2 17.8 19.5 12 16.3 6.2 19.5 7.5 13.2 3 9 9 8Z" />
  ) },
];

// reconstructed — the exact icon path data was cut off-frame in the
// screenshots; kept as simple recognizable glyphs (house/search/grid/
// book/chat/user/star) rather than guessing the original coordinates.
export default function AppShell({ children }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const { points } = useAppState();
  const { showToast } = useToast();

  const [bellOpen, setBellOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifs, setNotifs] = useState([]);
  const bellRef = useRef(null);
  const menuRef = useRef(null);

  const initial = (user?.displayName || 'U').charAt(0).toUpperCase();

  useEffect(() => {
    catalogApi.notifications().then(setNotifs).catch(() => {});
  }, []);

  useEffect(() => {
    function onClick(e) {
      if (bellRef.current && !bellRef.current.contains(e.target)) setBellOpen(false);
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  async function handleLogout() {
    await logout();
    showToast('Logged out');
  }

  return (
    <div className={styles.app}>
      <nav className={styles.sidebar}>
        <div className={`display ${styles.brand}`} onClick={() => navigate('/')}>
          CLUB
        </div>
        <div className={styles.navItems}>
          {NAV.map((item, i) =>
            item.divider ? (
              <div key={i} className={styles.navDivider} />
            ) : (
              <button
                key={item.to}
                className={`${styles.navBtn} ${
                  location.pathname === item.to ? styles.navBtnActive : ''
                }`}
                title={item.tip}
                onClick={() => navigate(item.to)}
              >
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8">
                  {item.icon}
                </svg>
              </button>
            )
          )}
        </div>
      </nav>

      <div className={styles.main}>
        <header className={styles.topbar}>
          <div className={styles.points}>
            <span className={styles.pointsGold}>★</span> {points.toLocaleString()}
          </div>

          <div className={styles.bellWrap} ref={bellRef}>
            <button className={styles.iconBtn} onClick={() => setBellOpen((v) => !v)}>
              🔔
              {notifs.length > 0 && <span className={styles.badge}>{notifs.length}</span>}
            </button>
            {bellOpen && (
              <div className={styles.dropdown}>
                {notifs.length ? (
                  notifs.map((n) => (
                    <div key={n.id} className={styles.notifItem}>
                      <div className={styles.notifIcon}>{n.icon || '🔔'}</div>
                      <div className={styles.notifBody}>
                        {n.text}
                        <div className={styles.notifTime}>{n.time}</div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className={styles.notifEmpty}>You're all caught up</div>
                )}
              </div>
            )}
          </div>

          <div className={styles.avatarMenuWrap} ref={menuRef}>
            <button
              className="avatar-sm"
              onClick={() => setMenuOpen((v) => !v)}
              style={{ cursor: 'pointer', border: 'none' }}
            >
              {initial}
            </button>
            {menuOpen && (
              <div className={styles.avatarDropdown}>
                <button className={styles.avatarMenuItem} onClick={() => navigate('/profile')}>
                  Profile
                </button>
                <button className={styles.avatarMenuItem} onClick={() => navigate('/settings')}>
                  Settings
                </button>
                <button
                  className={`${styles.avatarMenuItem} ${styles.danger}`}
                  onClick={handleLogout}
                >
                  Log out
                </button>
              </div>
            )}
          </div>
        </header>

        <main className={styles.content}>{children}</main>
      </div>
    </div>
  );
}
