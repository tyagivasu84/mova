import { useNavigate } from 'react-router-dom';
import { platformDot } from '../api/platform';
import styles from './cards.module.css';

// Renders a title poster. `title` shape comes from the catalog API
// (title, genre, year, rating, accent, trend?).
export default function PosterCard({ title }) {
  const navigate = useNavigate();
  const metaLine = title.meta || `${title.genre} · ${title.year}`;

  return (
    <div
      className={styles.poster}
      style={{ '--pa': title.accent || title.a }}
      onClick={() => navigate(`/movie/${encodeURIComponent(title.title)}`)}
    >
      <span className={styles.rating}>★ {title.rating}</span>
      {title.trend && (
        <div className={styles.trendTag}>
          <span
            className={styles.trendDot}
            style={{ background: platformDot(title.trend.platform) }}
          />
          {title.trend.label}
        </div>
      )}
      <div>
        <div className={styles.title}>{title.title}</div>
        <div className={styles.meta}>{metaLine}</div>
      </div>
    </div>
  );
}
