import { useToast } from '../context/ToastContext';
import styles from './cards.module.css';

// Renders a live room. `room` shape comes from the catalog API.
export default function RoomCard({ room }) {
  const { showToast } = useToast();

  return (
    <div className={styles.roomCard} data-platform={room.platform}>
      <div className={styles.roomTop}>
        <span className={styles.roomLive}>
          <span className={styles.liveDot} /> Live
        </span>
        <span className={styles.platformPill}>{room.platform}</span>
      </div>
      <h3>
        {room.title}
        {room.premium && <span className={styles.premiumTag}>★ Premium</span>}
      </h3>
      <div className={styles.roomDesc}>{room.desc}</div>
      <div className={styles.avatars}>
        {(room.avatars || []).map((a, i) => (
          <span key={i} className={a.startsWith('+') ? styles.more : ''}>
            {a}
          </span>
        ))}
      </div>
      <div className={styles.roomFooter}>
        <span className={styles.seats}>{room.seatsCurrent} watching</span>
        <button
          className={styles.joinBtn}
          onClick={() => showToast(`Joining ${room.title}…`)}
        >
          {room.permission ? 'Ask to join' : 'Join'}
        </button>
      </div>
    </div>
  );
}
