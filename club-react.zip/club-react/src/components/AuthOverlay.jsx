import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import styles from './AuthOverlay.module.css';

export default function AuthOverlay() {
  const { login, register, google } = useAuth();
  const { showToast } = useToast();

  const [tab, setTab] = useState('login'); // 'login' | 'signup'
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const isSignup = tab === 'signup';

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (isSignup && password !== confirm) {
      setError('Passwords do not match');
      return;
    }

    setBusy(true);
    try {
      if (isSignup) {
        await register({
          email,
          password,
          displayName: username || undefined,
          username: username ? `@${username}` : undefined,
        });
        showToast('Welcome to CLUB! 🎉');
      } else {
        await login({ email, password });
        showToast('Welcome back 👋');
      }
    } catch (err) {
      setError(err.message || 'Something went wrong');
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    setBusy(true);
    try {
      await google({ email, displayName: username || undefined });
      showToast('Welcome to CLUB! 🎉');
    } catch (err) {
      setError(err.message || 'Could not continue with Google');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={styles.overlay}>
      <div className={styles.card}>
        <h1 className={`display ${styles.logo}`}>CLUB</h1>
        <p className={styles.tagline}>Find your people. Watch together.</p>

        <form onSubmit={handleSubmit}>
          {isSignup && (
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          )}
          <input
            type="email"
            placeholder="Email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {isSignup && (
            <input
              type="password"
              placeholder="Confirm password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          )}
          <button
            type="submit"
            className={`btn btn-primary ${styles.submit}`}
            disabled={busy}
          >
            {busy ? 'Please wait…' : isSignup ? 'Create account' : 'Log In'}
          </button>
        </form>

        <div className={styles.error}>{error}</div>

        <div className={styles.divider}>
          <span>or</span>
        </div>

        <button className={styles.googleBtn} onClick={handleGoogle} disabled={busy}>
          <span className={styles.googleG}>G</span> Continue with Google
        </button>

        <p className={styles.switch}>
          {isSignup ? (
            <>
              Already have an account?{' '}
              <a onClick={() => setTab('login')}>Log in</a>
            </>
          ) : (
            <>
              New here? <a onClick={() => setTab('signup')}>Create an account</a>
            </>
          )}
        </p>
      </div>
    </div>
  );
}
