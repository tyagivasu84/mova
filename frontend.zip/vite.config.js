import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The frontend calls the backend at /api. In dev we proxy that to the Node
// server on :4000 so there are no CORS issues and no hard-coded host.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:4000',
        changeOrigin: true,
      },
    },
  },
});
