# CLUB — React Frontend

## Prerequisites
- The CLUB backend running on `http://localhost:4000` (see the `club-backend` project)

## Run
```bash
# 1) start the backend first (separate terminal)
cd club-backend
npm install
npm run seed      # optional demo user: rosaline@club.local / password123
npm run dev        # http://localhost:4000

# 2) start this app
cd club-react
npm install
npm run dev        # http://localhost:5173
```

Open the Vite URL and log in with the seeded account, or sign up fresh.

## How it talks to the backend

`vite.config.js` proxies `/api` → `http://localhost:4000`, so there's no CORS
setup and no hard-coded host in the code. To point at a different backend,
set `VITE_API_BASE` (see `.env.example`).

## Build for production

```bash
npm run build      # outputs to dist/
npm run preview    # serve the built app locally
```

For production, serve `dist/` behind a proxy that forwards `/api` to the backend,
or set `VITE_API_BASE` to the backend's public URL at build time.

## Notes

- The JWT is stored in `localStorage` under `club_token`.
- Streak/points rules are enforced server-side; the client only displays state
  and calls the claim/redeem endpoints.
- CLUB hosts no third-party content — the streaming/game data is catalog
  metadata only, matching the original app's disclaimers.

---
### Reconstruction note
This project was rebuilt from a set of screen-recording screenshots of the
original source, not from the original files directly. Most files below are
transcribed verbatim from what was visible. A handful of files/sections were
partially out of frame or blurry (`platform.js`, parts of `AppShell.jsx`,
`state.js`, `Messages.jsx`, and some CSS tails) — those are marked with
`// reconstructed` comments and filled in with reasonable, consistent
implementations so the app runs end-to-end.
