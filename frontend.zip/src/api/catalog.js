import { request } from './client';

function qs(params) {
  const clean = Object.fromEntries(
    Object.entries(params || {}).filter(([, v]) => v != null && v !== '')
  );
  const s = new URLSearchParams(clean).toString();
  return s ? `?${s}` : '';
}

// Mirrors the backend /api/catalog routes (static third-party data:
// streaming platforms, titles, games, rooms, shop, notifications, events).
export const catalogApi = {
  platforms() {
    return request('/catalog/platforms').then((d) => d.platforms);
  },
  titles(filters) {
    return request(`/catalog/titles${qs(filters)}`).then((d) => d.titles);
  },
  title(name) {
    return request(`/catalog/titles/${encodeURIComponent(name)}`).then((d) => d.title);
  },
  trendingApps() {
    return request('/catalog/trending-apps').then((d) => d.apps);
  },
  games() {
    return request('/catalog/games').then((d) => d.games);
  },
  rooms(filters) {
    return request(`/catalog/rooms${qs(filters)}`).then((d) => d.rooms);
  },
  room(id) {
    return request(`/catalog/rooms/${encodeURIComponent(id)}`).then((d) => d.room);
  },
  shop() {
    return request('/catalog/shop').then((d) => d.items);
  },
  notifications() {
    return request('/catalog/notifications').then((d) => d.notifications);
  },
  events() {
    return request('/catalog/events').then((d) => d.events);
  },
};
