import { request, setToken } from './client';

// Mirrors the backend /api/auth routes.
export const authApi = {
  async register({ email, password, displayName, username }) {
    const data = await request('/auth/register', {
      method: 'POST',
      body: { email, password, displayName, username },
    });
    setToken(data.token);
    return data.user;
  },

  async login({ email, password }) {
    const data = await request('/auth/login', {
      method: 'POST',
      body: { email, password },
    });
    setToken(data.token);
    return data.user;
  },

  // Mock "Continue with Google" (backend provisions/returns a user).
  async google({ email, displayName } = {}) {
    const data = await request('/auth/google', {
      method: 'POST',
      body: { email, displayName },
    });
    setToken(data.token);
    return data.user;
  },

  async me() {
    const data = await request('/auth/me', { auth: true });
    return data.user;
  },

  async updateProfile(patch) {
    const data = await request('/auth/profile', {
      method: 'PATCH',
      body: patch,
      auth: true,
    });
    return data.user;
  },

  async logout() {
    try {
      await request('/auth/logout', { method: 'POST', auth: true });
    } catch {
      /* ignore */
    }
    setToken(null);
  },
};
