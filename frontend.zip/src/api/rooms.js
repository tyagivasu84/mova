// Mock room-hosting + example-room layer. One Room primitive — no fixed
// watch/game category. Browsing real movie-watch rooms still goes through
// the real catalogApi (catalogApi.rooms/room); this module covers what has
// no backend route yet: creating/hosting a room on any topic, plus a small
// set of seeded example rooms so the list doesn't start empty.
import { mockRequest } from './mockClient';
import { readStore, writeStore } from './mock/store';
import { catalogApi } from './catalog';
import { achievementsApi } from './achievements';
import { notifApi } from './notifications';
import { MOCK_USERS, mockUser } from './mock/fixtures/users';

// Optional social-tone tag, available for any room regardless of topic —
// this describes vibe, not "what you're doing," so it isn't a category
// that forces a lane the way watch/game used to.
export const VIBES = ['Casual', 'Competitive', 'Just Chatting'];

function seedExampleRooms() {
  return [
    { id: 'rm1', title: 'Minecraft Base Build', tag: 'Minecraft', vibe: 'Casual', host: 'Ethan Cole', desc: 'Building a mega base, chill vibes.', seatsCurrent: 4, seatsMax: 8, avatars: ['E', 'D', '+2'], premium: false, permission: false, locked: false },
    { id: 'rm2', title: 'Heist Night', tag: 'GTA 5', vibe: 'Competitive', host: 'Jordan Reyes', desc: 'Running the casino heist, need 1 more.', seatsCurrent: 3, seatsMax: 4, avatars: ['J', 'M'], premium: true, permission: true, locked: false },
    { id: 'rm3', title: 'Impostor Chaos', tag: 'Among Us', vibe: 'Casual', host: 'Maya Chen', desc: 'Casual lobby, all welcome.', seatsCurrent: 7, seatsMax: 10, avatars: ['M', 'P', 'S', 'A', '+3'], premium: false, permission: false, locked: false },
    { id: 'rm4', title: 'Study for Finals', tag: 'Study Group', vibe: 'Just Chatting', host: 'Noah Kim', desc: 'Quiet coworking, cameras optional.', seatsCurrent: 5, seatsMax: 12, avatars: ['N', 'I', '+3'], premium: false, permission: false, locked: false },
    { id: 'rm5', title: 'Marigold House Finale', tag: 'Movie Night', vibe: 'Casual', host: 'Zoe Bennett', desc: 'Watching the season finale together — no spoilers in chat.', seatsCurrent: 4, seatsMax: 6, avatars: ['Z', 'H', '+2'], premium: true, permission: true, locked: false },
    { id: 'rm6', title: 'Vent About My Day', tag: null, vibe: 'Just Chatting', host: 'Hannah Fischer', desc: 'Low-key hangout, come as you are.', seatsCurrent: 2, seatsMax: 8, avatars: ['H', 'R'], premium: false, permission: false, locked: false },
  ];
}

function loadHosted() {
  return readStore('hostedRooms', () => []);
}

function loadJoinRequests() {
  return readStore('roomJoinRequests', () => []);
}

export const roomsApi = {
  create(payload) {
    const rooms = loadHosted();
    const id = `hosted-${Date.now()}`;
    const invitedUsers = (payload.invited || []).map(mockUser).filter(Boolean);
    // `visibility` (public/private/invite_only) is the richer Watch Party
    // concept; plain rooms only ever pass `private` (boolean). Both funnel
    // into the same `permission` gate RoomCard already reads.
    const visibility = payload.visibility || (payload.private ? 'private' : 'public');
    const room = {
      id,
      title: payload.title,
      tag: payload.tag || null,
      vibe: payload.vibe || null,
      host: 'You',
      desc: 'Instant room',
      seatsCurrent: 1,
      seatsMax: payload.maxParticipants || 8,
      avatars: ['You'],
      premium: false,
      permission: visibility !== 'public',
      visibility,
      locked: false,
      hostedByMe: true,
      invited: invitedUsers.map((u) => ({ id: u.id, displayName: u.displayName })),
      isWatchParty: Boolean(payload.isWatchParty),
      provider: payload.provider || null,
      // Real URL for embeddable providers (YouTube/Vimeo) only — an
      // uploaded file's local object URL only exists on the host's own
      // device and can't be persisted/serialized, so it's never stored
      // here; it's passed via navigation state at creation time instead.
      videoUrl: payload.videoUrl || null,
      description: payload.description || '',
      maxParticipants: payload.maxParticipants || null,
      enableVoice: payload.enableVoice !== false,
      enableVideo: Boolean(payload.enableVideo),
      enableChat: payload.enableChat !== false,
    };
    rooms.push(room);
    writeStore('hostedRooms', rooms);
    achievementsApi.unlock('a7');

    // Since this is a single-real-user prototype, the "host approves a
    // join request" loop is only demonstrable for rooms I host — seed one
    // simulated incoming request so it's actually exercisable from the
    // bell dropdown, instead of building a flow that can never fire.
    if (visibility === 'private') {
      const requester = MOCK_USERS[Math.floor(Math.random() * MOCK_USERS.length)];
      const reqId = `jr-${Date.now()}-in`;
      const requests = loadJoinRequests();
      requests.push({
        id: reqId,
        roomId: id,
        roomTitle: payload.title,
        direction: 'incoming',
        fromUserId: requester.id,
        status: 'pending',
        createdAt: new Date().toISOString(),
      });
      writeStore('roomJoinRequests', requests);
      notifApi.push({
        type: 'room_join_request',
        icon: '🚪',
        text: `${requester.displayName} wants to join your room "${payload.title}"`,
        meta: { requestId: reqId, roomId: id },
      });
    }

    return mockRequest(room);
  },
  get(id) {
    const hosted = loadHosted().find((r) => r.id === id);
    if (hosted) return mockRequest(hosted);
    const example = seedExampleRooms().find((r) => r.id === id);
    if (example) return mockRequest(example);
    return catalogApi.room(id);
  },
  // Lock only ever renders for hostedByMe rooms, so this only needs to
  // persist into the hostedRooms store.
  setLocked(id, locked) {
    const rooms = loadHosted();
    const idx = rooms.findIndex((r) => r.id === id);
    if (idx < 0) return mockRequest.fail('Room not found', 404);
    rooms[idx] = { ...rooms[idx], locked };
    writeStore('hostedRooms', rooms);
    return mockRequest(rooms[idx]);
  },
  // Host-only — permanently closes the room (unlike leaving, which just
  // navigates away and leaves it live/joinable for everyone else). Removes
  // it from hostedRooms so it disappears from every listing, and clears
  // any pending join requests against it.
  end(id) {
    const rooms = loadHosted();
    const idx = rooms.findIndex((r) => r.id === id);
    if (idx < 0) return mockRequest.fail('Room not found', 404);
    rooms.splice(idx, 1);
    writeStore('hostedRooms', rooms);
    const requests = loadJoinRequests().filter((r) => r.roomId !== id);
    writeStore('roomJoinRequests', requests);
    return mockRequest({ id });
  },
  // Invite friends into an already-hosted room, so hosting no longer has
  // to bundle invites up front — you can start instantly and pull people
  // in once you're actually in the room.
  invite(roomId, userIds) {
    const rooms = loadHosted();
    const idx = rooms.findIndex((r) => r.id === roomId);
    if (idx < 0) return mockRequest.fail('Room not found', 404);
    const room = rooms[idx];
    const existingIds = new Set((room.invited || []).map((u) => u.id));
    const newUsers = userIds.map(mockUser).filter((u) => u && !existingIds.has(u.id));
    if (newUsers.length) {
      const invited = [
        ...(room.invited || []),
        ...newUsers.map((u) => ({ id: u.id, displayName: u.displayName })),
      ];
      rooms[idx] = { ...room, invited };
      writeStore('hostedRooms', rooms);
    }
    return mockRequest(rooms[idx]);
  },
  // Sync read (like settingsApi.get()) so RoomCard can render the right
  // button label without an extra loading state.
  myJoinRequestStatus(roomId) {
    const req = loadJoinRequests().find(
      (r) => r.roomId === roomId && r.direction === 'outgoing'
    );
    return req ? req.status : null;
  },
  requestJoin(room) {
    const requests = loadJoinRequests();
    const existing = requests.find(
      (r) => r.roomId === room.id && r.direction === 'outgoing' && r.status === 'pending'
    );
    if (existing) return mockRequest(existing);
    const req = {
      id: `jr-${Date.now()}`,
      roomId: room.id,
      roomTitle: room.title,
      direction: 'outgoing',
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    requests.push(req);
    writeStore('roomJoinRequests', requests);
    return mockRequest(req);
  },
  approveJoinRequest(requestId) {
    const requests = loadJoinRequests();
    const idx = requests.findIndex((r) => r.id === requestId);
    if (idx < 0) return mockRequest.fail('Request not found', 404);
    requests[idx] = { ...requests[idx], status: 'approved' };
    writeStore('roomJoinRequests', requests);
    const rooms = loadHosted();
    const rIdx = rooms.findIndex((r) => r.id === requests[idx].roomId);
    if (rIdx >= 0) {
      const room = rooms[rIdx];
      rooms[rIdx] = { ...room, seatsCurrent: Math.min(room.seatsCurrent + 1, room.seatsMax ?? Infinity) };
      writeStore('hostedRooms', rooms);
    }
    return mockRequest(requests[idx]);
  },
  denyJoinRequest(requestId) {
    const requests = loadJoinRequests();
    const next = requests.map((r) => (r.id === requestId ? { ...r, status: 'denied' } : r));
    writeStore('roomJoinRequests', next);
    return mockRequest(next.find((r) => r.id === requestId));
  },
  // All locally-hosted rooms — no category filter, one Room primitive.
  hosted() {
    return mockRequest(loadHosted());
  },
  examples() {
    return mockRequest(seedExampleRooms());
  },
  // "Find a room" — joins the most-populated open (unlocked, not full)
  // room whose title/tag matches the typed text, instead of a browsing
  // flow or skill-based matchmaking algorithm.
  quickMatch(query) {
    const q = (query || '').trim().toLowerCase();
    if (!q) return mockRequest(null);
    const all = [...loadHosted(), ...seedExampleRooms()];
    const open = all.filter(
      (r) =>
        !r.locked &&
        r.seatsCurrent < (r.seatsMax ?? Infinity) &&
        (r.title.toLowerCase().includes(q) || (r.tag || '').toLowerCase().includes(q))
    );
    if (!open.length) return mockRequest(null);
    const fullest = [...open].sort((a, b) => b.seatsCurrent - a.seatsCurrent)[0];
    return mockRequest(fullest);
  },
};
