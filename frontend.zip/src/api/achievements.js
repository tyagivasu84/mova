import { mockRequest } from './mockClient';
import { readStore, writeStore } from './mock/store';

function iso(daysAgo) {
  return new Date(Date.now() - daysAgo * 86400000).toISOString();
}

const DEFINITIONS = [
  { id: 'a1', title: 'First Watch', desc: 'Joined your first room', icon: '🎬' },
  { id: 'a2', title: 'Streak Starter', desc: 'Hit a 3-day streak', icon: '🔥' },
  { id: 'a3', title: 'Streak Master', desc: 'Hit a 30-day streak', icon: '⚡' },
  { id: 'a4', title: 'Social Butterfly', desc: 'Made 5 friends', icon: '🦋' },
  { id: 'a5', title: 'Big Spender', desc: 'Redeemed 3 shop items', icon: '💎' },
  { id: 'a6', title: 'Verified', desc: 'Completed profile verification', icon: '✅' },
  { id: 'a7', title: 'Host', desc: 'Hosted your first room', icon: '🎙️' },
  { id: 'a8', title: 'Club Member', desc: 'Joined a club', icon: '🏛️' },
  { id: 'a9', title: 'Icebreaker', desc: 'Played Two Truths and a Lie', icon: '🎭' },
  { id: 'a10', title: 'Dare Devil', desc: 'Completed a Truth or Dare card', icon: '🃏' },
  { id: 'a11', title: 'No Judgment', desc: 'Finished a round of Never Have I Ever', icon: '🙈' },
  { id: 'a12', title: 'Undercover', desc: 'Finished a round of Mafia', icon: '🕵️' },
  { id: 'a13', title: 'Know-It-All', desc: 'Finished a round of Trivia', icon: '🧠' },
  { id: 'a14', title: 'Emoji Expert', desc: 'Finished a round of Emoji Charades', icon: '🎬' },
  { id: 'a15', title: 'Master of Disguise', desc: 'Finished a round of Spyfall', icon: '🕵️‍♀️' },
];

// { [id]: isoTimestamp }, seeded with two pre-unlocked as flavor — the
// rest unlock for real via achievementsApi.unlock() from the app's actual
// trigger points (verification, hosting, clubs, shop, streak, friends).
function seedUnlocks() {
  return { a1: iso(30), a2: iso(10) };
}

function loadUnlocks() {
  return readStore('achievementUnlocks', seedUnlocks);
}

export const achievementsApi = {
  list() {
    const unlocks = loadUnlocks();
    return mockRequest(
      DEFINITIONS.map((d) => ({
        ...d,
        unlocked: Boolean(unlocks[d.id]),
        unlockedAt: unlocks[d.id] || null,
      }))
    );
  },
  // Idempotent — safe to call every time the underlying condition is met.
  unlock(id) {
    const unlocks = loadUnlocks();
    if (!unlocks[id]) {
      unlocks[id] = new Date().toISOString();
      writeStore('achievementUnlocks', unlocks);
    }
    return mockRequest(unlocks[id]);
  },
};
