// Mock notification feed — extends what catalogApi.notifications() used to
// serve (read-only) with type + read state so the bell dropdown can act on
// friend requests and mark items as read.
import { mockRequest } from './mockClient';
import { readStore, writeStore } from './mock/store';

function seedNotifications() {
  return [
    {
      id: 'n1',
      type: 'friend_request',
      icon: '👋',
      text: 'Jordan Reyes sent you a friend request',
      time: '2h ago',
      read: false,
      meta: { requestId: 'fr1' },
    },
    {
      id: 'n2',
      type: 'system',
      icon: '🔥',
      text: 'Your streak is about to expire — claim today!',
      time: '5h ago',
      read: false,
    },
    {
      id: 'n3',
      type: 'room_invite',
      icon: '🎬',
      text: 'Amara invited you to Friday Horror Night',
      time: '1d ago',
      read: true,
    },
    {
      id: 'n4',
      type: 'friend_request',
      icon: '👋',
      text: 'Amara Okafor sent you a friend request',
      time: '2d ago',
      read: false,
      meta: { requestId: 'fr2' },
    },
    {
      id: 'n5',
      type: 'recommendation',
      icon: '🍿',
      text: 'Because you liked Nocturne City: try Glass Horizon',
      time: '3d ago',
      read: false,
    },
    {
      id: 'n6',
      type: 'achievement',
      icon: '🔥',
      text: 'Achievement unlocked: Streak Starter',
      time: '4d ago',
      read: true,
    },
  ];
}

function load() {
  return readStore('notifications', seedNotifications);
}

export const notifApi = {
  list() {
    return mockRequest(load());
  },
  push(partial) {
    const items = load();
    const notif = { id: `n${Date.now()}`, read: false, time: 'Just now', icon: '🔔', ...partial };
    const next = [notif, ...items];
    writeStore('notifications', next);
    return mockRequest(next);
  },
  markRead(id) {
    const items = load().map((n) => (n.id === id ? { ...n, read: true } : n));
    writeStore('notifications', items);
    return mockRequest(items);
  },
  markAllRead() {
    const items = load().map((n) => ({ ...n, read: true }));
    writeStore('notifications', items);
    return mockRequest(items);
  },
};
