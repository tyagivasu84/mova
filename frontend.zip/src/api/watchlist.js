// Sync, like settingsApi/ageProfileApi — a title's watchlist state is read
// on every render of Home's hero and MovieDetail, so both stay in sync
// with a single source of truth instead of each faking their own local
// toggle state.
import { readStore, writeStore } from './mock/store';

export const watchlistApi = {
  list() {
    return readStore('watchlist', () => []);
  },
  has(title) {
    return watchlistApi.list().includes(title);
  },
  toggle(title) {
    const list = watchlistApi.list();
    const next = list.includes(title) ? list.filter((t) => t !== title) : [...list, title];
    writeStore('watchlist', next);
    return next.includes(title);
  },
};
