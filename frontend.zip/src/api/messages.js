// Mock DM layer — Messages.jsx was previously a placeholder with no
// backend route. This covers conversations, sending, reactions, and
// per-message thread replies, all persisted to localStorage.
import { mockRequest } from './mockClient';
import { readStore, writeStore } from './mock/store';
import { mockUser } from './mock/fixtures/users';

function iso(hoursAgo) {
  return new Date(Date.now() - hoursAgo * 3600000).toISOString();
}

function seedConversations() {
  return [
    { id: 'c1', userId: 'u1', lastMessage: "omg have you seen the finale??", updatedAt: iso(1), read: false },
    { id: 'c2', userId: 'u3', lastMessage: 'Watch party this weekend?', updatedAt: iso(5), read: false },
    { id: 'c3', userId: 'u5', lastMessage: 'Sending you the invite now', updatedAt: iso(26), read: true },
  ];
}

function seedMessages() {
  return {
    c1: [
      { id: 'm1', authorId: 'u1', body: 'omg have you seen the finale??', reactions: [], replies: [], createdAt: iso(1.2) },
      { id: 'm2', authorId: 'me', body: "NOT YET no spoilers 😭", reactions: [], replies: [], createdAt: iso(1) },
    ],
    c2: [
      {
        id: 'm3',
        authorId: 'u3',
        body: 'Watch party this weekend? ||the ending destroys me though||',
        reactions: [{ emoji: '😂', userIds: ['me'] }],
        replies: [],
        createdAt: iso(5),
      },
    ],
    c3: [
      { id: 'm4', authorId: 'u5', body: 'Sending you the invite now', reactions: [], replies: [], createdAt: iso(26) },
    ],
  };
}

function loadConvos() {
  return readStore('conversations', seedConversations);
}
function loadMessages() {
  return readStore('messagesByConvo', seedMessages);
}

function hydrate(m) {
  return { ...m, author: m.authorId === 'me' ? null : mockUser(m.authorId) };
}

export const messagesApi = {
  conversations() {
    const convos = loadConvos()
      .map((c) => ({ ...c, user: mockUser(c.userId) }))
      .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    return mockRequest(convos);
  },
  messages(conversationId) {
    const all = loadMessages();
    return mockRequest((all[conversationId] || []).map(hydrate));
  },
  markRead(conversationId) {
    const convos = loadConvos();
    const idx = convos.findIndex((c) => c.id === conversationId);
    if (idx >= 0 && !convos[idx].read) {
      convos[idx] = { ...convos[idx], read: true };
      writeStore('conversations', convos);
    }
    return mockRequest(convos);
  },
  unreadCount() {
    return mockRequest(loadConvos().filter((c) => !c.read).length);
  },
  send(conversationId, body, extra = {}) {
    const all = loadMessages();
    const list = all[conversationId] || [];
    const msg = {
      id: `m${Date.now()}`,
      authorId: 'me',
      body,
      type: extra.type || 'text',
      gift: extra.gift || null,
      reactions: [],
      replies: [],
      createdAt: new Date().toISOString(),
    };
    all[conversationId] = [...list, msg];
    writeStore('messagesByConvo', all);

    const convos = loadConvos();
    const idx = convos.findIndex((c) => c.id === conversationId);
    if (idx >= 0) {
      convos[idx] = { ...convos[idx], lastMessage: body, updatedAt: msg.createdAt };
      writeStore('conversations', convos);
    }
    return mockRequest(hydrate(msg));
  },
  react(conversationId, messageId, emoji) {
    const all = loadMessages();
    const list = all[conversationId] || [];
    const next = list.map((m) => {
      if (m.id !== messageId) return m;
      const existing = m.reactions.find((r) => r.emoji === emoji);
      let reactions;
      if (existing) {
        const userIds = existing.userIds.includes('me')
          ? existing.userIds.filter((id) => id !== 'me')
          : [...existing.userIds, 'me'];
        reactions = m.reactions
          .map((r) => (r.emoji === emoji ? { ...r, userIds } : r))
          .filter((r) => r.userIds.length > 0);
      } else {
        reactions = [...m.reactions, { emoji, userIds: ['me'] }];
      }
      return { ...m, reactions };
    });
    all[conversationId] = next;
    writeStore('messagesByConvo', all);
    return mockRequest(hydrate(next.find((m) => m.id === messageId)));
  },
  reply(conversationId, messageId, body) {
    const all = loadMessages();
    const list = all[conversationId] || [];
    const reply = { id: `r${Date.now()}`, authorId: 'me', body, createdAt: new Date().toISOString() };
    const next = list.map((m) =>
      m.id === messageId ? { ...m, replies: [...m.replies, reply] } : m
    );
    all[conversationId] = next;
    writeStore('messagesByConvo', all);
    return mockRequest(hydrate(next.find((m) => m.id === messageId)));
  },
};
