// Mock counterpart to client.js's request(). New domains that don't have a
// real backend route yet call mockRequest() with the same async/throwing
// shape, so swapping in a real request('/path', opts) call later is a
// same-signature change to the xApi method body, not a rewrite.

export function mockRequest(data, { delay = 250 } = {}) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(data), delay);
  });
}

mockRequest.fail = function fail(message, status = 400, { delay = 250 } = {}) {
  return new Promise((_, reject) => {
    setTimeout(() => {
      const err = new Error(message);
      err.status = status;
      reject(err);
    }, delay);
  });
};
