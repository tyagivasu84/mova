// Taste Match — never built before, per the original spec. Mocked
// compatibility scores against the seeded user roster.
import { mockRequest } from './mockClient';
import { MOCK_USERS } from './mock/fixtures/users';

const SHARED_TITLE_POOL = [
  'Nocturne City', 'Solar Drift', 'The Long Static', 'Paper Moons',
  'Afterglow', 'Iron Season', 'Glass Horizon', 'Midnight Freight',
];

const GENRE_POOL = ['Thriller', 'Sci-Fi', 'Comedy', 'Horror', 'Drama', 'Animation', 'Romance', 'Action'];

function pick(pool, seed, n) {
  return pool.filter((_, i) => (i + seed) % 3 === 0).slice(0, n);
}

function blendProfile(genres) {
  if (genres.length < 2) return `Mostly ${genres[0] || 'Drama'}`;
  const majority = 65 - genres.length * 3;
  const minority = Math.max(100 - majority, 0);
  return `${majority}% ${genres[0]} / ${minority}% ${genres[1]}`;
}

const RESULTS = MOCK_USERS.slice(0, 8).map((u, i) => {
  const sharedGenres = pick(GENRE_POOL, i, 2 + (i % 2));
  return {
    userId: u.id,
    displayName: u.displayName,
    avatarInitial: u.avatarInitial,
    percent: 60 + ((i * 7 + 13) % 38),
    sharedTitles: pick(SHARED_TITLE_POOL, i, 3),
    sharedGenres,
    blendProfile: blendProfile(sharedGenres),
    movieAnthem: SHARED_TITLE_POOL[(i * 3 + 1) % SHARED_TITLE_POOL.length],
  };
}).sort((a, b) => b.percent - a.percent);

export const tasteMatchApi = {
  list() {
    return mockRequest(RESULTS);
  },
};
