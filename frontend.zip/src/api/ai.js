import { mockRequest } from './mockClient';

const TEMPLATES = [
  '{a} and {b} mostly talked about tonight\'s plans — nothing urgent to act on.',
  'The conversation moved from a spoiler-tagged comment to scheduling a watch party this weekend.',
  "TL;DR: a few reactions and one message you haven't replied to from {a}.",
];

export const aiApi = {
  summarize(messages) {
    const names = [...new Set(messages.map((m) => m.author?.displayName).filter(Boolean))];
    const text = TEMPLATES[messages.length % TEMPLATES.length]
      .replace('{a}', names[0] || 'the group')
      .replace('{b}', names[1] || 'everyone else');
    return mockRequest(text, { delay: 900 });
  },
};
