// Mock Clubs system — communities with roles, channels (text chat reusing
// the same message shape as DMs), voice channels, polls, events, a
// topic-based forum, and a media gallery pulled from real chat history.
import { mockRequest } from './mockClient';
import { readStore, writeStore } from './mock/store';
import { mockUser } from './mock/fixtures/users';
import { achievementsApi } from './achievements';

const EMOJI_SETS = {
  club1: ['🎬', '🍿', '👻', '🔥', '😭', '💀', '🎃', '🩸'],
  club2: ['🚀', '🤖', '👽', '⚡', '🌌', '🛸', '🧠', '🔮'],
  club3: ['😂', '🤣', '🎉', '💖', '🌈', '✨', '🥳', '🙌'],
  club4: ['🎮', '🕹️', '🏆', '💥', '🎯', '🔫', '🛡️', '⚔️'],
};

const ROLE_ORDER = ['owner', 'admin', 'mod', 'vip', 'member'];

export const CLUB_CATEGORIES = [
  'Gaming', 'Movies', 'Anime', 'Technology', 'Programming', 'Sports',
  'Music', 'Photography', 'Education', 'Business', 'Fashion', 'Travel',
  'Food', 'Lifestyle', 'Other',
];

const DEFAULT_VOICE_CHANNELS = [
  { id: 'v-general', name: 'General Voice' },
  { id: 'v-gaming', name: 'Gaming Voice' },
  { id: 'v-movie', name: 'Movie Night' },
  { id: 'v-study', name: 'Study Room' },
  { id: 'v-music', name: 'Music Lounge' },
  { id: 'v-afk', name: 'AFK' },
];

const ACCENTS = ['#5a1620', '#1e3a5f', '#1f4a3d', '#4a2f5c', '#5c4419'];

function iso(daysAgo) {
  return new Date(Date.now() - daysAgo * 86400000).toISOString();
}

function timeUntil(dateStr) {
  const diff = new Date(dateStr).getTime() - Date.now();
  if (diff <= 0) return 'Starting now';
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  if (days > 0) return `in ${days}d ${hours}h`;
  const mins = Math.floor((diff % 3600000) / 60000);
  return `in ${hours}h ${mins}m`;
}

function randomAccent() {
  return ACCENTS[Math.floor(Math.random() * ACCENTS.length)];
}

function seedClubs() {
  return [
    {
      id: 'club1',
      name: 'Horror Society',
      avatarInitial: 'H',
      description: 'For people who watch horror movies with the lights off.',
      category: 'Movies',
      accent: '#5a1620',
      verified: true,
      createdAt: iso(240),
      channels: [
        { id: 'ch1', name: 'general', type: 'text' },
        { id: 'ch2', name: 'announcements', type: 'text' },
      ],
      voiceChannels: DEFAULT_VOICE_CHANNELS,
      members: [
        { userId: 'me', role: 'member' },
        { userId: 'u1', role: 'owner' },
        { userId: 'u7', role: 'admin' },
        { userId: 'u9', role: 'mod' },
        { userId: 'u13', role: 'vip' },
        { userId: 'u3', role: 'member' },
      ],
      emojiSet: EMOJI_SETS.club1,
    },
    {
      id: 'club2',
      name: 'Sci-Fi Collective',
      avatarInitial: 'S',
      description: 'Deep dives into everything speculative fiction.',
      category: 'Movies',
      accent: '#1e3a5f',
      verified: false,
      createdAt: iso(180),
      channels: [
        { id: 'ch3', name: 'general', type: 'text' },
        { id: 'ch4', name: 'theories', type: 'text' },
      ],
      voiceChannels: DEFAULT_VOICE_CHANNELS,
      members: [
        { userId: 'u2', role: 'owner' },
        { userId: 'me', role: 'vip' },
        { userId: 'u10', role: 'mod' },
        { userId: 'u14', role: 'member' },
      ],
      emojiSet: EMOJI_SETS.club2,
    },
    {
      id: 'club3',
      name: 'Rom-Com Realm',
      avatarInitial: 'R',
      description: 'Comfort watches, happy endings, no exceptions.',
      category: 'Movies',
      accent: '#4a2f5c',
      verified: false,
      createdAt: iso(30),
      channels: [{ id: 'ch5', name: 'general', type: 'text' }],
      voiceChannels: DEFAULT_VOICE_CHANNELS,
      members: [
        { userId: 'u3', role: 'owner' },
        { userId: 'u5', role: 'admin' },
        { userId: 'u11', role: 'member' },
      ],
      emojiSet: EMOJI_SETS.club3,
    },
    {
      id: 'club4',
      name: 'Co-op Gamers',
      avatarInitial: 'G',
      description: 'Game nights, streams, and squad finding.',
      category: 'Gaming',
      accent: '#1f4a3d',
      verified: true,
      createdAt: iso(10),
      channels: [
        { id: 'ch6', name: 'general', type: 'text' },
        { id: 'ch7', name: 'lfg', type: 'text' },
      ],
      voiceChannels: DEFAULT_VOICE_CHANNELS,
      members: [
        { userId: 'u4', role: 'owner' },
        { userId: 'u12', role: 'mod' },
        { userId: 'u6', role: 'member' },
      ],
      emojiSet: EMOJI_SETS.club4,
    },
  ];
}

function seedChannelMessages() {
  return {
    ch1: [
      { id: 'cm1', authorId: 'u1', body: 'Friday pick is out — vote in #general', type: 'text', reactions: [], replies: [], createdAt: iso(1) },
      { id: 'cm2', authorId: 'u7', body: "||the third act twist is unreal|| no spoilers though", type: 'text', reactions: [{ emoji: '💀', userIds: ['u9'] }], replies: [], createdAt: iso(0.5) },
    ],
    ch3: [
      { id: 'cm3', authorId: 'u2', body: 'New theory thread up top', type: 'text', reactions: [], replies: [], createdAt: iso(2) },
    ],
  };
}

function seedPolls() {
  return {
    club1: [
      {
        id: 'poll1',
        question: "What's next for Friday Horror Night?",
        options: [
          { id: 'o1', text: 'Nocturne City', votes: ['u1', 'u7'] },
          { id: 'o2', text: 'Glass Horizon', votes: ['u9'] },
        ],
        closesAt: new Date(Date.now() + 3 * 86400000).toISOString(),
      },
    ],
  };
}

function seedEvents() {
  return {
    club1: [{ id: 'ce1', title: 'Friday Horror Night', month: 'FRI', day: 'HR', meta: '9:00 PM · Hosted by Maya', countdown: 'in 2d' }],
    club4: [{ id: 'ce2', title: 'Co-op Ranked Night', month: 'SAT', day: 'GN', meta: '8:00 PM · Hosted by Ethan', countdown: 'in 3d' }],
  };
}

function seedForum() {
  return {
    club1: [
      {
        id: 'f1',
        authorId: 'u13',
        tag: 'Theory',
        title: 'The house in Nocturne City is a metaphor',
        body: "Hear me out — every room represents a stage of grief.",
        replies: [],
        upvotes: ['u1', 'u9'],
        createdAt: iso(3),
      },
      {
        id: 'f2',
        authorId: 'u9',
        tag: 'Fan Art',
        title: 'Drew the ending scene',
        body: 'Took me way too long but worth it.',
        replies: [],
        upvotes: ['u1'],
        createdAt: iso(1),
      },
    ],
  };
}

function loadClubs() {
  return readStore('clubs', seedClubs);
}
function loadChannelMessages() {
  return readStore('clubChannelMessages', seedChannelMessages);
}
function loadPolls() {
  return readStore('clubPolls', seedPolls);
}
function loadEvents() {
  return readStore('clubEvents', seedEvents);
}
function loadForum() {
  return readStore('clubForum', seedForum);
}

// Members online right now — no real presence backend, so this is a
// stable function of member count rather than a persisted field.
function onlineCountFor(memberCount) {
  return Math.max(1, Math.round(memberCount * 0.4));
}

function levelFor(memberCount) {
  if (memberCount >= 500) return { level: 4, badge: '🥇' };
  if (memberCount >= 100) return { level: 3, badge: '🥈' };
  if (memberCount >= 50) return { level: 2, badge: '🥉' };
  return { level: 1, badge: '🌱' };
}

function hydrateClub(c) {
  const members = c.members
    .map((m) => ({ ...m, user: m.userId === 'me' ? null : mockUser(m.userId) }))
    .sort((a, b) => ROLE_ORDER.indexOf(a.role) - ROLE_ORDER.indexOf(b.role));
  const memberCount = members.length;
  const onlineCount = onlineCountFor(memberCount);
  return {
    ...c,
    members,
    memberCount,
    onlineCount,
    live: onlineCount >= 3,
    inviteCode: `club-${c.id}`.toUpperCase(),
    ...levelFor(memberCount),
    isMember: members.some((m) => m.userId === 'me'),
    myRole: members.find((m) => m.userId === 'me')?.role || null,
  };
}

function hydrateMessage(m) {
  return { ...m, author: m.authorId === 'me' ? null : mockUser(m.authorId) };
}

function hydratePost(p) {
  return {
    ...p,
    author: p.authorId === 'me' ? null : mockUser(p.authorId),
    replies: (p.replies || []).map((r) => ({ ...r, author: r.authorId === 'me' ? null : mockUser(r.authorId) })),
  };
}

export const clubsApi = {
  list() {
    return mockRequest(loadClubs().map(hydrateClub));
  },
  get(id) {
    const club = loadClubs().find((c) => c.id === id);
    return club ? mockRequest(hydrateClub(club)) : mockRequest.fail('Club not found', 404);
  },
  create(payload) {
    const clubs = loadClubs();
    const id = `club-${Date.now()}`;
    const club = {
      id,
      name: payload.name.trim(),
      avatarInitial: payload.name.trim().charAt(0).toUpperCase(),
      description: (payload.description || '').trim(),
      category: payload.category || 'Other',
      accent: randomAccent(),
      private: Boolean(payload.private),
      verified: false,
      createdAt: new Date().toISOString(),
      channels: [
        { id: `${id}-general`, name: 'general', type: 'text' },
        { id: `${id}-announcements`, name: 'announcements', type: 'text' },
      ],
      voiceChannels: DEFAULT_VOICE_CHANNELS,
      members: [{ userId: 'me', role: 'owner' }],
      emojiSet: EMOJI_SETS.club1,
    };
    clubs.push(club);
    writeStore('clubs', clubs);
    achievementsApi.unlock('a8');
    return mockRequest(hydrateClub(club));
  },
  join(id) {
    const clubs = loadClubs();
    const idx = clubs.findIndex((c) => c.id === id);
    if (idx >= 0 && !clubs[idx].members.some((m) => m.userId === 'me')) {
      clubs[idx] = { ...clubs[idx], members: [...clubs[idx].members, { userId: 'me', role: 'member' }] };
      writeStore('clubs', clubs);
      achievementsApi.unlock('a8');
    }
    return mockRequest(hydrateClub(clubs[idx]));
  },

  channelMessages(channelId) {
    const all = loadChannelMessages();
    return mockRequest((all[channelId] || []).map(hydrateMessage));
  },
  sendChannelMessage(channelId, body, extra = {}) {
    const all = loadChannelMessages();
    const msg = {
      id: `cm${Date.now()}`,
      authorId: 'me',
      body,
      type: extra.type || 'text',
      image: extra.image || null,
      reactions: [],
      replies: [],
      createdAt: new Date().toISOString(),
    };
    all[channelId] = [...(all[channelId] || []), msg];
    writeStore('clubChannelMessages', all);
    return mockRequest(hydrateMessage(msg));
  },
  reactChannelMessage(channelId, messageId, emoji) {
    const all = loadChannelMessages();
    const list = all[channelId] || [];
    const next = list.map((m) => {
      if (m.id !== messageId) return m;
      const existing = m.reactions.find((r) => r.emoji === emoji);
      let reactions;
      if (existing) {
        const userIds = existing.userIds.includes('me')
          ? existing.userIds.filter((id) => id !== 'me')
          : [...existing.userIds, 'me'];
        reactions = m.reactions.map((r) => (r.emoji === emoji ? { ...r, userIds } : r)).filter((r) => r.userIds.length > 0);
      } else {
        reactions = [...m.reactions, { emoji, userIds: ['me'] }];
      }
      return { ...m, reactions };
    });
    all[channelId] = next;
    writeStore('clubChannelMessages', all);
    return mockRequest(hydrateMessage(next.find((m) => m.id === messageId)));
  },
  replyChannelMessage(channelId, messageId, body) {
    const all = loadChannelMessages();
    const list = all[channelId] || [];
    const reply = { id: `cr${Date.now()}`, authorId: 'me', body, createdAt: new Date().toISOString() };
    const next = list.map((m) => (m.id === messageId ? { ...m, replies: [...m.replies, reply] } : m));
    all[channelId] = next;
    writeStore('clubChannelMessages', all);
    return mockRequest(hydrateMessage(next.find((m) => m.id === messageId)));
  },

  mediaForClub(clubId) {
    const club = loadClubs().find((c) => c.id === clubId);
    if (!club) return mockRequest([]);
    const all = loadChannelMessages();
    const media = club.channels
      .flatMap((ch) => (all[ch.id] || []).map((m) => ({ ...m, channelName: ch.name })))
      .filter((m) => m.type === 'image')
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return mockRequest(media);
  },

  polls(clubId) {
    return mockRequest(loadPolls()[clubId] || []);
  },
  createPoll(clubId, question, optionTexts) {
    const all = loadPolls();
    const poll = {
      id: `poll${Date.now()}`,
      question,
      options: optionTexts.map((text, i) => ({ id: `o${Date.now()}_${i}`, text, votes: [] })),
      closesAt: new Date(Date.now() + 3 * 86400000).toISOString(),
    };
    all[clubId] = [...(all[clubId] || []), poll];
    writeStore('clubPolls', all);
    return mockRequest(poll);
  },
  vote(clubId, pollId, optionId) {
    const all = loadPolls();
    const list = all[clubId] || [];
    const next = list.map((p) => {
      if (p.id !== pollId) return p;
      return {
        ...p,
        options: p.options.map((o) => ({
          ...o,
          votes: o.id === optionId
            ? (o.votes.includes('me') ? o.votes.filter((v) => v !== 'me') : [...o.votes, 'me'])
            : o.votes.filter((v) => v !== 'me'),
        })),
      };
    });
    all[clubId] = next;
    writeStore('clubPolls', all);
    return mockRequest(next.find((p) => p.id === pollId));
  },

  events(clubId) {
    return mockRequest(loadEvents()[clubId] || []);
  },
  createEvent(clubId, { title, scheduledAt }) {
    const all = loadEvents();
    const d = new Date(scheduledAt);
    const event = {
      id: `ce${Date.now()}`,
      title,
      month: d.toLocaleDateString(undefined, { month: 'short' }).toUpperCase(),
      day: d.getDate(),
      meta: 'Hosted by you',
      countdown: timeUntil(scheduledAt),
    };
    all[clubId] = [...(all[clubId] || []), event];
    writeStore('clubEvents', all);
    return mockRequest(event);
  },

  forumPosts(clubId) {
    return mockRequest((loadForum()[clubId] || []).map(hydratePost));
  },
  createForumPost(clubId, { tag, title, body }) {
    const all = loadForum();
    const post = { id: `f${Date.now()}`, authorId: 'me', tag, title, body, replies: [], upvotes: [], createdAt: new Date().toISOString() };
    all[clubId] = [post, ...(all[clubId] || [])];
    writeStore('clubForum', all);
    return mockRequest(hydratePost(post));
  },
  replyForumPost(clubId, postId, body) {
    const all = loadForum();
    const list = all[clubId] || [];
    const reply = { id: `fr${Date.now()}`, authorId: 'me', body, createdAt: new Date().toISOString() };
    const next = list.map((p) => (p.id === postId ? { ...p, replies: [...p.replies, reply] } : p));
    all[clubId] = next;
    writeStore('clubForum', all);
    return mockRequest(hydratePost(next.find((p) => p.id === postId)));
  },
  upvoteForumPost(clubId, postId) {
    const all = loadForum();
    const list = all[clubId] || [];
    const next = list.map((p) =>
      p.id === postId
        ? { ...p, upvotes: p.upvotes.includes('me') ? p.upvotes.filter((v) => v !== 'me') : [...p.upvotes, 'me'] }
        : p
    );
    all[clubId] = next;
    writeStore('clubForum', all);
    return mockRequest(hydratePost(next.find((p) => p.id === postId)));
  },
};

export const FORUM_TAGS = ['Theory', 'Question', 'Fan Art', 'Discussion'];
