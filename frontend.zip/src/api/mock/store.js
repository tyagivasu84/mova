// localStorage-backed mutable store for mock domains (friends, rooms,
// messages, ...) that need to persist writes across reloads without a
// real backend yet.

const PREFIX = 'club_mock_';

export function readStore(key, seedFn) {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (raw != null) return JSON.parse(raw);
  } catch {
    /* fall through to reseed */
  }
  const seeded = seedFn ? seedFn() : null;
  if (seeded != null) writeStore(key, seeded);
  return seeded;
}

export function writeStore(key, data) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(data));
  } catch {
    /* ignore quota/serialization errors */
  }
  return data;
}

export function resetStore(key) {
  try {
    localStorage.removeItem(PREFIX + key);
  } catch {
    /* ignore */
  }
}
