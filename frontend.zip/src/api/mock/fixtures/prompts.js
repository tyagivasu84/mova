// Static prompt decks for the Truth or Dare and Never Have I Ever
// mini-games — no backend needed, just content.

export const TRUTHS = [
  "What's the most embarrassing thing in your watch history?",
  'What movie do you pretend to like but secretly hate?',
  "What's a celebrity crush you've never told anyone about?",
  "What's the last lie you told in this app?",
  'What show did you binge in one sitting?',
  "What's your most-used emoji and why?",
  "What's a hot take you'd never say out loud in a group chat?",
  "What's the cringiest thing you've ever sent in a DM?",
];

export const DARES = [
  'Type your next message using only emojis.',
  'Send the third photo in your camera roll to this room.',
  'Do your best movie villain laugh on mic.',
  'Change your display name to something silly for 5 minutes.',
  'Recite the alphabet backwards.',
  'Describe your day using only movie titles.',
  'Do an impression of another participant.',
  'Send a voice message singing the CLUB jingle you just made up.',
];

export const NEVER_HAVE_I_EVER = [
  'Never have I ever fallen asleep during a movie in the theater.',
  'Never have I ever cried during an animated movie.',
  'Never have I ever rewatched a whole series in one weekend.',
  'Never have I ever pretended to have seen a movie I hadn’t.',
  'Never have I ever spoiled an ending for someone by accident.',
  'Never have I ever watched a movie just because of one actor.',
  'Never have I ever skipped the credits scene and regretted it.',
  'Never have I ever texted through an entire movie.',
  'Never have I ever forgotten the name of a movie mid-conversation.',
  'Never have I ever watched the same movie more than 10 times.',
];

// Shared shape for both Trivia and Emoji Charades — { prompt, choices,
// correctIndex } — one generic round-quiz engine renders both decks.
// Mix of straight movie trivia and lighter relationship/awkward-moment/
// school pop-culture trivia — the latter are framed around common movie
// tropes and survey-backed consensus, not personal confessions (that's
// Truth or Dare / Never Have I Ever's job), so every question still has
// one real, defensible correct answer.
export const TRIVIA_QUESTIONS = [
  { prompt: 'Which director is known for "Jaws" and "Jurassic Park"?', choices: ['Steven Spielberg', 'James Cameron', 'Christopher Nolan', 'Ridley Scott'], correctIndex: 0 },
  { prompt: 'What was the first feature-length animated movie ever released?', choices: ['Pinocchio', 'Snow White and the Seven Dwarfs', 'Fantasia', 'Bambi'], correctIndex: 1 },
  { prompt: 'Which actor has played Batman the most times on film?', choices: ['Christian Bale', 'Michael Keaton', 'Ben Affleck', 'George Clooney'], correctIndex: 1 },
  { prompt: 'Who composed the score for "Star Wars"?', choices: ['Hans Zimmer', 'John Williams', 'Danny Elfman', 'Alan Silvestri'], correctIndex: 1 },
  { prompt: 'In "The Matrix," what color pill does Neo take?', choices: ['Blue', 'Red', 'Green', 'Purple'], correctIndex: 1 },
  { prompt: 'In teen rom-coms, where does the classic first-kiss scene most often happen?', choices: ['The school dance', 'The cafeteria', 'Detention', 'The bus stop'], correctIndex: 0 },
  { prompt: 'What\'s the #1 breakup trope right before the third-act reunion in a rom-com?', choices: ['A big misunderstanding', 'Moving to another city', 'Falling for someone else', 'A family feud'], correctIndex: 0 },
  { prompt: 'Classic movie cliché: what does the awkward date always knock over first?', choices: ['A glass of water', 'The waiter', 'A candle', 'Their own chair'], correctIndex: 0 },
  { prompt: 'In "meet cute" movie tropes, what most commonly brings the couple together?', choices: ['A coffee shop collision', 'A blind date', 'Being coworkers', 'A dating app'], correctIndex: 0 },
  { prompt: 'What\'s the most-used excuse in movies for ghosting someone after a date?', choices: ['"My phone died"', '"I got busy with work"', '"I lost your number"', '"I fell asleep"'], correctIndex: 1 },
  { prompt: 'In high school movies, prom night drama most often centers on:', choices: ['Who asked who', 'The dress/suit', 'Who\'s driving', 'The after-party'], correctIndex: 0 },
  { prompt: 'What\'s the classic setup for the "wrong person overhears your crush confession" scene?', choices: ['Talking to the wrong locker', 'A phone on speaker', 'A note passed to the wrong person', 'Yelling it across the hallway'], correctIndex: 1 },
];

export const EMOJI_CHARADES = [
  { prompt: '🦁👑', choices: ['The Lion King', 'Madagascar', 'Zootopia', 'Jungle Book'], correctIndex: 0 },
  { prompt: '🕷️👨', choices: ['Batman', 'Spider-Man', 'Venom', 'Iron Man'], correctIndex: 1 },
  { prompt: '🧊❄️👸', choices: ['Moana', 'Encanto', 'Frozen', 'Tangled'], correctIndex: 2 },
  { prompt: '🦈🌊', choices: ['Jaws', 'Finding Nemo', 'Moana', 'Titanic'], correctIndex: 0 },
  { prompt: '🚗⚡🔴', choices: ['Cars', 'Fast & Furious', 'Transformers', 'Speed'], correctIndex: 1 },
  { prompt: '🏠🎈👴', choices: ['UP', 'Coco', 'Inside Out', 'Soul'], correctIndex: 0 },
  { prompt: '🧙‍♂️💍🌋', choices: ['Harry Potter', 'The Lord of the Rings', 'Narnia', 'Shrek'], correctIndex: 1 },
  { prompt: '🤖❤️🌱', choices: ['Wall-E', 'Big Hero 6', 'Ex Machina', 'Transformers'], correctIndex: 0 },
];

export const SPYFALL_LOCATIONS = [
  'Movie Theater', 'Space Station', 'Beach Party', 'Recording Studio',
  'Haunted House', 'Cruise Ship', 'Film Set', 'Amusement Park',
  'Art Museum', 'Video Game Convention',
];
