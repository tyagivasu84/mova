// Seed roster shared across every mock domain (friends, clubs, rooms,
// taste match, messages) so the same cast of people recurs everywhere.
// `funFacts` (3 statements, exactly one `lie: true`) powers the
// Two Truths and a Lie room icebreaker game.

export const MOCK_USERS = [
  {
    id: 'u1', displayName: 'Maya Chen', username: 'mayac', avatarInitial: 'M', verified: true,
    bio: 'Horror movie nights every Friday.',
    funFacts: [
      { text: "I've seen every Friday the 13th movie." },
      { text: "I'm allergic to popcorn.", lie: true },
      { text: 'I once stayed up all night for a horror marathon.' },
    ],
  },
  {
    id: 'u2', displayName: 'Jordan Reyes', username: 'jreyes', avatarInitial: 'J', verified: false,
    bio: 'Sci-fi completionist. Watched Dune 12 times.', dmOnlyFriends: true,
    funFacts: [
      { text: "I've watched Dune 12 times." },
      { text: 'I own a lightsaber replica signed by George Lucas.', lie: true },
      { text: 'I can recite the opening crawl of Star Wars from memory.' },
    ],
  },
  {
    id: 'u3', displayName: 'Priya Nair', username: 'priyan', avatarInitial: 'P', verified: true,
    bio: 'Rom-com watch parties, always with snacks.',
    funFacts: [
      { text: 'I always bring homemade snacks to watch parties.' },
      { text: "I've never cried during a rom-com.", lie: true },
      { text: "My favorite rom-com is a three-way tie." },
    ],
  },
  {
    id: 'u4', displayName: 'Ethan Cole', username: 'ecole', avatarInitial: 'E', verified: false,
    bio: 'Streaming co-op games on weekends.',
    funFacts: [
      { text: 'I stream co-op games every weekend.' },
      { text: "I've beaten every Dark Souls game blindfolded.", lie: true },
      { text: "My chat calls me 'Captain Clutch'." },
    ],
  },
  {
    id: 'u5', displayName: 'Sofia Marquez', username: 'sofiam', avatarInitial: 'S', verified: true,
    bio: 'Runs the Animation Club.',
    funFacts: [
      { text: 'I run the Animation Club.' },
      { text: "I've never watched a Studio Ghibli film.", lie: true },
      { text: 'I own over 200 animated movies.' },
    ],
  },
  {
    id: 'u6', displayName: 'Liam Turner', username: 'lturner', avatarInitial: 'L', verified: false,
    bio: 'Documentary marathons every Sunday.',
    funFacts: [
      { text: 'I do documentary marathons every Sunday.' },
      { text: 'I once appeared as an extra in a nature documentary.' },
      { text: 'I fall asleep during every documentary I watch.', lie: true },
    ],
  },
  {
    id: 'u7', displayName: 'Amara Okafor', username: 'amarao', avatarInitial: 'A', verified: true,
    bio: 'Reviews everything. Trust no trailer.',
    funFacts: [
      { text: 'I write a review for every movie I watch.' },
      { text: "I've never trusted a movie trailer in my life." },
      { text: 'I gave a perfect 10/10 to a movie I fell asleep during.', lie: true },
    ],
  },
  {
    id: 'u8', displayName: 'Noah Kim', username: 'noahk', avatarInitial: 'N', verified: false,
    bio: 'Korean drama enthusiast.',
    funFacts: [
      { text: "I've watched over 100 K-dramas." },
      { text: 'I picked up conversational Korean just from watching dramas.' },
      { text: "I've never cried during a K-drama finale.", lie: true },
    ],
  },
  {
    id: 'u9', displayName: 'Isabella Rossi', username: 'irossi', avatarInitial: 'I', verified: false,
    bio: 'Loves a good slow-burn thriller.',
    funFacts: [
      { text: 'My favorite genre is slow-burn thrillers.' },
      { text: "I've guessed the twist in every thriller I've ever watched.", lie: true },
      { text: 'I once stayed awake three nights bingeing a thriller series.' },
    ],
  },
  {
    id: 'u10', displayName: 'Marcus Webb', username: 'mwebb', avatarInitial: 'W', verified: true,
    bio: 'Podcasts, panels, and premieres.',
    funFacts: [
      { text: "I've been to five movie premieres." },
      { text: 'I host a podcast about movie panels.' },
      { text: "I've never missed a single Comic-Con panel.", lie: true },
    ],
  },
  {
    id: 'u11', displayName: 'Zoe Bennett', username: 'zbennett', avatarInitial: 'Z', verified: false,
    bio: 'Comfort-watch curator.',
    funFacts: [
      { text: 'I keep a running list of comfort movies for bad days.' },
      { text: 'I rewatch the same movie every single week.', lie: true },
      { text: 'My most-rewatched movie has over 50 rewatches.' },
    ],
  },
  {
    id: 'u12', displayName: 'Diego Alvarez', username: 'dalvarez', avatarInitial: 'D', verified: false,
    bio: 'Late-night game streams.',
    funFacts: [
      { text: 'I stream games late at night.' },
      { text: "I've stayed awake for 48 hours straight streaming.", lie: true },
      { text: 'My stream has a running joke about pizza.' },
    ],
  },
  {
    id: 'u13', displayName: 'Hannah Fischer', username: 'hfischer', avatarInitial: 'H', verified: true,
    bio: 'Film school dropout, professional opinion-haver.',
    funFacts: [
      { text: 'I dropped out of film school.' },
      { text: 'I have strong opinions about every movie ever made.' },
      { text: "I've never disagreed with a movie critic.", lie: true },
    ],
  },
  {
    id: 'u14', displayName: 'Ravi Shah', username: 'rshah', avatarInitial: 'R', verified: false,
    bio: 'Watches everything at 1.5x speed.',
    funFacts: [
      { text: 'I watch everything at 1.5x speed.' },
      { text: 'I once watched a 3-hour movie in under two hours.' },
      { text: "I've never watched a movie at normal speed.", lie: true },
    ],
  },
];

export function mockUser(id) {
  return MOCK_USERS.find((u) => u.id === id) || null;
}
