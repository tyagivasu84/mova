// Sync, like ageProfile.js — these are read at boot (AppShell) and on every
// toggle, so there's no need to wrap them in mockRequest's artificial delay.
import { readStore, writeStore } from './mock/store';

const DEFAULTS = {
  privateProfile: false,
  dmOnlyFriends: true,
  reduceMotion: false,
};

export const settingsApi = {
  get() {
    return readStore('settings', () => DEFAULTS);
  },
  set(patch) {
    const next = { ...settingsApi.get(), ...patch };
    writeStore('settings', next);
    return next;
  },
};
