import { mockRequest } from './mockClient';

export const GIFT_CATALOG = [
  { id: 'rose', name: 'Rose', icon: '🌹', price: 50 },
  { id: 'popcorn', name: 'Popcorn', icon: '🍿', price: 100 },
  { id: 'trophy', name: 'Trophy', icon: '🏆', price: 250 },
  { id: 'gem', name: 'Gem', icon: '💎', price: 500 },
  { id: 'crown', name: 'Crown', icon: '👑', price: 1000 },
];

export const giftsApi = {
  catalog() {
    return mockRequest(GIFT_CATALOG);
  },
};
