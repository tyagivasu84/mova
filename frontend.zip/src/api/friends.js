// Mock friends/social graph — no backend route exists yet.
import { mockRequest } from './mockClient';
import { readStore, writeStore } from './mock/store';
import { MOCK_USERS, mockUser } from './mock/fixtures/users';

function iso(daysAgo) {
  return new Date(Date.now() - daysAgo * 86400000).toISOString();
}

function seedFriends() {
  return {
    friendIds: ['u1', 'u3', 'u5'],
    incoming: [
      { id: 'fr1', fromUserId: 'u2', status: 'pending', createdAt: iso(0.4) },
      { id: 'fr2', fromUserId: 'u7', status: 'pending', createdAt: iso(2) },
    ],
    outgoing: [{ id: 'fr3', toUserId: 'u10', status: 'pending', createdAt: iso(1) }],
  };
}

function load() {
  return readStore('friends', seedFriends);
}

function computeView(state) {
  return {
    friends: state.friendIds.map(mockUser).filter(Boolean),
    incoming: state.incoming
      .filter((r) => r.status === 'pending')
      .map((r) => ({ ...r, fromUser: mockUser(r.fromUserId) })),
    outgoing: state.outgoing
      .filter((r) => r.status === 'pending')
      .map((r) => ({ ...r, toUser: mockUser(r.toUserId) })),
  };
}

export const friendsApi = {
  list() {
    return mockRequest(computeView(load()));
  },
  search(query) {
    const q = (query || '').trim().toLowerCase();
    if (!q) return mockRequest([]);
    const state = load();
    const results = MOCK_USERS.filter(
      (u) =>
        !state.friendIds.includes(u.id) &&
        (u.displayName.toLowerCase().includes(q) || u.username.toLowerCase().includes(q))
    );
    return mockRequest(results);
  },
  sendRequest(userId) {
    const state = load();
    const alreadySent = state.outgoing.some((r) => r.toUserId === userId && r.status === 'pending');
    if (!alreadySent && !state.friendIds.includes(userId)) {
      state.outgoing.push({
        id: `fr${Date.now()}`,
        toUserId: userId,
        status: 'pending',
        createdAt: new Date().toISOString(),
      });
      writeStore('friends', state);
    }
    return mockRequest(computeView(state));
  },
  acceptRequest(id) {
    const state = load();
    const req = state.incoming.find((r) => r.id === id);
    if (req) {
      state.incoming = state.incoming.filter((r) => r.id !== id);
      if (!state.friendIds.includes(req.fromUserId)) state.friendIds.push(req.fromUserId);
      writeStore('friends', state);
    }
    return mockRequest(computeView(state));
  },
  declineRequest(id) {
    const state = load();
    state.incoming = state.incoming.filter((r) => r.id !== id);
    writeStore('friends', state);
    return mockRequest(computeView(state));
  },
};
