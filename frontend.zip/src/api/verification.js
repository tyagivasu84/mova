import { mockRequest } from './mockClient';
import { readStore, writeStore } from './mock/store';
import { achievementsApi } from './achievements';

export const verificationApi = {
  status() {
    return mockRequest(readStore('verified', () => false));
  },
  submit(source = 'manual') {
    writeStore('verified', true);
    if (source === 'director') writeStore('verifiedViaDirector', true);
    achievementsApi.unlock('a6');
    return mockRequest({ verified: true }, { delay: 1400 });
  },
  // Only unverifies if the badge came from a Director purchase — never
  // strips one earned honestly through VerifyModal's pose-match flow.
  revokeDirectorGrant() {
    if (readStore('verifiedViaDirector', () => false)) {
      writeStore('verified', false);
      writeStore('verifiedViaDirector', false);
    }
    return mockRequest({ verified: readStore('verified', () => false) });
  },
};
