// Sync, like settingsApi/ageProfileApi — persists which plan the user has
// selected so it survives a refresh instead of reverting to Free.
import { readStore, writeStore } from './mock/store';

export const premiumApi = {
  getPlan() {
    return readStore('premiumPlan', () => 'free');
  },
  setPlan(planId) {
    writeStore('premiumPlan', planId);
    return planId;
  },
};
