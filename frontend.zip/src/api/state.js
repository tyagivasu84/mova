import { request } from './client';

// reconstructed — mirrors the backend /api/state routes (points/streak/shop).
// Only a couple of calls were visible in the screenshots (addPoints,
// claimStreak, redeemShopItem, get); the shape below matches how
// AppStateContext.jsx consumes them.
export const stateApi = {
  async get() {
    const data = await request('/state', { auth: true });
    return data; // { points, streak, shopOwned }
  },

  async addPoints(amount) {
    const data = await request('/state/points', {
      method: 'POST',
      body: { amount },
      auth: true,
    });
    return data.state;
  },

  async claimStreak() {
    const data = await request('/state/streak/claim', {
      method: 'POST',
      auth: true,
    });
    return data; // { reward, dayOfWeek, state }
  },

  async redeemShopItem(itemId) {
    const data = await request('/state/shop/redeem', {
      method: 'POST',
      body: { itemId },
      auth: true,
    });
    return data; // { item, state }
  },
};
