// Mock referral system — no backend route exists yet. Same async
// object-of-methods shape as the real xApi modules so this can be
// pointed at request() later without touching call sites.
import { mockRequest } from './mockClient';
import { readStore } from './mock/store';
import { MOCK_USERS } from './mock/fixtures/users';

const TIERS = [
  { tier: 1, referralsNeeded: 1, rewardPoints: 100 },
  { tier: 2, referralsNeeded: 3, rewardPoints: 300 },
  { tier: 3, referralsNeeded: 5, rewardPoints: 750 },
  { tier: 4, referralsNeeded: 10, rewardPoints: 2000 },
];

function seedReferrals() {
  return {
    code: 'CLUB-RSTY-4821',
    referredUsers: MOCK_USERS.slice(0, 2).map((u, i) => ({
      userId: u.id,
      displayName: u.displayName,
      status: 'joined',
      joinedAt: new Date(Date.now() - 86400000 * (5 + i * 3)).toISOString(),
    })),
  };
}

function load() {
  return readStore('referrals', seedReferrals);
}

export const referralsApi = {
  getCode() {
    return mockRequest(load().code);
  },
  getReferrals() {
    return mockRequest(load().referredUsers);
  },
  getLadder() {
    const count = load().referredUsers.length;
    return mockRequest(TIERS.map((t) => ({ ...t, unlocked: count >= t.referralsNeeded })));
  },
};
