// Mock social layer for a Watch Party room — live chat, emoji reaction
// log, a shared queue, quick polls, and a collaborative notes pad. All
// scoped by roomId, stored the same way the rest of the mock API stores
// things (readStore/writeStore, per-key maps). The room's lifecycle itself
// (create/get/lock/invite) stays in roomsApi — this only covers the extra
// in-party social data that a plain Room doesn't need.
import { mockRequest } from './mockClient';
import { readStore, writeStore } from './mock/store';
import { mockUser } from './mock/fixtures/users';

function loadChat() {
  return readStore('watchPartyChat', () => ({}));
}
function loadQueue() {
  return readStore('watchPartyQueue', () => ({}));
}
function loadPolls() {
  return readStore('watchPartyPolls', () => ({}));
}
function loadNotes() {
  return readStore('watchPartyNotes', () => ({}));
}
function loadReactions() {
  return readStore('watchPartyReactions', () => ({}));
}

function hydrateChatMessage(m) {
  return { ...m, author: m.authorId === 'me' ? null : mockUser(m.authorId) };
}

export const watchPartyApi = {
  chat(roomId) {
    const all = loadChat();
    return mockRequest((all[roomId] || []).map(hydrateChatMessage));
  },
  sendChat(roomId, body, authorId = 'me') {
    const all = loadChat();
    const msg = {
      id: `wpc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      authorId,
      body,
      createdAt: new Date().toISOString(),
    };
    all[roomId] = [...(all[roomId] || []), msg];
    writeStore('watchPartyChat', all);
    return mockRequest(hydrateChatMessage(msg));
  },

  queue(roomId) {
    return mockRequest(loadQueue()[roomId] || []);
  },
  addToQueue(roomId, item) {
    const all = loadQueue();
    const entry = { id: `wpq-${Date.now()}`, ...item };
    all[roomId] = [...(all[roomId] || []), entry];
    writeStore('watchPartyQueue', all);
    return mockRequest(entry);
  },
  removeFromQueue(roomId, itemId) {
    const all = loadQueue();
    all[roomId] = (all[roomId] || []).filter((q) => q.id !== itemId);
    writeStore('watchPartyQueue', all);
    return mockRequest(all[roomId]);
  },

  polls(roomId) {
    return mockRequest(loadPolls()[roomId] || []);
  },
  createPoll(roomId, question, optionTexts) {
    const all = loadPolls();
    const poll = {
      id: `wpp-${Date.now()}`,
      question,
      options: optionTexts.map((text, i) => ({ id: `o${i}`, text, votes: [] })),
    };
    all[roomId] = [...(all[roomId] || []), poll];
    writeStore('watchPartyPolls', all);
    return mockRequest(poll);
  },
  vote(roomId, pollId, optionId) {
    const all = loadPolls();
    const next = (all[roomId] || []).map((p) => {
      if (p.id !== pollId) return p;
      return {
        ...p,
        options: p.options.map((o) => {
          const has = o.votes.includes('me');
          if (o.id === optionId) return { ...o, votes: has ? o.votes : [...o.votes, 'me'] };
          return { ...o, votes: o.votes.filter((v) => v !== 'me') };
        }),
      };
    });
    all[roomId] = next;
    writeStore('watchPartyPolls', all);
    return mockRequest(next.find((p) => p.id === pollId));
  },

  notes(roomId) {
    return mockRequest(loadNotes()[roomId] || '');
  },
  saveNotes(roomId, text) {
    const all = loadNotes();
    all[roomId] = text;
    writeStore('watchPartyNotes', all);
    return mockRequest(text);
  },

  reactions(roomId) {
    return mockRequest(loadReactions()[roomId] || []);
  },
  sendReaction(roomId, emoji, authorId = 'me') {
    const all = loadReactions();
    const entry = { id: `wpr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, emoji, authorId, createdAt: new Date().toISOString() };
    all[roomId] = [...(all[roomId] || []), entry];
    writeStore('watchPartyReactions', all);
    return mockRequest(entry);
  },
};
