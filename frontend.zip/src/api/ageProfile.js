// Mock age-bracket flag set at signup. Accounts 13-17 get age-appropriate
// defaults (e.g. gifting disabled) rather than being blocked outright;
// under-13 signups are blocked entirely in AuthOverlay before this is ever
// written.
import { readStore, writeStore } from './mock/store';

export const ageProfileApi = {
  get() {
    return readStore('ageBracket', () => 'adult');
  },
  set(bracket) {
    writeStore('ageBracket', bracket);
    return bracket;
  },
};
