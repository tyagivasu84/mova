// Mock "what a friend is currently doing" presence — no real-time
// backend exists yet, so this is a small seeded map, same spirit as the
// other mock domains (notifications, achievements). The signed-in
// user's own status isn't here — it's derived live from
// CallContext.activeRoom instead, since that's real state rather than a
// fake presence feed. Anyone not in the map defaults to 'online'.
import { mockRequest } from './mockClient';

const PRESENCE = {
  u1: { status: 'gaming', activity: 'Minecraft' },
  u3: { status: 'listening', activity: 'a movie soundtrack playlist' },
  u4: { status: 'watching', activity: 'Nocturne City' },
  u5: { status: 'idle' },
  u7: { status: 'busy' },
  u9: { status: 'busy', activity: 'studying' },
};

export const STATUS_INFO = {
  online: { label: 'Online', color: 'var(--green)', icon: '🟢' },
  gaming: { label: 'Gaming', color: 'var(--blue)', icon: '🎮' },
  watching: { label: 'Watching', color: 'var(--red)', icon: '🎬' },
  listening: { label: 'Listening', color: '#a970ff', icon: '🎧' },
  idle: { label: 'Idle', color: 'var(--gold)', icon: '🌙' },
  busy: { label: 'Busy', color: 'var(--text-dim)', icon: '⛔' },
};

export const presenceApi = {
  map() {
    return mockRequest(PRESENCE);
  },
  of(userId) {
    return PRESENCE[userId] || { status: 'online' };
  },
};
