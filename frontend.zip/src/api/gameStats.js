import { mockRequest } from './mockClient';

const GAME_STATS = [
  { game: 'Minecraft', icon: '🧱', hoursPlayed: 42, lastPlayed: '2 days ago', favorite: true },
  { game: 'Among Us', icon: '🛸', hoursPlayed: 18, lastPlayed: '1 week ago', favorite: false },
  { game: 'GTA 5', icon: '🚗', hoursPlayed: 9, lastPlayed: '3 weeks ago', favorite: false },
];

export const gameStatsApi = {
  list() {
    return mockRequest(GAME_STATS);
  },
};
