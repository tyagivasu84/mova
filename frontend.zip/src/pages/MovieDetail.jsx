import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { catalogApi } from '../api/catalog';
import { platformName } from '../api/platform';
import { watchlistApi } from '../api/watchlist';
import { asText } from '../utils/text';
import { useToast } from '../context/ToastContext';
import WatchPartyCreateModal from '../components/WatchPartyCreateModal';

export default function MovieDetail() {
  const { name } = useParams();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [title, setTitle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showWatchParty, setShowWatchParty] = useState(false);
  const [inWatchlist, setInWatchlist] = useState(false);

  useEffect(() => {
    setLoading(true);
    catalogApi
      .title(name)
      .then((t) => {
        setTitle(t);
        setInWatchlist(watchlistApi.has(t.title));
      })
      .catch((e) => setError(e.message || 'Title not found'))
      .finally(() => setLoading(false));
  }, [name]);

  function handleToggleWatchlist() {
    const next = watchlistApi.toggle(title.title);
    setInWatchlist(next);
    showToast(next ? `Added ${title.title} to watchlist` : `Removed ${title.title} from watchlist`);
  }

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 80 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (error || !title) {
    return (
      <div className="empty-state">
        <div className="emoji">🎬</div>
        <h3>Title not found</h3>
        <p>{error}</p>
        <button className="btn btn-primary" onClick={() => navigate('/')}>
          Back home
        </button>
      </div>
    );
  }

  return (
    <div>
      <button
        className="btn btn-ghost"
        style={{ marginBottom: 20 }}
        onClick={() => navigate(-1)}
      >
        ← Back
      </button>

      <div style={{ display: 'flex', gap: 28, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <div
          style={{
            flex: '0 0 220px',
            height: 320,
            borderRadius: 14,
            position: 'relative',
            overflow: 'hidden',
            border: '1px solid var(--border)',
          }}
        >
          <img
            src={`https://picsum.photos/seed/${encodeURIComponent(title.title)}/440/640`}
            alt=""
            style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}
          />
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: `linear-gradient(160deg, ${title.accent || title.a || '#5a3a1e'}, transparent 60%)`,
              opacity: 0.6,
            }}
          />
        </div>
        <div style={{ flex: 1, minWidth: 280 }}>
          <h1 style={{ fontFamily: 'Archivo Black', fontSize: 34, marginBottom: 10 }}>
            {title.title}
          </h1>
          <div
            style={{
              display: 'flex',
              gap: 14,
              flexWrap: 'wrap',
              color: 'var(--text-muted)',
              fontSize: 13,
              marginBottom: 18,
            }}
          >
            <span>{title.year}</span>
            <span>{asText(title.genre)}</span>
            <span>{title.runtime}</span>
            <span style={{ color: 'var(--gold)', fontWeight: 800 }}>★ {title.rating}</span>
          </div>

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 22 }}>
            {(title.platforms || []).map((p) => (
              <span
                key={platformName(p)}
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  padding: '5px 11px',
                  borderRadius: 100,
                  background: 'rgba(255,255,255,0.06)',
                  border: '1px solid var(--border)',
                  color: 'var(--text-muted)',
                }}
              >
                {platformName(p)}
              </span>
            ))}
          </div>

          <p style={{ color: 'var(--text-muted)', lineHeight: 1.6, marginBottom: 24 }}>
            A standout {asText(title.genre).toLowerCase()} title from {title.year}. Start a room
            and hang out on voice/video with friends while you each stream it from your own
            account — press play together and react live.
          </p>

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <button className="btn btn-primary" onClick={() => setShowWatchParty(true)}>
              🎬 Create Watch Party
            </button>
            <button className="btn btn-ghost" onClick={handleToggleWatchlist}>
              {inWatchlist ? '✓ In Watchlist' : '+ Watchlist'}
            </button>
          </div>
        </div>
      </div>

      {showWatchParty && (
        <WatchPartyCreateModal initialTitle={title.title} onClose={() => setShowWatchParty(false)} />
      )}
    </div>
  );
}
