import { useState } from 'react';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import { premiumApi } from '../api/premium';
import { verificationApi } from '../api/verification';
import { ageProfileApi } from '../api/ageProfile';
import ShopGrid from '../components/ShopGrid';
import StreakStrip from '../components/StreakStrip';
import ReferralLadder from '../components/ReferralLadder';
import styles from './Premium.module.css';

const PLANS = [
  {
    id: 'free',
    name: 'Free',
    price: '₹0',
    period: '',
    perks: ['Join public rooms', 'Basic watchlist', 'Daily streak rewards'],
    highlight: false,
  },
  {
    id: 'premium',
    name: 'Premium',
    price: '₹199',
    period: '/mo',
    perks: ['Host unlimited rooms', 'Voice + video calls', 'Priority queue skip', 'Custom theme'],
    highlight: true,
  },
  {
    id: 'director',
    name: 'Director',
    price: '₹1,499',
    period: '/yr',
    perks: ['Everything in Premium', 'Verified badge', 'Room boosts included', 'Early feature access'],
    highlight: false,
  },
];

export default function Premium() {
  const { points, addPoints } = useAppState();
  const { showToast } = useToast();
  const [currentPlan, setCurrentPlan] = useState(() => premiumApi.getPlan());
  const [tab, setTab] = useState('premium');
  const blocked = ageProfileApi.get() === 'teen';

  async function handleBuyPoints(amount) {
    try {
      await addPoints(amount);
      showToast(`+${amount.toLocaleString()} pts added`);
    } catch (err) {
      showToast(err.message || 'Could not add points');
    }
  }

  async function handleChoosePlan(plan) {
    if (blocked && plan.id !== 'free') {
      showToast('Purchases are limited for age-appropriate accounts');
      return;
    }
    const previousPlan = currentPlan;
    premiumApi.setPlan(plan.id);
    setCurrentPlan(plan.id);
    showToast(`Switched to ${plan.name} 🎉`);
    // Director's "Verified badge" perk is a real perk, not just copy —
    // grant it through the same verification system Profile.jsx reads,
    // and revoke it if downgrading away from Director (unless the user
    // separately earned it via VerifyModal's pose-match flow).
    if (plan.id === 'director') {
      try {
        await verificationApi.submit('director');
        showToast("You're verified! ✅");
      } catch {
        /* non-critical */
      }
    } else if (previousPlan === 'director') {
      try {
        const { verified } = await verificationApi.revokeDirectorGrant();
        if (!verified) showToast('Director perks removed — verified badge revoked');
      } catch {
        /* non-critical */
      }
    }
  }

  return (
    <div>
      <div className="section-head">
        <h2>Premium</h2>
        <span>★ {points.toLocaleString()} pts available</span>
      </div>

      <div className={styles.tabRow}>
        <button
          className={`${styles.tabBtn} ${tab === 'premium' ? styles.tabBtnActive : ''}`}
          onClick={() => setTab('premium')}
        >
          💎 Premium
        </button>
        <button
          className={`${styles.tabBtn} ${tab === 'rewards' ? styles.tabBtnActive : ''}`}
          onClick={() => setTab('rewards')}
        >
          🎁 Rewards
        </button>
      </div>

      {tab === 'rewards' ? (
        <>
          <StreakStrip />

          <div className="section-head">
            <h2>Points shop</h2>
            <span>Redeem your points</span>
          </div>
          <ShopGrid />

          <div className="section-head">
            <h2>Invite &amp; earn</h2>
            <span>Climb the referral ladder for bonus points</span>
          </div>
          <ReferralLadder />
        </>
      ) : (
        <>
          {blocked && (
            <div className={styles.notice}>
              🛡️ Age-appropriate mode is on for your account. Paid plan purchases are limited.
            </div>
          )}

          <div className={styles.planGrid}>
            {PLANS.map((plan) => {
              const isCurrent = currentPlan === plan.id;
              return (
                <div
                  key={plan.id}
                  className={`${styles.planCard} ${plan.highlight ? styles.planCardHighlight : ''}`}
                >
                  <h3 className={styles.planName}>{plan.name}</h3>
                  <div className={styles.planPriceRow}>
                    <span className={styles.planPrice}>{plan.price}</span>
                    <span className={styles.planPeriod}>{plan.period}</span>
                  </div>
                  <ul className={styles.perkList}>
                    {plan.perks.map((perk) => (
                      <li key={perk} className={styles.perkItem}>
                        ✓ {perk}
                      </li>
                    ))}
                  </ul>
                  <button
                    className={plan.highlight ? 'btn btn-primary' : 'btn btn-ghost'}
                    style={{ width: '100%' }}
                    disabled={isCurrent || (blocked && plan.id !== 'free')}
                    onClick={() => handleChoosePlan(plan)}
                  >
                    {isCurrent ? 'Current plan' : `Choose ${plan.name}`}
                  </button>
                </div>
              );
            })}
          </div>

          <div className="section-head">
            <h2>Top up points</h2>
            <span>Spend on cosmetics &amp; perks below</span>
          </div>
          <div className={styles.pointsRow}>
            {[500, 1000, 2500].map((amt) => (
              <button key={amt} className="btn btn-ghost" onClick={() => handleBuyPoints(amt)}>
                + {amt.toLocaleString()} pts
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
