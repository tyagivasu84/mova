import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { catalogApi } from '../api/catalog';
import { roomsApi } from '../api/rooms';
import { useToast } from '../context/ToastContext';
import RoomCard from '../components/RoomCard';
import HostRoomModal from '../components/HostRoomModal';
import WatchPartyCreateModal from '../components/WatchPartyCreateModal';

// One Room primitive — no fixed watch/game category, so there's no
// category-chip filter here. Free-text search narrows the list; "Find &
// join" skips browsing entirely and drops you into the fullest open room
// matching what you typed (not skill-based matchmaking, just that rule).
export default function Rooms() {
  const navigate = useNavigate();
  const location = useLocation();
  const { showToast } = useToast();
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState(() => location.state?.presetSearch || '');
  const [showHost, setShowHost] = useState(false);
  const [showWatchParty, setShowWatchParty] = useState(false);
  const [matching, setMatching] = useState(false);

  function load() {
    setLoading(true);
    Promise.all([
      catalogApi.rooms().catch(() => []),
      roomsApi.hosted().catch(() => []),
      roomsApi.examples().catch(() => []),
    ])
      .then(([catalogRooms, hosted, examples]) => setRooms([...hosted, ...examples, ...catalogRooms]))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  const q = search.trim().toLowerCase();
  const visible = q
    ? rooms.filter(
        (r) =>
          r.title.toLowerCase().includes(q) ||
          (r.tag || '').toLowerCase().includes(q) ||
          (typeof r.platform === 'string' && r.platform.toLowerCase().includes(q))
      )
    : rooms;

  async function handleFindRoom() {
    if (!search.trim()) return;
    setMatching(true);
    try {
      const room = await roomsApi.quickMatch(search.trim());
      if (room) {
        navigate(`/room/${room.id}`);
      } else {
        showToast(`No open rooms about "${search.trim()}" right now — host one instead?`);
      }
    } finally {
      setMatching(false);
    }
  }

  return (
    <div>
      <div
        className="section-head"
        style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
      >
        <div>
          <h2>Rooms</h2>
          <span>Jump into a live room — about anything</span>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-ghost" onClick={() => setShowWatchParty(true)}>
            🎬 Create Watch Party
          </button>
          <button className="btn btn-primary" onClick={() => setShowHost(true)}>
            + Host a room
          </button>
        </div>
      </div>

      {showHost && (
        <HostRoomModal
          onClose={() => {
            setShowHost(false);
            load();
          }}
        />
      )}

      {showWatchParty && (
        <WatchPartyCreateModal
          onClose={() => {
            setShowWatchParty(false);
            load();
          }}
        />
      )}

      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search or find a room about… Minecraft, movie night, study"
          style={{
            flex: 1,
            background: 'var(--bg-raised)',
            border: '1px solid var(--border)',
            borderRadius: 8,
            padding: '10px 14px',
            color: '#fff',
            fontSize: 13,
          }}
        />
        <button className="btn btn-blue" onClick={handleFindRoom} disabled={matching || !search.trim()}>
          {matching ? 'Finding…' : '⚡ Find & join'}
        </button>
      </div>

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : visible.length ? (
        <div className="rooms-grid">
          {visible.map((r) => (
            <RoomCard key={r.id} room={r} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">🛋️</div>
          <h3>No rooms right now</h3>
          <p>Be the first — host a room and invite friends.</p>
        </div>
      )}
    </div>
  );
}
