import { useNavigate } from 'react-router-dom';

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="empty-state">
      <div className="emoji">🧭</div>
      <h3>Page not found</h3>
      <p>The link you followed may be broken, or the page may have been removed.</p>
      <button className="btn btn-primary" onClick={() => navigate('/')}>
        Back to Home
      </button>
    </div>
  );
}
