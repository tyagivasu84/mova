import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { catalogApi } from '../api/catalog';
import { roomsApi } from '../api/rooms';
import { GAMES, TRENDING_GAMES } from '../config/games';
import { useToast } from '../context/ToastContext';
import RoomCard from '../components/RoomCard';
import StoryRow from '../components/StoryRow';
import GamePosterCard from '../components/GamePosterCard';
import HostRoomModal from '../components/HostRoomModal';
import styles from './Home.module.css';

export default function Home() {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hostGameFor, setHostGameFor] = useState(null);
  const [startingGame, setStartingGame] = useState(false);

  // Games only ever happen live inside a Room — this gets you into one
  // and drops you straight in with the chosen game already open, via
  // LiveRoom's `autoOpenGame` nav state. Friends can still be invited —
  // that now lives entirely in Host Room's own invite picker rather than
  // a separate quick-invite flow here.
  async function handleQuickPlay(game) {
    setStartingGame(true);
    try {
      // Fill up an existing open room for this game before spinning up a
      // new one — same matchmaking Rooms' "⚡ Find & join" already uses,
      // so Quick Play actually fills seats instead of always forking a
      // fresh room per click.
      const match = await roomsApi.quickMatch(game.title);
      if (match) {
        navigate(`/room/${match.id}`, { state: { autoOpenGame: game.id } });
        return;
      }
      const room = await roomsApi.create({
        title: `${game.title} Room`,
        tag: game.title,
        vibe: 'Casual',
        mode: 'instant',
        private: false,
        invited: [],
      });
      navigate(`/room/${room.id}`, { state: { autoOpenGame: game.id } });
    } catch (err) {
      showToast(err.message || 'Could not start a room');
    } finally {
      setStartingGame(false);
    }
  }

  useEffect(() => {
    Promise.all([
      catalogApi.rooms().catch(() => []),
      roomsApi.hosted().catch(() => []),
      roomsApi.examples().catch(() => []),
    ])
      .then(([catalogRooms, hosted, examples]) => setRooms([...hosted, ...examples, ...catalogRooms].slice(0, 6)))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <StoryRow />

      <div className="section-head">
        <h2>Trending Games</h2>
        <span>What everyone's playing right now</span>
      </div>
      <div style={{ display: 'flex', gap: 14, overflowX: 'auto', marginBottom: 40, paddingBottom: 4 }}>
        {TRENDING_GAMES.map((g) => (
          <GamePosterCard key={g.title} game={g} />
        ))}
      </div>

      <div className="section-head">
        <h2>Games</h2>
        <span>Games happen live in a voice/video room — quick play, or host one and invite friends</span>
      </div>
      <div className="rooms-grid" style={{ marginBottom: 40 }}>
        {GAMES.map((g) => (
          <div key={g.id} className={styles.gameCard}>
            <div className={styles.gameIcon}>{g.icon}</div>
            <h3>{g.title}</h3>
            <p className={styles.gameDesc}>{g.desc}</p>
            <div className={styles.gameActions}>
              <button
                className="btn btn-primary"
                onClick={() => handleQuickPlay(g)}
                disabled={startingGame}
              >
                ⚡ Quick Play
              </button>
              <button className="btn btn-ghost" onClick={() => setHostGameFor(g)}>
                🏠 Host room
              </button>
            </div>
          </div>
        ))}
      </div>

      {hostGameFor && (
        <HostRoomModal
          initialTitle={`${hostGameFor.title} Night`}
          initialTag={hostGameFor.title}
          autoOpenGame={hostGameFor.id}
          onClose={() => setHostGameFor(null)}
        />
      )}

      <div
        className="section-head"
        style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
      >
        <div>
          <h2>Live rooms</h2>
          <span>Jump into a room — watch parties, game lobbies, or just hanging out</span>
        </div>
        <button className="btn btn-ghost" onClick={() => navigate('/rooms')}>
          Browse all →
        </button>
      </div>
      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : rooms.length ? (
        <div className="rooms-grid">
          {rooms.map((r) => (
            <RoomCard key={r.id} room={r} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">🛋️</div>
          <h3>No rooms live right now</h3>
          <p>Be the first — host a room and invite friends.</p>
        </div>
      )}
    </div>
  );
}
