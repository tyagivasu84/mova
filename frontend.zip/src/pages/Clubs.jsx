import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { clubsApi } from '../api/clubs';
import { useToast } from '../context/ToastContext';
import ClubCreateModal from '../components/ClubCreateModal';
import styles from './Clubs.module.css';

function ClubCard({ club, onJoin, navigate, featured }) {
  return (
    <div className={`${styles.card} ${featured ? styles.cardFeatured : ''}`}>
      <div className={styles.cardBanner} style={{ '--ca': club.accent || '#3a1420' }}>
        <div className={styles.bannerLeftBadges}>
          {featured && <span className={styles.featuredBadge}>🔥 Featured</span>}
          {club.live && <span className={styles.liveBadge}>🔴 Live</span>}
        </div>
        <span className={styles.categoryPill}>{club.category}</span>
      </div>
      <div className={styles.cardBody}>
        <div className={styles.cardHead}>
          <div className="avatar-sm" style={{ width: 44, height: 44, fontSize: 16 }}>
            {club.avatarInitial}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className={styles.cardName}>
              {club.name}
              {club.verified && <span title="Verified">✅</span>}
              <span title={`Level ${club.level}`}>{club.badge}</span>
            </div>
            <div className={styles.cardMeta}>
              {club.onlineCount} online · {club.memberCount} members
            </div>
          </div>
        </div>
        <p className={styles.cardDesc}>{club.description}</p>
        <div className={styles.cardActions}>
          <button className="btn btn-ghost" onClick={() => navigate(`/clubs/${club.id}`)}>
            Preview
          </button>
          {club.isMember ? (
            <span className={styles.joinedTag}>✓ Joined</span>
          ) : (
            <button className="btn btn-primary" onClick={() => onJoin(club)}>
              Join
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Clubs() {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [clubs, setClubs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showCreate, setShowCreate] = useState(false);

  function load() {
    setLoading(true);
    clubsApi
      .list()
      .then(setClubs)
      .catch(() => setClubs([]))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function handleJoin(club) {
    try {
      const updated = await clubsApi.join(club.id);
      setClubs((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
      showToast(`Joined ${updated.name}`);
    } catch (err) {
      showToast(err.message || 'Could not join club');
    }
  }

  function openCreate() {
    setShowCreate(true);
  }

  // Private clubs aren't browsable — only reachable via invite link
  // (i.e. navigating straight to /clubs/:id), unless you're already in one.
  const discoverable = useMemo(() => clubs.filter((c) => !c.private || c.isMember), [clubs]);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return discoverable;
    return discoverable.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.category.toLowerCase().includes(q)
    );
  }, [discoverable, search]);

  const myClubs = useMemo(() => discoverable.filter((c) => c.isMember), [discoverable]);

  const recommended = useMemo(() => {
    const notJoined = discoverable.filter((c) => !c.isMember);
    const myCategories = new Set(myClubs.map((c) => c.category));
    const matches = myCategories.size
      ? notJoined.filter((c) => myCategories.has(c.category))
      : notJoined;
    return [...matches].sort((a, b) => b.memberCount - a.memberCount).slice(0, 4);
  }, [discoverable, myClubs]);

  return (
    <div>
      <div className={styles.pageHeader}>
        <h1>Clubs</h1>
        <button className="btn btn-primary" style={{ fontSize: 12.5, padding: '8px 16px' }} onClick={openCreate}>
          + Create Club
        </button>
      </div>

      <input
        className={styles.searchInput}
        placeholder="Search clubs, topics, or interests…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {!loading && myClubs.length > 0 && (
        <>
          <div className="section-head">
            <h2>Your Clubs</h2>
            <span>Communities you've joined</span>
          </div>
          <div className={styles.featuredRow}>
            {myClubs.map((c) => (
              <ClubCard key={c.id} club={c} onJoin={handleJoin} navigate={navigate} />
            ))}
          </div>
        </>
      )}

      {!loading && recommended.length > 0 && (
        <>
          <div className="section-head">
            <h2>Matching Your Interests</h2>
            <span>
              {myClubs.length
                ? 'Based on the clubs you already joined'
                : 'Popular clubs to get you started'}
            </span>
          </div>
          <div className={styles.featuredRow}>
            {recommended.map((c) => (
              <ClubCard key={c.id} club={c} onJoin={handleJoin} navigate={navigate} featured />
            ))}
          </div>
        </>
      )}

      <div className="section-head">
        <h2>All Clubs</h2>
        <span>{visible.length} communities</span>
      </div>

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : visible.length ? (
        <div className={styles.grid}>
          {visible.map((c) => (
            <ClubCard key={c.id} club={c} onJoin={handleJoin} navigate={navigate} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">🏛️</div>
          <h3>No clubs found</h3>
          <p>Try a different search, or create your own.</p>
        </div>
      )}

      {showCreate && <ClubCreateModal onClose={() => setShowCreate(false)} />}
    </div>
  );
}
