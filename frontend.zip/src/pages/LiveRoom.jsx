import { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { roomsApi } from '../api/rooms';
import { useAuth } from '../context/AuthContext';
import { useCall } from '../context/CallContext';
import { useSocial } from '../context/SocialContext';
import { useToast } from '../context/ToastContext';
import { MOCK_USERS, mockUser } from '../api/mock/fixtures/users';
import { GAMES } from '../config/games';
import SpeakingRing from '../components/SpeakingRing';
import TwoTruthsGame from '../components/TwoTruthsGame';
import TruthOrDareGame from '../components/TruthOrDareGame';
import NeverHaveIEverGame from '../components/NeverHaveIEverGame';
import MafiaGame from '../components/MafiaGame';
import TriviaGame from '../components/TriviaGame';
import EmojiCharadesGame from '../components/EmojiCharadesGame';
import SpyfallGame from '../components/SpyfallGame';
import WatchPartyRoom from '../components/WatchPartyRoom';
import styles from './LiveRoom.module.css';

const GAME_COMPONENTS = {
  'two-truths': TwoTruthsGame,
  'truth-or-dare': TruthOrDareGame,
  'never-have-i-ever': NeverHaveIEverGame,
  mafia: MafiaGame,
  trivia: TriviaGame,
  'emoji-charades': EmojiCharadesGame,
  spyfall: SpyfallGame,
};

// Invited friends always show up as room participants — everyone else
// fills the remaining seats, same "guaranteed + filler" pattern the
// game-invite flow already uses elsewhere.
function buildParticipants(user, invitedIds = []) {
  const invited = invitedIds.map(mockUser).filter(Boolean);
  const invitedIdSet = new Set(invited.map((u) => u.id));
  const filler = MOCK_USERS.filter((u) => !invitedIdSet.has(u.id)).slice(0, Math.max(0, 5 - invited.length));
  const others = [...invited, ...filler];
  return [
    {
      userId: 'me',
      displayName: user?.displayName || 'You',
      avatarInitial: (user?.displayName || 'U').charAt(0).toUpperCase(),
      isMe: true,
      micOn: true,
      speaking: false,
      handRaised: false,
    },
    ...others.map((u) => ({
      userId: u.id,
      displayName: u.displayName,
      avatarInitial: u.avatarInitial,
      isMe: false,
      micOn: true,
      speaking: false,
      handRaised: false,
    })),
  ];
}

export default function LiveRoom() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { joinRoom, leaveRoom } = useCall();
  const { friends } = useSocial();
  const { showToast } = useToast();

  const [room, setRoom] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(false);
  const [handRaised, setHandRaised] = useState(false);
  const [locked, setLocked] = useState(false);
  const [menuOpenFor, setMenuOpenFor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [lockedOut, setLockedOut] = useState(false);
  const [gamePickerOpen, setGamePickerOpen] = useState(false);
  const [activeGame, setActiveGame] = useState(null);
  const [invitePickerOpen, setInvitePickerOpen] = useState(false);

  const isHost = Boolean(room?.hostedByMe);
  const ActiveGameComponent = activeGame ? GAME_COMPONENTS[activeGame] : null;

  useEffect(() => {
    let active = true;
    setLoading(true);
    setNotFound(false);
    setLockedOut(false);
    roomsApi
      .get(id)
      .then((r) => {
        if (!active) return;
        if (r.locked && !r.hostedByMe) {
          setLockedOut(true);
          return;
        }
        setRoom(r);
        setLocked(Boolean(r.locked));
        setParticipants(buildParticipants(user, r.invited?.map((u) => u.id)));
        joinRoom(r);
        if (location.state?.autoOpenGame) setActiveGame(location.state.autoOpenGame);
      })
      .catch(() => {
        if (active) setNotFound(true);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
      leaveRoom();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // Simulate speaking activity so the ring animation has something to show.
  useEffect(() => {
    const interval = setInterval(() => {
      setParticipants((prev) => {
        if (!prev.length) return prev;
        const speakerIdx = Math.floor(Math.random() * prev.length);
        return prev.map((p, i) => ({
          ...p,
          speaking: i === speakerIdx && (p.isMe ? micOn : p.micOn),
        }));
      });
    }, 1800);
    return () => clearInterval(interval);
  }, [micOn]);

  useEffect(() => {
    setParticipants((prev) =>
      prev.map((p) => (p.isMe ? { ...p, handRaised } : p))
    );
  }, [handRaised]);

  function handleLeave() {
    navigate(-1); // unmount triggers the effect cleanup's leaveRoom()
  }

  async function handleEndRoom() {
    if (!window.confirm("End this room for everyone? This can't be undone.")) return;
    try {
      await roomsApi.end(room.id);
      showToast('Room ended');
      navigate(-1);
    } catch (err) {
      showToast(err.message || 'Could not end the room');
    }
  }

  async function handleToggleLock() {
    const next = !locked;
    try {
      await roomsApi.setLocked(room.id, next);
      setLocked(next);
      showToast(next ? 'Room locked — no new joins' : 'Room unlocked');
    } catch (err) {
      showToast(err.message || 'Could not update room');
    }
  }

  async function handleInviteFriend(friend) {
    try {
      const updated = await roomsApi.invite(room.id, [friend.id]);
      setRoom(updated);
      showToast(`Invited ${friend.displayName}`);
    } catch (err) {
      showToast(err.message || 'Could not invite friend');
    }
  }

  function handleMute(userId) {
    setParticipants((prev) =>
      prev.map((p) => (p.userId === userId ? { ...p, micOn: !p.micOn } : p))
    );
    setMenuOpenFor(null);
  }

  function handleKick(userId) {
    const target = participants.find((p) => p.userId === userId);
    setMenuOpenFor(null);
    if (!target) return;
    if (!window.confirm(`Remove ${target.displayName} from the room?`)) return;
    setParticipants((prev) => prev.filter((p) => p.userId !== userId));
    showToast(`${target.displayName} was removed from the room`);
  }

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 80 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="empty-state">
        <div className="emoji">🚪</div>
        <h3>Room not found</h3>
        <p>This room may have ended, or the link is invalid.</p>
        <button className="btn btn-primary" onClick={() => navigate('/rooms')}>
          Back to Rooms
        </button>
      </div>
    );
  }

  if (lockedOut) {
    return (
      <div className="empty-state">
        <div className="emoji">🔒</div>
        <h3>This room is locked</h3>
        <p>The host has locked the room to new joins.</p>
        <button className="btn btn-primary" onClick={() => navigate('/rooms')}>
          Back to Rooms
        </button>
      </div>
    );
  }

  if (room?.isWatchParty) {
    return (
      <WatchPartyRoom
        // Force a remount when navigating from one party straight into
        // another (e.g. "Schedule Another") — without this, React reuses
        // the same instance across the route change and its internal
        // state (participants, now-playing video, invited list) stays
        // stuck on the previous party since it's only ever seeded once
        // via useState initializers.
        key={room.id}
        room={room}
        isHost={isHost}
        locked={locked}
        onToggleLock={handleToggleLock}
        onLeave={handleLeave}
        localVideoUrl={location.state?.localVideoUrl}
      />
    );
  }

  return (
    <div className={styles.wrap}>
      <div className="section-head">
        <h2>
          {room?.title || 'Live room'}
          {room?.tag && <span className={styles.tagPill}>{room.tag}</span>}
          {locked && <span className={styles.lockedTag}>🔒 Locked</span>}
        </h2>
        <span>{participants.length} in the room</span>
      </div>

      {room?.invited?.length > 0 && (
        <div style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 12 }}>
          Invited: {room.invited.map((u) => u.displayName).join(', ')}
        </div>
      )}

      <div className={styles.grid}>
        {participants.map((p) => (
          <div key={p.userId} className={styles.tile}>
            <div className={styles.ringWrap}>
              <SpeakingRing
                initial={p.avatarInitial}
                active={p.isMe ? micOn && p.speaking : p.micOn && p.speaking}
                muted={p.isMe ? !micOn : !p.micOn}
                size={76}
              />
              {isHost && !p.isMe && (
                <div className={styles.hostMenuWrap}>
                  <button
                    className={styles.hostMenuBtn}
                    onClick={() => setMenuOpenFor((v) => (v === p.userId ? null : p.userId))}
                    aria-label={`Host controls for ${p.displayName}`}
                  >
                    ⋯
                  </button>
                  {menuOpenFor === p.userId && (
                    <div className={styles.hostMenu}>
                      <button onClick={() => handleMute(p.userId)}>
                        {p.micOn ? 'Mute' : 'Unmute'}
                      </button>
                      <button className={styles.hostMenuDanger} onClick={() => handleKick(p.userId)}>
                        Kick
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className={styles.tileName}>
              {p.isMe ? 'You' : p.displayName}
              {p.handRaised && ' ✋'}
            </div>
            {p.isMe && camOn && <div className={styles.camTag}>📹 Camera on</div>}
          </div>
        ))}
      </div>

      <div className={styles.controls}>
        <button
          className={`${styles.ctrlBtn} ${!micOn ? styles.ctrlOff : ''}`}
          onClick={() => setMicOn((v) => !v)}
          aria-label="Toggle microphone"
        >
          {micOn ? '🎙️' : '🔇'}
        </button>
        <button
          className={`${styles.ctrlBtn} ${!camOn ? styles.ctrlOff : ''}`}
          onClick={() => setCamOn((v) => !v)}
          aria-label="Toggle camera"
        >
          {camOn ? '📹' : '📷'}
        </button>
        <button
          className={`${styles.ctrlBtn} ${handRaised ? styles.ctrlActive : ''}`}
          onClick={() => setHandRaised((v) => !v)}
          aria-label="Raise hand"
        >
          ✋
        </button>
        {isHost && (
          <button
            className={`${styles.ctrlBtn} ${locked ? styles.ctrlActive : ''}`}
            onClick={handleToggleLock}
            aria-label="Lock room"
          >
            {locked ? '🔒' : '🔓'}
          </button>
        )}
        {isHost && (
          <div className={styles.gameMenuWrap}>
            <button
              className={styles.ctrlBtn}
              onClick={() => setInvitePickerOpen((v) => !v)}
              aria-label="Invite friends to this room"
            >
              ➕
            </button>
            {invitePickerOpen && (
              <div className={styles.gameMenu}>
                {friends.filter((f) => !room?.invited?.some((u) => u.id === f.id)).length ? (
                  friends
                    .filter((f) => !room?.invited?.some((u) => u.id === f.id))
                    .map((f) => (
                      <button key={f.id} onClick={() => handleInviteFriend(f)}>
                        <span className="avatar-sm" style={{ width: 22, height: 22, fontSize: 10 }}>
                          {f.avatarInitial}
                        </span>
                        {f.displayName}
                      </button>
                    ))
                ) : (
                  <div style={{ padding: '9px 10px', fontSize: 12, color: 'var(--text-dim)' }}>
                    Everyone's already invited
                  </div>
                )}
              </div>
            )}
          </div>
        )}
        <div className={styles.gameMenuWrap}>
          <button
            className={styles.ctrlBtn}
            onClick={() => setGamePickerOpen((v) => !v)}
            aria-label="Play a game with this room"
          >
            🎮
          </button>
          {gamePickerOpen && (
            <div className={styles.gameMenu}>
              {GAMES.map((g) => (
                <button
                  key={g.id}
                  onClick={() => {
                    setActiveGame(g.id);
                    setGamePickerOpen(false);
                  }}
                >
                  <span>{g.icon}</span>
                  {g.title}
                </button>
              ))}
            </div>
          )}
        </div>
        <button className={`${styles.ctrlBtn} ${styles.leaveBtn}`} onClick={handleLeave}>
          Leave
        </button>
        {isHost && (
          <button className={`${styles.ctrlBtn} ${styles.endBtn}`} onClick={handleEndRoom}>
            End room
          </button>
        )}
      </div>

      {ActiveGameComponent && (
        <ActiveGameComponent
          participants={participants.filter((p) => !p.isMe)}
          user={user}
          onClose={() => setActiveGame(null)}
        />
      )}
    </div>
  );
}
