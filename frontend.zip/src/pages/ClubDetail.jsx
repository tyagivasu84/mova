import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { clubsApi, FORUM_TAGS } from '../api/clubs';
import { useToast } from '../context/ToastContext';
import MessageList from '../components/MessageList';
import ThreadPanel from '../components/ThreadPanel';
import AiSummaryButton from '../components/AiSummaryButton';
import EmojiPicker from '../components/EmojiPicker';
import ClubChannelSidebar from '../components/ClubChannelSidebar';
import ClubVoiceChannel from '../components/ClubVoiceChannel';
import RoleBadge from '../components/RoleBadge';
import PollCard from '../components/PollCard';
import EventCard from '../components/EventCard';
import styles from './ClubDetail.module.css';

const TABS = [
  { id: 'chat', label: 'Chat' },
  { id: 'forum', label: 'Forum' },
  { id: 'polls', label: 'Polls' },
  { id: 'events', label: 'Events' },
  { id: 'media', label: 'Media' },
  { id: 'members', label: 'Members' },
];

// A handful of placeholder photo picks for the "share an image" flow —
// no real file upload exists, so this stands in for it (same spirit as
// PosterCard's seeded picsum placeholders).
const IMAGE_PICKS = ['popcorn', 'movie-night', 'controller', 'vinyl', 'camera', 'sunset'];

// Shared by the Forum/Polls/Events "new ___" forms so the same input look
// isn't hand-rolled four separate times.
const fieldStyle = {
  width: '100%',
  background: 'var(--bg-raised)',
  border: '1px solid var(--border)',
  borderRadius: 8,
  padding: '10px 12px',
  color: '#fff',
  fontSize: 13,
  marginBottom: 10,
};

function ChatTab({ club }) {
  const [activeChannelId, setActiveChannelId] = useState(club.channels[0]?.id);
  const [messages, setMessages] = useState([]);
  const [value, setValue] = useState('');
  const [threadMessage, setThreadMessage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showImagePicker, setShowImagePicker] = useState(false);

  const activeVoiceChannel = club.voiceChannels?.find((c) => c.id === activeChannelId);
  const activeTextChannel = club.channels.find((c) => c.id === activeChannelId);

  useEffect(() => {
    if (!activeChannelId || activeVoiceChannel) return;
    setLoading(true);
    clubsApi
      .channelMessages(activeChannelId)
      .then(setMessages)
      .catch(() => setMessages([]))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeChannelId]);

  async function handleSend(e) {
    e.preventDefault();
    if (!value.trim()) return;
    const msg = await clubsApi.sendChannelMessage(activeChannelId, value.trim());
    setMessages((prev) => [...prev, msg]);
    setValue('');
  }

  async function handleSendImage(seed) {
    setShowImagePicker(false);
    const image = `https://picsum.photos/seed/${seed}/360/240`;
    const msg = await clubsApi.sendChannelMessage(activeChannelId, '📷 Shared an image', {
      type: 'image',
      image,
    });
    setMessages((prev) => [...prev, msg]);
  }

  async function handleReact(messageId, emoji) {
    const updated = await clubsApi.reactChannelMessage(activeChannelId, messageId, emoji);
    setMessages((prev) => prev.map((m) => (m.id === messageId ? updated : m)));
  }

  async function handleReply(messageId, body) {
    const updated = await clubsApi.replyChannelMessage(activeChannelId, messageId, body);
    setMessages((prev) => prev.map((m) => (m.id === messageId ? updated : m)));
    setThreadMessage(updated);
  }

  return (
    <div className={styles.chatWrap}>
      <ClubChannelSidebar
        channels={club.channels}
        voiceChannels={club.voiceChannels}
        activeId={activeChannelId}
        onSelect={setActiveChannelId}
      />

      {activeVoiceChannel ? (
        <div className={styles.chatPane}>
          <ClubVoiceChannel
            channel={activeVoiceChannel}
            club={club}
            onLeave={() => setActiveChannelId(club.channels[0]?.id)}
          />
        </div>
      ) : (
        <div className={styles.chatPane}>
          <div className={styles.chatHeader}>
            <h3 style={{ fontSize: 14 }}># {activeTextChannel?.name}</h3>
            <div style={{ marginLeft: 'auto' }}>
              <AiSummaryButton messages={messages} />
            </div>
          </div>

          {loading ? (
            <div style={{ display: 'grid', placeItems: 'center', padding: 40 }}>
              <div className="spinner" />
            </div>
          ) : (
            <MessageList messages={messages} onReact={handleReact} onOpenThread={setThreadMessage} />
          )}

          <div className={styles.chatComposer}>
            <EmojiPicker emojiSet={club.emojiSet} onPick={(e) => setValue((v) => v + e)} />
            <form className={styles.chatComposerRow} onSubmit={handleSend}>
              <div className={styles.imagePickerWrap}>
                <button
                  type="button"
                  className={styles.imagePickerBtn}
                  onClick={() => setShowImagePicker((v) => !v)}
                  aria-label="Share an image"
                >
                  📷
                </button>
                {showImagePicker && (
                  <div className={styles.imagePickerMenu}>
                    {IMAGE_PICKS.map((seed) => (
                      <img
                        key={seed}
                        src={`https://picsum.photos/seed/${seed}/80/80`}
                        alt=""
                        onClick={() => handleSendImage(seed)}
                      />
                    ))}
                  </div>
                )}
              </div>
              <input
                className={styles.chatInput}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="Message #general… ||spoiler|| to blur"
              />
              <button className="btn btn-primary" type="submit">
                Send
              </button>
            </form>
          </div>
        </div>
      )}

      {threadMessage && (
        <ThreadPanel
          message={threadMessage}
          onClose={() => setThreadMessage(null)}
          onReply={handleReply}
        />
      )}
    </div>
  );
}

function ForumTab({ club }) {
  const [posts, setPosts] = useState([]);
  const [filterTag, setFilterTag] = useState('All');
  const [showNew, setShowNew] = useState(false);
  const [tag, setTag] = useState(FORUM_TAGS[0]);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [replyDrafts, setReplyDrafts] = useState({});
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    clubsApi.forumPosts(club.id).then(setPosts).catch(() => setPosts([])).finally(() => setLoading(false));
  }

  useEffect(load, [club.id]);

  async function handleCreate(e) {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;
    await clubsApi.createForumPost(club.id, { tag, title: title.trim(), body: body.trim() });
    setTitle('');
    setBody('');
    setShowNew(false);
    load();
  }

  async function handleUpvote(postId) {
    const updated = await clubsApi.upvoteForumPost(club.id, postId);
    setPosts((prev) => prev.map((p) => (p.id === postId ? updated : p)));
  }

  async function handleReply(postId) {
    const draft = (replyDrafts[postId] || '').trim();
    if (!draft) return;
    const updated = await clubsApi.replyForumPost(club.id, postId, draft);
    setPosts((prev) => prev.map((p) => (p.id === postId ? updated : p)));
    setReplyDrafts((prev) => ({ ...prev, [postId]: '' }));
  }

  const visible = filterTag === 'All' ? posts : posts.filter((p) => p.tag === filterTag);

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16, alignItems: 'center' }}>
        {['All', ...FORUM_TAGS].map((t) => (
          <button
            key={t}
            className={filterTag === t ? 'btn btn-primary' : 'btn btn-ghost'}
            style={{ fontSize: 11.5, padding: '6px 12px' }}
            onClick={() => setFilterTag(t)}
          >
            {t}
          </button>
        ))}
        <button
          className="btn btn-ghost"
          style={{ fontSize: 11.5, marginLeft: 'auto' }}
          onClick={() => setShowNew((v) => !v)}
        >
          {showNew ? 'Cancel' : '+ New post'}
        </button>
      </div>

      {showNew && (
        <form onSubmit={handleCreate} className={styles.forumPost}>
          <select value={tag} onChange={(e) => setTag(e.target.value)} style={fieldStyle}>
            {FORUM_TAGS.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Post title"
            style={fieldStyle}
          />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="What's on your mind?"
            rows={3}
            style={{ ...fieldStyle, resize: 'vertical' }}
          />
          <button className="btn btn-primary" type="submit">
            Post
          </button>
        </form>
      )}

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : visible.length ? (
        visible.map((p) => (
          <div key={p.id} className={styles.forumPost}>
            <span className={styles.forumTag}>{p.tag}</span>
            <div className={styles.forumTitle}>{p.title}</div>
            <div className={styles.forumBody}>{p.body}</div>
            <div className={styles.forumFooter}>
              <span>{p.author?.displayName || 'You'}</span>
              <button
                className={`btn btn-ghost ${p.upvotes.includes('me') ? styles.upvoted : ''}`}
                style={{ fontSize: 11, padding: '4px 10px' }}
                onClick={() => handleUpvote(p.id)}
              >
                ▲ {p.upvotes.length}
              </button>
              <span>{p.replies.length} replies</span>
            </div>
            {p.replies.length > 0 && (
              <div style={{ marginTop: 10, paddingLeft: 14, borderLeft: '2px solid var(--border)' }}>
                {p.replies.map((r) => (
                  <div key={r.id} style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 6 }}>
                    <b>{r.author?.displayName || 'You'}:</b> {r.body}
                  </div>
                ))}
              </div>
            )}
            <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
              <input
                value={replyDrafts[p.id] || ''}
                onChange={(e) => setReplyDrafts((prev) => ({ ...prev, [p.id]: e.target.value }))}
                placeholder="Reply…"
                style={{
                  flex: 1,
                  background: 'var(--bg-raised)',
                  border: '1px solid var(--border)',
                  borderRadius: 100,
                  padding: '7px 12px',
                  color: '#fff',
                  fontSize: 12,
                }}
              />
              <button className="btn btn-ghost" style={{ fontSize: 11.5 }} onClick={() => handleReply(p.id)}>
                Reply
              </button>
            </div>
          </div>
        ))
      ) : (
        <div className="empty-state">
          <div className="emoji">📝</div>
          <h3>No posts yet</h3>
          <p>Start a Theory, Question, Fan Art, or Discussion thread.</p>
        </div>
      )}
    </div>
  );
}

function PollsTab({ club }) {
  const { showToast } = useToast();
  const [polls, setPolls] = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [question, setQuestion] = useState('');
  const [optionsText, setOptionsText] = useState('');
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    clubsApi.polls(club.id).then(setPolls).catch(() => setPolls([])).finally(() => setLoading(false));
  }

  useEffect(load, [club.id]);

  async function handleVote(pollId, optionId) {
    const updated = await clubsApi.vote(club.id, pollId, optionId);
    setPolls((prev) => prev.map((p) => (p.id === pollId ? updated : p)));
  }

  async function handleCreate(e) {
    e.preventDefault();
    const opts = optionsText.split(',').map((o) => o.trim()).filter(Boolean);
    if (!question.trim() || opts.length < 2) {
      showToast('Add a question and at least 2 options');
      return;
    }
    await clubsApi.createPoll(club.id, question.trim(), opts);
    setQuestion('');
    setOptionsText('');
    setShowNew(false);
    load();
  }

  return (
    <div>
      <button
        className="btn btn-ghost"
        style={{ fontSize: 11.5, marginBottom: 16 }}
        onClick={() => setShowNew((v) => !v)}
      >
        {showNew ? 'Cancel' : '+ New poll'}
      </button>

      {showNew && (
        <form onSubmit={handleCreate} className={styles.forumPost}>
          <input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Poll question"
            style={fieldStyle}
          />
          <input
            value={optionsText}
            onChange={(e) => setOptionsText(e.target.value)}
            placeholder="Options, comma separated"
            style={fieldStyle}
          />
          <button className="btn btn-primary" type="submit">
            Create poll
          </button>
        </form>
      )}

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : polls.length ? (
        polls.map((p) => <PollCard key={p.id} poll={p} onVote={handleVote} />)
      ) : (
        <div className="empty-state">
          <div className="emoji">🗳️</div>
          <h3>No polls yet</h3>
        </div>
      )}
    </div>
  );
}

function EventsTab({ club }) {
  const { showToast } = useToast();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  function load() {
    setLoading(true);
    clubsApi.events(club.id).then(setEvents).catch(() => setEvents([])).finally(() => setLoading(false));
  }

  useEffect(load, [club.id]);

  async function handleCreate(e) {
    e.preventDefault();
    if (!title.trim() || !date) {
      showToast('Add a title and date');
      return;
    }
    await clubsApi.createEvent(club.id, {
      title: title.trim(),
      scheduledAt: new Date(`${date}T${time || '19:00'}`).toISOString(),
    });
    setTitle('');
    setDate('');
    setTime('');
    setShowNew(false);
    load();
  }

  return (
    <div>
      <button
        className="btn btn-ghost"
        style={{ fontSize: 11.5, marginBottom: 16 }}
        onClick={() => setShowNew((v) => !v)}
      >
        {showNew ? 'Cancel' : '+ New event'}
      </button>

      {showNew && (
        <form onSubmit={handleCreate} className={styles.forumPost}>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Event title"
            style={fieldStyle}
          />
          <div style={{ display: 'flex', gap: 10 }}>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              style={{ ...fieldStyle, flex: 1 }}
            />
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              style={{ ...fieldStyle, flex: 1 }}
            />
          </div>
          <button className="btn btn-primary" type="submit">
            Create event
          </button>
        </form>
      )}

      {loading ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
          <div className="spinner" />
        </div>
      ) : events.length ? (
        <div>
          {events.map((e) => (
            <EventCard key={e.id} event={e} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">📅</div>
          <h3>No upcoming events</h3>
        </div>
      )}
    </div>
  );
}

function MediaTab({ club }) {
  const [media, setMedia] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    clubsApi.mediaForClub(club.id).then(setMedia).catch(() => setMedia([])).finally(() => setLoading(false));
  }, [club.id]);

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (!media.length) {
    return (
      <div className="empty-state">
        <div className="emoji">🖼️</div>
        <h3>No media yet</h3>
        <p>Images shared in chat will show up here.</p>
      </div>
    );
  }

  return (
    <div className={styles.mediaGrid}>
      {media.map((m) => (
        <div key={m.id} className={styles.mediaItem}>
          <img src={m.image} alt="" loading="lazy" />
          <div className={styles.mediaMeta}>
            {m.author?.displayName || 'You'} · #{m.channelName}
          </div>
        </div>
      ))}
    </div>
  );
}

function JoinGate({ club, onJoin, joining }) {
  return (
    <div className="empty-state">
      <div className="emoji">🔒</div>
      <h3>Join to participate</h3>
      <p>Join {club.name} to chat, post, vote, and create events.</p>
      <button className="btn btn-primary" onClick={onJoin} disabled={joining}>
        {joining ? 'Joining…' : 'Join club'}
      </button>
    </div>
  );
}

function MembersTab({ club }) {
  return (
    <div>
      {club.members.map((m) => (
        <div key={m.userId} className={styles.memberRow}>
          <span className="avatar-sm" style={{ width: 30, height: 30, fontSize: 12 }}>
            {m.userId === 'me' ? 'Y' : m.user?.avatarInitial || '?'}
          </span>
          <span className={styles.memberName}>
            {m.userId === 'me' ? 'You' : m.user?.displayName || 'Unknown member'}
          </span>
          <RoleBadge role={m.role} />
        </div>
      ))}
    </div>
  );
}

async function copyInviteLink(club, showToast) {
  const link = `https://club.app/invite/${club.inviteCode}`;
  if (!navigator.clipboard?.writeText) {
    showToast('Could not copy — clipboard not available');
    return;
  }
  try {
    await navigator.clipboard.writeText(link);
    showToast('Invite link copied');
  } catch {
    showToast('Could not copy link');
  }
}

export default function ClubDetail() {
  const { id } = useParams();
  const { showToast } = useToast();
  const [club, setClub] = useState(null);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);
  const [tab, setTab] = useState('chat');

  function load() {
    clubsApi
      .get(id)
      .then(setClub)
      .catch(() => setClub(null))
      .finally(() => setLoading(false));
  }

  useEffect(load, [id]);

  async function handleJoin() {
    setJoining(true);
    try {
      const updated = await clubsApi.join(id);
      setClub(updated);
      showToast(`Joined ${updated.name}`);
    } catch (err) {
      showToast(err.message || 'Could not join club');
    } finally {
      setJoining(false);
    }
  }

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 80 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (!club) {
    return (
      <div className="empty-state">
        <div className="emoji">🏛️</div>
        <h3>Club not found</h3>
      </div>
    );
  }

  return (
    <div>
      <div className={styles.banner} style={{ '--ca': club.accent || '#3a1420' }} />
      <div className={styles.header}>
        <div className="avatar-sm" style={{ width: 64, height: 64, fontSize: 24 }}>
          {club.avatarInitial}
        </div>
        <div className={styles.headerBody}>
          <div className={styles.name}>
            {club.name}
            {club.verified && <span title="Verified">✅</span>}
            <span className={styles.levelBadge} title={`Level ${club.level}`}>
              {club.badge} Lv.{club.level}
            </span>
          </div>
          <div className={styles.desc}>{club.description}</div>
          <div style={{ fontSize: 11.5, color: 'var(--text-dim)', marginTop: 4 }}>
            {club.onlineCount} online · {club.memberCount} members
          </div>
        </div>
        <button className="btn btn-ghost" onClick={() => copyInviteLink(club, showToast)}>
          🔗 Invite
        </button>
        {!club.isMember ? (
          <button className="btn btn-primary" onClick={handleJoin} disabled={joining}>
            {joining ? 'Joining…' : 'Join club'}
          </button>
        ) : (
          <RoleBadge role={club.myRole} />
        )}
      </div>

      <div className={styles.tabs}>
        {TABS.map((t) => (
          <button
            key={t.id}
            className={`${styles.tab} ${tab === t.id ? styles.tabActive : ''}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {['chat', 'forum', 'polls', 'events', 'media'].includes(tab) && !club.isMember ? (
        <JoinGate club={club} onJoin={handleJoin} joining={joining} />
      ) : (
        <>
          {tab === 'chat' && <ChatTab club={club} />}
          {tab === 'forum' && <ForumTab club={club} />}
          {tab === 'polls' && <PollsTab club={club} />}
          {tab === 'events' && <EventsTab club={club} />}
          {tab === 'media' && <MediaTab club={club} />}
        </>
      )}
      {tab === 'members' && <MembersTab club={club} />}
    </div>
  );
}
