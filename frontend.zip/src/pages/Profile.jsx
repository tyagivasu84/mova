import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAppState } from '../context/AppStateContext';
import { useCall } from '../context/CallContext';
import { useSocial } from '../context/SocialContext';
import { useToast } from '../context/ToastContext';
import { verificationApi } from '../api/verification';
import { mockUser } from '../api/mock/fixtures/users';
import { gameStatsApi } from '../api/gameStats';
import { settingsApi } from '../api/settings';
import { clubsApi } from '../api/clubs';
import VerifiedBadge from '../components/VerifiedBadge';
import VerifyModal from '../components/VerifyModal';
import AchievementsGrid from '../components/AchievementsGrid';
import GiftModal from '../components/GiftModal';
import styles from './Profile.module.css';

const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'games', label: 'Games' },
  { id: 'communities', label: 'Communities' },
  { id: 'friends', label: 'Friends' },
];

function GamesTab() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    gameStatsApi.list().then(setGames).catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 40 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (!games.length) {
    return (
      <div className="empty-state">
        <div className="emoji">🎮</div>
        <h3>No games played yet</h3>
        <p>Join a gaming room to start building your stats.</p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {games.map((g) => (
        <div
          key={g.game}
          style={{
            display: 'flex',
            gap: 16,
            alignItems: 'center',
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            borderRadius: 12,
            padding: 16,
          }}
        >
          <div
            style={{
              textAlign: 'center',
              minWidth: 54,
              padding: '8px 4px',
              background: 'var(--bg-raised)',
              borderRadius: 10,
              border: '1px solid var(--border)',
              fontSize: 22,
            }}
          >
            {g.icon}
          </div>
          <div style={{ flex: 1 }}>
            <h3 style={{ fontSize: 15, marginBottom: 3 }}>{g.game}</h3>
            <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>
              {g.hoursPlayed}h played · last played {g.lastPlayed}
            </div>
          </div>
          {g.favorite && (
            <div style={{ fontSize: 11.5, color: 'var(--gold)', fontWeight: 700 }}>★ Favorite</div>
          )}
        </div>
      ))}
    </div>
  );
}

function CommunitiesTab() {
  const navigate = useNavigate();
  const [clubs, setClubs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    clubsApi
      .list()
      .then((list) => setClubs(list.filter((c) => c.isMember)))
      .catch(() => setClubs([]))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 40 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (!clubs.length) {
    return (
      <div className="empty-state">
        <div className="emoji">🏛️</div>
        <h3>No communities yet</h3>
        <p>Join a club to see it here.</p>
      </div>
    );
  }

  return (
    <div className="rooms-grid">
      {clubs.map((c) => (
        <div
          key={c.id}
          className={styles.listRow}
          style={{ cursor: 'pointer' }}
          onClick={() => navigate(`/clubs/${c.id}`)}
        >
          <div className="avatar-sm" style={{ width: 44, height: 44, fontSize: 16 }}>
            {c.avatarInitial}
          </div>
          <div style={{ flex: 1 }}>
            <h3 style={{ fontSize: 15, marginBottom: 3 }}>{c.name}</h3>
            <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>{c.memberCount} members</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function FriendsTab() {
  const navigate = useNavigate();
  const { friends } = useSocial();

  if (!friends.length) {
    return (
      <div className="empty-state">
        <div className="emoji">🧑‍🤝‍🧑</div>
        <h3>No friends yet</h3>
        <p>Find people on the Friends page.</p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {friends.map((f) => (
        <div
          key={f.id}
          className={styles.listRow}
          style={{ cursor: 'pointer' }}
          onClick={() => navigate(`/profile/${f.id}`)}
        >
          <span className="avatar-sm">{f.avatarInitial}</span>
          <div style={{ flex: 1 }}>
            <h3 style={{ fontSize: 15, marginBottom: 3 }}>{f.displayName}</h3>
            <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>@{f.username}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className={styles.statCard}>
      <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--gold)' }}>{value}</div>
      <div style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 4 }}>{label}</div>
    </div>
  );
}

function OtherProfile({ otherUser }) {
  const { friends } = useSocial();
  const [showGift, setShowGift] = useState(false);

  const isFriend = friends.some((f) => f.id === otherUser.id);
  const giftBlocked = otherUser.dmOnlyFriends && !isFriend;

  return (
    <div>
      <div className={styles.banner} />
      <div className={styles.header} style={{ marginBottom: 24 }}>
        <div className="avatar-sm" style={{ width: 84, height: 84, fontSize: 32 }}>
          {otherUser.avatarInitial}
        </div>
        <div style={{ flex: 1, minWidth: 220 }}>
          <h1 className={styles.headerName}>
            {otherUser.displayName}
            {otherUser.verified && <VerifiedBadge size={18} />}
          </h1>
          <div style={{ color: 'var(--text-dim)', fontSize: 13, marginBottom: 4 }}>
            @{otherUser.username}
          </div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>{otherUser.bio}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <button className="btn btn-primary" onClick={() => setShowGift(true)} disabled={giftBlocked}>
            🎁 Send gift
          </button>
          {giftBlocked && (
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 6, maxWidth: 160 }}>
              Only accepts gifts from friends
            </div>
          )}
        </div>
      </div>

      {showGift && <GiftModal toName={otherUser.displayName} onClose={() => setShowGift(false)} />}
    </div>
  );
}

export default function Profile() {
  const { userId } = useParams();
  const { user, updateProfile } = useAuth();
  const { points, shopOwned } = useAppState();
  const { activeRoom } = useCall();
  const { showToast } = useToast();

  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [username, setUsername] = useState(user?.username || '');
  const [saving, setSaving] = useState(false);
  const [verified, setVerified] = useState(false);
  const [showVerify, setShowVerify] = useState(false);
  const [tab, setTab] = useState('overview');
  const [isPrivate, setIsPrivate] = useState(false);

  const currentRoomTopic = activeRoom ? activeRoom.tag || activeRoom.title : null;

  useEffect(() => {
    verificationApi.status().then(setVerified).catch(() => {});
    setIsPrivate(Boolean(settingsApi.get().privateProfile));
  }, []);

  if (userId) {
    const otherUser = mockUser(userId);
    if (otherUser) return <OtherProfile otherUser={otherUser} />;
    return (
      <div className="empty-state">
        <div className="emoji">🔍</div>
        <h3>User not found</h3>
        <p>This profile may have been removed, or the link is invalid.</p>
      </div>
    );
  }

  async function handleSave() {
    setSaving(true);
    try {
      await updateProfile({ displayName, username });
      showToast('Profile updated ✓');
      setEditing(false);
    } catch (err) {
      showToast(err.message || 'Could not update profile');
    } finally {
      setSaving(false);
    }
  }

  const initial = (user?.displayName || 'U').charAt(0).toUpperCase();

  return (
    <div>
      <div className={styles.banner} />
      <div className={styles.header}>
        <div className="avatar-sm" style={{ width: 84, height: 84, fontSize: 32 }}>
          {initial}
        </div>
        <div style={{ flex: 1, minWidth: 220 }}>
          <h1 className={styles.headerName}>
            {user?.displayName}
            {verified && <VerifiedBadge size={18} />}
            {isPrivate && (
              <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-dim)' }}>
                🔒 Private
              </span>
            )}
          </h1>
          <div style={{ color: 'var(--text-dim)', fontSize: 13, marginBottom: 4 }}>
            {user?.username}
          </div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>
            {isPrivate ? '•••••••@•••••.com' : user?.email}
          </div>
          {/* Same dim small-text slot RoomCard uses for its "X here" line. */}
          {currentRoomTopic && (
            <div style={{ color: 'var(--text-dim)', fontSize: 12.5, marginTop: 4 }}>
              🎯 In: {currentRoomTopic}
            </div>
          )}
        </div>
        {!verified && (
          <button className="btn btn-ghost" onClick={() => setShowVerify(true)}>
            Get verified
          </button>
        )}
        <button className="btn btn-ghost" onClick={() => setEditing((v) => !v)}>
          {editing ? 'Cancel' : 'Edit profile'}
        </button>
      </div>

      {showVerify && (
        <VerifyModal onClose={() => setShowVerify(false)} onVerified={() => setVerified(true)} />
      )}

      {editing && (
        <div className={styles.editCard}>
          <label style={{ fontSize: 12, color: 'var(--text-dim)' }}>Display name</label>
          <input
            className={styles.input}
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
          />
          <label style={{ fontSize: 12, color: 'var(--text-dim)' }}>Username</label>
          <input
            className={styles.input}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <button
            className="btn btn-primary"
            style={{ width: '100%', marginTop: 8 }}
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? 'Saving…' : 'Save changes'}
          </button>
        </div>
      )}

      <div className={styles.tabs}>
        {TABS.map((t) => (
          <button
            key={t.id}
            className={`${styles.tab} ${tab === t.id ? styles.tabActive : ''}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
              gap: 16,
            }}
          >
            <Stat label="Points" value={`★ ${points.toLocaleString()}`} />
            <Stat label="Items owned" value={shopOwned.length} />
            <Stat
              label="Member since"
              value={new Date(user?.createdAt || Date.now()).getFullYear()}
            />
          </div>

          <div className="section-head" style={{ marginTop: 40 }}>
            <h2>Achievements</h2>
            <span>Badges you've earned on CLUB</span>
          </div>
          <AchievementsGrid />
        </>
      )}

      {tab === 'games' && <GamesTab />}
      {tab === 'communities' && <CommunitiesTab />}
      {tab === 'friends' && <FriendsTab />}
    </div>
  );
}
