import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { messagesApi } from '../api/messages';
import { clickableDivProps } from '../utils/a11y';
import MessageList from '../components/MessageList';
import MessageComposer from '../components/MessageComposer';
import ThreadPanel from '../components/ThreadPanel';
import AiSummaryButton from '../components/AiSummaryButton';
import GiftModal from '../components/GiftModal';
import styles from './Messages.module.css';

export default function Messages() {
  const navigate = useNavigate();
  const [conversations, setConversations] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [threadMessage, setThreadMessage] = useState(null);
  const [showGift, setShowGift] = useState(false);

  useEffect(() => {
    messagesApi
      .conversations()
      .then((convos) => {
        setConversations(convos);
        if (convos.length) setActiveId(convos[0].id);
      })
      .catch(() => setConversations([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!activeId) return;
    messagesApi.messages(activeId).then(setMessages).catch(() => setMessages([]));
    messagesApi.markRead(activeId).then(() => {
      setConversations((prev) => prev.map((c) => (c.id === activeId ? { ...c, read: true } : c)));
    });
  }, [activeId]);

  const active = conversations.find((c) => c.id === activeId);

  async function handleSend(body) {
    const msg = await messagesApi.send(activeId, body);
    setMessages((prev) => [...prev, msg]);
    setConversations((prev) =>
      prev
        .map((c) => (c.id === activeId ? { ...c, lastMessage: body, updatedAt: msg.createdAt } : c))
        .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
    );
  }

  async function handleGiftSent(gift) {
    const msg = await messagesApi.send(activeId, `Sent ${gift.icon} ${gift.name}`, { type: 'gift', gift });
    setMessages((prev) => [...prev, msg]);
    setConversations((prev) =>
      prev
        .map((c) =>
          c.id === activeId ? { ...c, lastMessage: `🎁 Sent ${gift.name}`, updatedAt: msg.createdAt } : c
        )
        .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
    );
  }

  async function handleReact(messageId, emoji) {
    const updated = await messagesApi.react(activeId, messageId, emoji);
    setMessages((prev) => prev.map((m) => (m.id === messageId ? updated : m)));
  }

  async function handleReply(messageId, body) {
    const updated = await messagesApi.reply(activeId, messageId, body);
    setMessages((prev) => prev.map((m) => (m.id === messageId ? updated : m)));
    setThreadMessage(updated);
  }

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 60 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (!conversations.length) {
    return (
      <div className="empty-state">
        <div className="emoji">💬</div>
        <h3>No messages yet</h3>
        <p>Join a room or add friends to start a conversation.</p>
      </div>
    );
  }

  return (
    <div className={styles.wrap}>
      <div className={styles.convoList}>
        {conversations.map((c) => (
          <div
            key={c.id}
            className={`${styles.convoItem} ${c.id === activeId ? styles.convoItemActive : ''}`}
            {...clickableDivProps(() => setActiveId(c.id))}
          >
            <span className="avatar-sm">{c.user?.avatarInitial || '?'}</span>
            <div className={styles.convoBody}>
              <div className={styles.convoName}>{c.user?.displayName || 'Unknown user'}</div>
              <div className={styles.convoLast}>{c.lastMessage}</div>
            </div>
          </div>
        ))}
      </div>

      {active && (
        <div className={styles.pane}>
          <div className={styles.paneHeader}>
            <span className="avatar-sm">{active.user?.avatarInitial || '?'}</span>
            <div
              className={styles.paneHeaderName}
              style={{ cursor: active.user ? 'pointer' : 'default' }}
              {...(active.user ? clickableDivProps(() => navigate(`/profile/${active.user.id}`)) : {})}
            >
              {active.user?.displayName || 'Unknown user'}
            </div>
            <button
              className="btn btn-ghost"
              style={{ fontSize: 12 }}
              disabled={!active.user}
              onClick={() => active.user && navigate(`/call/${active.user.id}`)}
            >
              📞 Call
            </button>
            <AiSummaryButton messages={messages} />
            <button
              className="btn btn-ghost"
              style={{ fontSize: 12 }}
              disabled={!active.user}
              onClick={() => setShowGift(true)}
            >
              🎁 Gift
            </button>
          </div>

          <div className={styles.paneScroll}>
            <MessageList messages={messages} onReact={handleReact} onOpenThread={setThreadMessage} />
          </div>

          <MessageComposer onSend={handleSend} />
        </div>
      )}

      {threadMessage && (
        <ThreadPanel
          message={threadMessage}
          onClose={() => setThreadMessage(null)}
          onReply={handleReply}
        />
      )}

      {showGift && (
        <GiftModal
          toName={active?.user?.displayName}
          onClose={() => setShowGift(false)}
          onSent={handleGiftSent}
        />
      )}
    </div>
  );
}
