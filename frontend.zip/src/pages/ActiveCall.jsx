import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCall } from '../context/CallContext';
import { mockUser } from '../api/mock/fixtures/users';
import { GAMES } from '../config/games';
import SpeakingRing from '../components/SpeakingRing';
import TwoTruthsGame from '../components/TwoTruthsGame';
import TruthOrDareGame from '../components/TruthOrDareGame';
import NeverHaveIEverGame from '../components/NeverHaveIEverGame';
import MafiaGame from '../components/MafiaGame';
import TriviaGame from '../components/TriviaGame';
import EmojiCharadesGame from '../components/EmojiCharadesGame';
import SpyfallGame from '../components/SpyfallGame';
import styles from './ActiveCall.module.css';

const GAME_COMPONENTS = {
  'two-truths': TwoTruthsGame,
  'truth-or-dare': TruthOrDareGame,
  'never-have-i-ever': NeverHaveIEverGame,
  mafia: MafiaGame,
  trivia: TriviaGame,
  'emoji-charades': EmojiCharadesGame,
  spyfall: SpyfallGame,
};

function formatDuration(s) {
  const m = String(Math.floor(s / 60)).padStart(2, '0');
  const sec = String(s % 60).padStart(2, '0');
  return `${m}:${sec}`;
}

export default function ActiveCall() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { joinRoom, leaveRoom } = useCall();
  const other = mockUser(id);

  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [speaking, setSpeaking] = useState(false);
  const [duration, setDuration] = useState(0);
  const [gamePickerOpen, setGamePickerOpen] = useState(false);
  const [activeGame, setActiveGame] = useState(null);

  const ActiveGameComponent = activeGame ? GAME_COMPONENTS[activeGame] : null;

  useEffect(() => {
    joinRoom({ id, title: other ? `Call with ${other.displayName}` : 'Active call', type: 'call' });
    return () => leaveRoom();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    const speakingInterval = setInterval(() => setSpeaking(Math.random() > 0.4), 1600);
    const durationInterval = setInterval(() => setDuration((d) => d + 1), 1000);
    return () => {
      clearInterval(speakingInterval);
      clearInterval(durationInterval);
    };
  }, []);

  return (
    <div className={styles.wrap}>
      <div className={styles.mainVideo}>
        <SpeakingRing
          initial={other?.avatarInitial || '?'}
          active={speaking}
          size={140}
          fontSize={48}
        />
        <div className={styles.callerName}>{other?.displayName || 'CLUB user'}</div>
        <div className={styles.duration}>{formatDuration(duration)}</div>
      </div>

      <div className={styles.selfPip}>
        {camOn ? (
          <div className={styles.pipCam}>📹</div>
        ) : (
          <SpeakingRing
            initial={(user?.displayName || 'U').charAt(0).toUpperCase()}
            active={micOn && speaking}
            size={64}
          />
        )}
      </div>

      <div className={styles.controls}>
        <button
          className={`${styles.ctrlBtn} ${!micOn ? styles.ctrlOff : ''}`}
          onClick={() => setMicOn((v) => !v)}
          aria-label="Toggle microphone"
        >
          {micOn ? '🎙️' : '🔇'}
        </button>
        <button
          className={`${styles.ctrlBtn} ${!camOn ? styles.ctrlOff : ''}`}
          onClick={() => setCamOn((v) => !v)}
          aria-label="Toggle camera"
        >
          {camOn ? '📹' : '📷'}
        </button>
        <div className={styles.gameMenuWrap}>
          <button
            className={styles.ctrlBtn}
            onClick={() => setGamePickerOpen((v) => !v)}
            aria-label="Play a game on this call"
          >
            🎮
          </button>
          {gamePickerOpen && (
            <div className={styles.gameMenu}>
              {GAMES.map((g) => (
                <button
                  key={g.id}
                  onClick={() => {
                    setActiveGame(g.id);
                    setGamePickerOpen(false);
                  }}
                >
                  <span>{g.icon}</span>
                  {g.title}
                </button>
              ))}
            </div>
          )}
        </div>
        <button className={`${styles.ctrlBtn} ${styles.endBtn}`} onClick={() => navigate(-1)}>
          End
        </button>
      </div>

      {ActiveGameComponent && (
        <ActiveGameComponent
          participants={other ? [{ userId: other.id }] : []}
          user={user}
          onClose={() => setActiveGame(null)}
        />
      )}
    </div>
  );
}
