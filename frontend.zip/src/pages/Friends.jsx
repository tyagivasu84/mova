import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSocial } from '../context/SocialContext';
import { useCall } from '../context/CallContext';
import { useToast } from '../context/ToastContext';
import { presenceApi, STATUS_INFO } from '../api/presence';
import { roomsApi } from '../api/rooms';
import { tasteMatchApi } from '../api/tasteMatch';
import { GAMES } from '../config/games';
import TasteMatchCard from '../components/TasteMatchCard';
import styles from './Friends.module.css';

export default function Friends() {
  const navigate = useNavigate();
  const { friends, incoming, outgoing, sendRequest, acceptRequest, declineRequest, search } =
    useSocial();
  const { activeRoom } = useCall();
  const { showToast } = useToast();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [presence, setPresence] = useState({});
  const [gamePickerFor, setGamePickerFor] = useState(null);
  const [matches, setMatches] = useState([]);

  useEffect(() => {
    presenceApi.map().then(setPresence).catch(() => {});
    tasteMatchApi.list().then(setMatches).catch(() => {});
  }, []);

  function friendStatusFor(userId) {
    if (friends.some((f) => f.id === userId)) return 'friend';
    if (outgoing.some((r) => r.toUser?.id === userId)) return 'pending';
    if (incoming.some((r) => r.fromUser?.id === userId)) return 'pending';
    return null;
  }

  async function handleAddFromMatch(match) {
    try {
      await sendRequest(match.userId);
      showToast(`Friend request sent to ${match.displayName}`);
    } catch (err) {
      showToast(err.message || 'Could not send request');
    }
  }

  function handleInviteToRoom(friend) {
    showToast(`Invited ${friend.displayName} to ${activeRoom.title}`);
  }

  // Games only ever happen live inside a Room — this creates one, invites
  // just this friend, and drops you straight in with the game already
  // open, same pattern as Home's "Invite friends" flow.
  async function handlePickGame(friend, game) {
    setGamePickerFor(null);
    try {
      const room = await roomsApi.create({
        title: `${game.title} with ${friend.displayName}`,
        tag: game.title,
        vibe: 'Casual',
        mode: 'instant',
        private: true,
        invited: [friend.id],
      });
      navigate(`/room/${room.id}`, { state: { autoOpenGame: game.id } });
    } catch (err) {
      showToast(err.message || 'Could not start a room');
    }
  }

  async function handleSearch(e) {
    e.preventDefault();
    setSearching(true);
    try {
      setResults(await search(query));
      setHasSearched(true);
    } finally {
      setSearching(false);
    }
  }

  async function handleSend(userId) {
    await sendRequest(userId);
    setResults((r) => r.filter((u) => u.id !== userId));
    showToast('Friend request sent');
  }

  async function handleAccept(id) {
    try {
      await acceptRequest(id);
      showToast('Friend request accepted');
    } catch (err) {
      showToast(err.message || 'Could not accept request');
    }
  }

  return (
    <div>
      <div className="section-head">
        <h2>Friends</h2>
        <span>Find people and manage requests</span>
      </div>

      <form className={styles.searchRow} onSubmit={handleSearch}>
        <input
          className={styles.searchInput}
          placeholder="Search by name or username"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button className="btn btn-primary" type="submit" disabled={searching}>
          Search
        </button>
      </form>

      {searching ? (
        <div style={{ display: 'grid', placeItems: 'center', padding: 30, marginBottom: 32 }}>
          <div className="spinner" />
        </div>
      ) : results.length > 0 ? (
        <div className={styles.resultsList} style={{ marginBottom: 32 }}>
          {results.map((u) => (
            <div key={u.id} className={styles.row}>
              <span className="avatar-sm">{u.avatarInitial}</span>
              <div className={styles.rowBody}>
                <div className={styles.rowName}>{u.displayName}</div>
                <div className={styles.rowMeta}>@{u.username}</div>
              </div>
              <button className="btn btn-ghost" onClick={() => handleSend(u.id)}>
                Add friend
              </button>
            </div>
          ))}
        </div>
      ) : (
        hasSearched && (
          <div className="empty-state" style={{ marginBottom: 32 }}>
            <div className="emoji">🔍</div>
            <h3>No results found</h3>
            <p>Try a different name or username.</p>
          </div>
        )
      )}

      {matches.length > 0 && (
        <>
          <div className="section-head">
            <h2>Taste Match</h2>
            <span>People whose taste lines up with yours</span>
          </div>
          <div style={{ display: 'flex', gap: 14, overflowX: 'auto', marginBottom: 32, paddingBottom: 4 }}>
            {matches.map((m) => (
              <TasteMatchCard
                key={m.userId}
                match={m}
                friendStatus={friendStatusFor(m.userId)}
                onAddFriend={handleAddFromMatch}
              />
            ))}
          </div>
        </>
      )}

      {incoming.length > 0 && (
        <>
          <div className="section-head">
            <h2>Requests</h2>
            <span>{incoming.length} pending</span>
          </div>
          <div className={styles.resultsList} style={{ marginBottom: 32 }}>
            {incoming.map((r) => (
              <div key={r.id} className={styles.row}>
                <span className="avatar-sm">{r.fromUser?.avatarInitial}</span>
                <div className={styles.rowBody}>
                  <div className={styles.rowName}>{r.fromUser?.displayName}</div>
                  <div className={styles.rowMeta}>@{r.fromUser?.username}</div>
                </div>
                <button className="btn btn-primary" onClick={() => handleAccept(r.id)}>
                  Accept
                </button>
                <button className="btn btn-ghost" onClick={() => declineRequest(r.id)}>
                  Decline
                </button>
              </div>
            ))}
          </div>
        </>
      )}

      {outgoing.length > 0 && (
        <>
          <div className="section-head">
            <h2>Sent</h2>
            <span>Waiting on a response</span>
          </div>
          <div className={styles.resultsList} style={{ marginBottom: 32 }}>
            {outgoing.map((r) => (
              <div key={r.id} className={styles.row}>
                <span className="avatar-sm">{r.toUser?.avatarInitial}</span>
                <div className={styles.rowBody}>
                  <div className={styles.rowName}>{r.toUser?.displayName}</div>
                </div>
                <span className={styles.pending}>Pending</span>
              </div>
            ))}
          </div>
        </>
      )}

      <div className="section-head">
        <h2>Your friends</h2>
        <span>{friends.length} friends</span>
      </div>
      {friends.length ? (
        <div className={styles.resultsList}>
          {friends.map((f) => {
            const p = presence[f.id] || { status: 'online' };
            const info = STATUS_INFO[p.status];
            return (
              <div key={f.id} className={`${styles.row} ${styles.friendRow}`}>
                <div
                  className={styles.friendClickable}
                  onClick={() => navigate(`/profile/${f.id}`)}
                >
                  <span className="avatar-sm">{f.avatarInitial}</span>
                  <div className={styles.rowBody}>
                    <div className={styles.rowName}>{f.displayName}</div>
                    <div className={styles.statusLine}>
                      <span className={styles.statusDot} style={{ background: info.color }} />
                      {p.activity ? `${info.icon} ${p.activity}` : info.label}
                    </div>
                  </div>
                </div>

                {activeRoom && (
                  <button className="btn btn-ghost" onClick={() => handleInviteToRoom(f)}>
                    Invite to room
                  </button>
                )}

                <div className={styles.gamePickerWrap}>
                  <button
                    className="btn btn-ghost"
                    onClick={() => setGamePickerFor((v) => (v === f.id ? null : f.id))}
                  >
                    Invite to game
                  </button>
                  {gamePickerFor === f.id && (
                    <div className={styles.gamePickerMenu}>
                      {GAMES.map((g) => (
                        <button key={g.id} onClick={() => handlePickGame(f, g)}>
                          <span>{g.icon}</span>
                          {g.title}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="empty-state">
          <div className="emoji">🧑‍🤝‍🧑</div>
          <h3>No friends yet</h3>
          <p>Search above to find people on CLUB.</p>
        </div>
      )}
    </div>
  );
}
