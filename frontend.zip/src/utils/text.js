// The backend represents some categorical fields (platform, genre, ...) as
// plain strings and others as { id, name } objects. Normalize to a display
// string wherever such a value is rendered directly or used as a key.
export function asText(v) {
  if (v == null) return '';
  if (typeof v === 'string' || typeof v === 'number') return v;
  return v.name ?? v.label ?? '';
}
