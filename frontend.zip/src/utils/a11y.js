// Spread onto a <div> that's been given onClick as a navigation/toggle
// trigger, so it's also reachable and activatable by keyboard.
export function clickableDivProps(onClick) {
  return {
    role: 'button',
    tabIndex: 0,
    onClick,
    onKeyDown(e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onClick();
      }
    },
  };
}
