// Content providers offerable for a Watch Party. CLUB never hosts, copies,
// bypasses DRM, or redistributes copyrighted video — "supported" providers
// are ones CLUB can legally embed (YouTube/Vimeo's own player) or that play
// a file the host already owns locally (Uploaded Video, host-only playback,
// no upload/redistribution). Everything else is listed as a future
// integration: for a real Netflix/Disney+/Prime Video/etc. party, each
// participant would sign in with their own authorized account and CLUB
// would only provide the room, sync cues, and social layer around it.
export const SUPPORTED_PROVIDERS = [
  {
    id: 'youtube',
    name: 'YouTube',
    icon: '▶️',
    description: 'Paste any public YouTube link — plays in a synced embedded player for everyone.',
    features: ['Embedded player', 'Host-controlled sync', 'Queue support'],
    embeddable: true,
    inputKind: 'url',
    inputLabel: 'YouTube video URL',
    inputPlaceholder: 'https://youtube.com/watch?v=…',
  },
  {
    id: 'vimeo',
    name: 'Vimeo',
    icon: '🎥',
    description: 'Paste a public Vimeo link — plays in a synced embedded player for everyone.',
    features: ['Embedded player', 'Host-controlled sync', 'Queue support'],
    embeddable: true,
    inputKind: 'url',
    inputLabel: 'Vimeo video URL',
    inputPlaceholder: 'https://vimeo.com/…',
  },
  {
    id: 'upload',
    name: 'Uploaded Video',
    icon: '📁',
    description: "Play a video file from your own device. Only the host's device plays it — CLUB doesn't upload, store, or redistribute the file.",
    features: ['Local playback', 'Host-only source', 'No upload or storage'],
    embeddable: false,
    inputKind: 'file',
    inputLabel: 'Choose a video file',
  },
];

export const FUTURE_PROVIDERS = [
  { id: 'netflix', name: 'Netflix', icon: '🎬' },
  { id: 'disneyplus', name: 'Disney+', icon: '🏰' },
  { id: 'primevideo', name: 'Prime Video', icon: '📦' },
  { id: 'hulu', name: 'Hulu', icon: '🟢' },
  { id: 'appletv', name: 'Apple TV+', icon: '🍎' },
  { id: 'crunchyroll', name: 'Crunchyroll', icon: '🍥' },
].map((p) => ({
  ...p,
  description: `Each participant watches with their own authorized ${p.name} account — CLUB syncs the room, not the stream.`,
  features: ['Coming soon'],
  embeddable: false,
}));

// Parses a pasted YouTube/Vimeo URL into an embeddable player URL. Returns
// null if the link can't be parsed (caller should keep the raw URL as a
// fallback / show an error).
export function toEmbedUrl(providerId, url) {
  if (!url) return null;
  try {
    if (providerId === 'youtube') {
      const u = new URL(url);
      const id = u.hostname.includes('youtu.be')
        ? u.pathname.slice(1)
        : u.searchParams.get('v') || u.pathname.split('/').pop();
      return id ? `https://www.youtube.com/embed/${id}?autoplay=0&enablejsapi=1` : null;
    }
    if (providerId === 'vimeo') {
      const u = new URL(url);
      const id = u.pathname.split('/').filter(Boolean).pop();
      return id ? `https://player.vimeo.com/video/${id}` : null;
    }
  } catch {
    return null;
  }
  return null;
}
