// Games playable straight from Home.
// `builtin` = a real mini-game shipped in this app (opens its own modal).
// `room-topic` = a real game people already play elsewhere — CLUB just
// helps host/find a Room for it, same as any other room topic.
export const GAMES = [
  {
    id: 'two-truths',
    type: 'builtin',
    title: 'Two Truths and a Lie',
    desc: 'Guess which fact about each person is the lie.',
    icon: '🎭',
  },
  {
    id: 'truth-or-dare',
    type: 'builtin',
    title: 'Truth or Dare',
    desc: 'Pick Truth or Dare and reveal the card.',
    icon: '🃏',
  },
  {
    id: 'never-have-i-ever',
    type: 'builtin',
    title: 'Never Have I Ever',
    desc: 'Swipe through statements — have you, or never?',
    icon: '🙈',
  },
  {
    id: 'mafia',
    type: 'builtin',
    title: 'Mafia',
    desc: 'Secret roles, night phases, and a day vote — find the Mafia.',
    icon: '🕵️',
  },
  {
    id: 'trivia',
    type: 'builtin',
    title: 'Trivia',
    desc: 'Movie facts and awkward-moment trivia — everyone competes for the top score.',
    icon: '🧠',
  },
  {
    id: 'emoji-charades',
    type: 'builtin',
    title: 'Emoji Charades',
    desc: 'Guess the movie from the emoji clue — fastest scores win.',
    icon: '🎬',
  },
  {
    id: 'spyfall',
    type: 'builtin',
    title: 'Spyfall',
    desc: 'Everyone knows the location except the Spy — vote them out.',
    icon: '🕵️‍♀️',
  },
];

// Curated subset shown as poster cards in Home's "Trending Games" row —
// same visual treatment as the movie "Trending titles" carousel. Kept to
// social-deduction + party/social games only, per the requested list.
// `accent` drives the card's gradient background (GamePosterCard) — an
// original color treatment per title instead of any real box art/logo,
// since none of these are CLUB's IP to redistribute.
export const TRENDING_GAMES = [
  { title: 'Among Us', icon: '🚀', accent: '#c51111' },
  { title: 'Goose Goose Duck', icon: '🦢', accent: '#f7b500' },
  { title: 'Super Sus', icon: '🔍', accent: '#7c3aed' },
  { title: 'Mafia', icon: '🕵️', accent: '#7a0c0c' },
  { title: 'Werewolf Online', icon: '🐺', accent: '#3f5227' },
  { title: 'Town of Salem 2', icon: '🌙', accent: '#6b2d5c' },
  { title: 'First Class Trouble', icon: '🤖', accent: '#0ea5a4' },
  { title: 'UNO!', icon: '🃏', accent: '#eab308' },
  { title: 'Minecraft', icon: '⛏️', accent: '#3f6d2e' },
  { title: 'Roblox', icon: '🧱', accent: '#c2261e' },
  { title: 'Stumble Guys', icon: '🏃', accent: '#3b82f6' },
  { title: 'Fall Guys', icon: '🫘', accent: '#ec4899' },
];
