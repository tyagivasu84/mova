import { Home, Tv, Users, MessageCircle, UserPlus, User, Crown } from 'lucide-react';

// Shared nav item list — the desktop sidebar (AppShell) and the mobile
// glass bottom nav (BottomNav) both render from this so entries stay in
// sync. `icon` is the Lucide component itself (rendered as <item.icon />),
// not pre-built JSX, so both nav bars can size/stroke it consistently.
// `mobile: false` hides an item from the bottom nav (kept small —
// 5 slots max reads well on a phone).
// Rewards lives inside Premium (as a tab) rather than getting its own nav
// entry. Messages has its own icon again (Clubs no longer hosts it).
export const NAV = [
  { to: '/', page: 'home', tip: 'Home', mobile: true, icon: Home },
  { to: '/rooms', page: 'rooms', tip: 'Rooms', mobile: true, icon: Tv },
  { to: '/clubs', page: 'clubs', tip: 'Clubs', mobile: false, icon: Users },
  { to: '/messages', page: 'messages', tip: 'Messages', mobile: true, icon: MessageCircle },
  { to: '/friends', page: 'friends', tip: 'Friends', mobile: false, icon: UserPlus },
  { divider: true },
  { to: '/profile', page: 'profile', tip: 'Profile', mobile: true, icon: User },
  { to: '/premium', page: 'premium', tip: 'Premium & Rewards', mobile: false, icon: Crown },
];
