import { useEffect } from 'react';

// Calls `onEscape` whenever the Escape key is pressed while mounted —
// shared by every modal/dropdown so keyboard users have a dismiss path
// that doesn't depend on finding a mouse-only close button.
export function useEscapeKey(onEscape) {
  useEffect(() => {
    function handleKeyDown(e) {
      if (e.key === 'Escape') onEscape();
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onEscape]);
}
