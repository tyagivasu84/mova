import { useEffect } from 'react';

const FOCUSABLE = 'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])';

// Keeps Tab/Shift+Tab cycling within the given container while it's
// mounted, and focuses its first focusable element on mount — shared by
// every overlay modal so keyboard users can't tab out to the page behind.
export function useFocusTrap(ref) {
  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    // Only steal focus if nothing inside already has it — some modals
    // autoFocus a specific field (e.g. a title input) and that should win.
    if (!node.contains(document.activeElement)) {
      node.querySelector(FOCUSABLE)?.focus();
    }

    function handleKeyDown(e) {
      if (e.key !== 'Tab') return;
      const items = node.querySelectorAll(FOCUSABLE);
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }

    node.addEventListener('keydown', handleKeyDown);
    return () => node.removeEventListener('keydown', handleKeyDown);
  }, [ref]);
}
