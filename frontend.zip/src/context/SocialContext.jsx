import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { friendsApi } from '../api/friends';
import { achievementsApi } from '../api/achievements';
import { useAuth } from './AuthContext';

const SocialContext = createContext(null);

export function SocialProvider({ children }) {
  const { user } = useAuth();
  const [friends, setFriends] = useState([]);
  const [incoming, setIncoming] = useState([]);
  const [outgoing, setOutgoing] = useState([]);

  const applyView = useCallback((view) => {
    setFriends(view.friends);
    setIncoming(view.incoming);
    setOutgoing(view.outgoing);
  }, []);

  const refresh = useCallback(async () => {
    if (!user) {
      setFriends([]);
      setIncoming([]);
      setOutgoing([]);
      return;
    }
    try {
      applyView(await friendsApi.list());
    } catch {
      /* keep previous state */
    }
  }, [user, applyView]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const sendRequest = useCallback(
    async (userId) => {
      const view = await friendsApi.sendRequest(userId);
      applyView(view);
      return view;
    },
    [applyView]
  );

  const acceptRequest = useCallback(
    async (id) => {
      const view = await friendsApi.acceptRequest(id);
      applyView(view);
      if ((view.friends?.length ?? 0) >= 5) achievementsApi.unlock('a4');
      return view;
    },
    [applyView]
  );

  const declineRequest = useCallback(
    async (id) => {
      const view = await friendsApi.declineRequest(id);
      applyView(view);
      return view;
    },
    [applyView]
  );

  const search = useCallback((query) => friendsApi.search(query), []);

  return (
    <SocialContext.Provider
      value={{ friends, incoming, outgoing, sendRequest, acceptRequest, declineRequest, search, refresh }}
    >
      {children}
    </SocialContext.Provider>
  );
}

export function useSocial() {
  const ctx = useContext(SocialContext);
  if (!ctx) throw new Error('useSocial must be used within SocialProvider');
  return ctx;
}
