import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { stateApi } from '../api/state';
import { achievementsApi } from '../api/achievements';
import { useAuth } from './AuthContext';

const AppStateContext = createContext(null);

// Day 1..7 rewards, mirrors the backend (kept for display only).
export const STREAK_REWARDS = [50, 75, 100, 125, 150, 200, 400];

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}
function daysBetween(a, b) {
  return Math.round((new Date(b) - new Date(a)) / 86400000);
}

// Derives the streak strip display from the persisted streak state.
export function deriveStreakView(streak) {
  const today = todayStr();
  const last = streak?.lastClaimDate || null;
  const gap = last ? daysBetween(last, today) : Infinity;
  const claimedToday = gap === 0;
  const broken = gap > 1;
  const effective = broken ? 0 : streak?.streak || 0;
  const pos = effective % 7; // 0-indexed slot for "today"
  const dots = Array.from({ length: 7 }, (_, i) => ({
    done: i < pos || (i === pos && claimedToday),
    today: i === pos && !claimedToday,
  }));
  return {
    claimedToday,
    pos,
    dots,
    dayLabel: `Day ${pos + 1} streak`,
    sub: claimedToday
      ? "You're set for today — back tomorrow to keep it going."
      : 'Come back daily for bigger bonuses.',
    claimReward: STREAK_REWARDS[pos],
  };
}

export function AppStateProvider({ children }) {
  const { user } = useAuth();
  const [points, setPoints] = useState(0);
  const [streak, setStreak] = useState({ streak: 0, lastClaimDate: null });
  const [shopOwned, setShopOwned] = useState([]);
  const [ready, setReady] = useState(false);

  // Load state when a user becomes available; reset when logged out.
  useEffect(() => {
    let active = true;
    if (!user) {
      setReady(false);
      setPoints(0);
      setStreak({ streak: 0, lastClaimDate: null });
      setShopOwned([]);
      return;
    }
    (async () => {
      try {
        const s = await stateApi.get();
        if (!active) return;
        setPoints(s.points ?? 0);
        setStreak(s.streak ?? { streak: 0, lastClaimDate: null });
        setShopOwned(s.shopOwned ?? []);
      } catch {
        /* keep defaults */
      } finally {
        if (active) setReady(true);
      }
    })();
    return () => {
      active = false;
    };
  }, [user]);

  const applyState = useCallback((s) => {
    // Clamped defensively — spend flows (e.g. GiftModal) send negative
    // amounts to the real /state/points endpoint, and this repo has no way
    // to confirm the backend itself rejects/clamps an overspend rather than
    // returning a negative balance.
    if (s.points != null) setPoints(Math.max(0, s.points));
    if (s.streak) setStreak(s.streak);
    if (s.shopOwned) setShopOwned(s.shopOwned);
  }, []);

  const addPoints = useCallback(
    async (amount) => {
      const s = await stateApi.addPoints(amount);
      applyState(s);
      return s;
    },
    [applyState]
  );

  const claimStreak = useCallback(async () => {
    const result = await stateApi.claimStreak();
    applyState(result.state);
    if ((result.state?.streak?.streak ?? 0) >= 30) achievementsApi.unlock('a3');
    return result; // { reward, dayOfWeek, state }
  }, [applyState]);

  const redeemShopItem = useCallback(
    async (itemId) => {
      const result = await stateApi.redeemShopItem(itemId);
      applyState(result.state);
      if ((result.state?.shopOwned?.length ?? 0) >= 3) achievementsApi.unlock('a5');
      return result; // { item, state }
    },
    [applyState]
  );

  return (
    <AppStateContext.Provider
      value={{ points, streak, shopOwned, ready, addPoints, claimStreak, redeemShopItem }}
    >
      {children}
    </AppStateContext.Provider>
  );
}

export function useAppState() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used within AppStateProvider');
  return ctx;
}
