import { createContext, useContext, useState, useCallback } from 'react';

const CallContext = createContext(null);

// Minimal cross-cutting state so AppShell can show a persistent "in room"
// indicator regardless of which page is currently mounted.
export function CallProvider({ children }) {
  const [activeRoom, setActiveRoom] = useState(null);

  const joinRoom = useCallback((room) => setActiveRoom(room), []);
  const leaveRoom = useCallback(() => setActiveRoom(null), []);

  return (
    <CallContext.Provider value={{ activeRoom, joinRoom, leaveRoom }}>
      {children}
    </CallContext.Provider>
  );
}

export function useCall() {
  const ctx = useContext(CallContext);
  if (!ctx) throw new Error('useCall must be used within CallProvider');
  return ctx;
}
