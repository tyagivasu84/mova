import styles from './ClubChannelSidebar.module.css';

export default function ClubChannelSidebar({ channels, voiceChannels, activeId, onSelect }) {
  return (
    <div className={styles.sidebar}>
      <div className={styles.groupLabel}>Text Channels</div>
      {channels.map((c) => (
        <button
          key={c.id}
          onClick={() => onSelect(c.id)}
          className={`${styles.channelBtn} ${c.id === activeId ? styles.channelBtnActive : ''}`}
        >
          # {c.name}
        </button>
      ))}

      {voiceChannels?.length > 0 && (
        <>
          <div className={styles.groupLabel}>Voice Channels</div>
          {voiceChannels.map((c) => (
            <button
              key={c.id}
              onClick={() => onSelect(c.id)}
              className={`${styles.channelBtn} ${styles.voiceBtn} ${c.id === activeId ? styles.channelBtnVoiceActive : ''}`}
            >
              🔊 {c.name}
            </button>
          ))}
        </>
      )}
    </div>
  );
}
