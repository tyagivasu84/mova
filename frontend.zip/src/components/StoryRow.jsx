import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSocial } from '../context/SocialContext';
import { clubsApi } from '../api/clubs';
import { presenceApi, STATUS_INFO } from '../api/presence';
import styles from './StoryRow.module.css';

// Ported from the Halo design exploration — a horizontal status row with a
// gradient ring, driven by the clubs you're in and your friends.
export default function StoryRow() {
  const navigate = useNavigate();
  const { friends } = useSocial();
  const [clubs, setClubs] = useState([]);
  const [presence, setPresence] = useState({});

  useEffect(() => {
    clubsApi
      .list()
      .then((list) => setClubs(list.filter((c) => c.isMember)))
      .catch(() => {});
    presenceApi.map().then(setPresence).catch(() => {});
  }, []);

  const items = [
    ...clubs.map((c) => ({
      key: `club-${c.id}`,
      label: c.name,
      status: null,
      initial: c.avatarInitial,
      onClick: () => navigate(`/clubs/${c.id}`),
    })),
    ...friends.map((f) => {
      const p = presence[f.id];
      const statusText = p ? p.activity || (p.status !== 'online' ? STATUS_INFO[p.status]?.label : null) : null;
      return {
        key: `friend-${f.id}`,
        label: f.displayName.split(' ')[0],
        status: statusText,
        initial: f.avatarInitial,
        onClick: () => navigate(`/profile/${f.id}`),
      };
    }),
  ];

  if (!items.length) return null;

  return (
    <div className={styles.row}>
      {items.map((it) => (
        <button key={it.key} className={styles.item} onClick={it.onClick}>
          <div className={styles.ring}>
            <div className={styles.avatar}>{it.initial}</div>
          </div>
          <div className={styles.label}>{it.label}</div>
          {/* Same dim small-text slot RoomCard uses for its "X here" line. */}
          {it.status && <div className={styles.status}>{it.status}</div>}
        </button>
      ))}
    </div>
  );
}
