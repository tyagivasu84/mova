import { useEffect, useRef, useState } from 'react';
import { MOCK_USERS, mockUser } from '../api/mock/fixtures/users';
import { SPYFALL_LOCATIONS } from '../api/mock/fixtures/prompts';
import { achievementsApi } from '../api/achievements';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import WagerStep from './WagerStep';
import styles from './SpyfallGame.module.css';

// Needs at least 3 other players (4 total) — a meaningful vote needs a
// real pool of suspects, same reasoning as Mafia's MIN_OTHERS.
const MIN_OTHERS = 3;

function resolveOthers(participants) {
  if (participants?.length) {
    return participants.map((p) => mockUser(p.userId)).filter(Boolean);
  }
  return [...MOCK_USERS].sort(() => Math.random() - 0.5).slice(0, 5);
}

function randomExcept(players, excludeIds) {
  const pool = players.filter((p) => !excludeIds.includes(p.id));
  if (!pool.length) return null;
  return pool[Math.floor(Math.random() * pool.length)].id;
}

// Single-round Spyfall — one random Spy among the group, everyone else
// shares a secret location. One discussion→vote phase (no real free-text
// Q&A between bots, that's not simulable meaningfully), then reveal.
export default function SpyfallGame({ user, participants, onClose }) {
  const { addPoints } = useAppState();
  const { showToast } = useToast();
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  const [players] = useState(() => {
    const others = resolveOthers(participants);
    const all = [
      { id: 'me', displayName: user?.displayName || 'You', avatarInitial: (user?.displayName || 'U').charAt(0).toUpperCase(), isMe: true },
      ...others.map((u) => ({ id: u.id, displayName: u.displayName, avatarInitial: u.avatarInitial, isMe: false })),
    ];
    const spyId = all[Math.floor(Math.random() * all.length)].id;
    return all.map((p) => ({ ...p, isSpy: p.id === spyId }));
  });
  const [location] = useState(() => SPYFALL_LOCATIONS[Math.floor(Math.random() * SPYFALL_LOCATIONS.length)]);
  const tooFewPlayers = players.length - 1 < MIN_OTHERS;

  const [stake, setStake] = useState(null);
  const [phase, setPhase] = useState('reveal'); // reveal -> vote -> result
  const [votedOutId, setVotedOutId] = useState(null);

  const me = players.find((p) => p.isMe);
  const spy = players.find((p) => p.isSpy);
  const spyCaught = votedOutId === spy?.id;
  const myTeamWon = phase === 'result' && (me.isSpy ? !spyCaught : spyCaught);

  useEffect(() => {
    if (phase !== 'result' || stake === null) return;
    achievementsApi.unlock('a15').catch(() => {});
    const opponentCount = players.length - 1;
    if (myTeamWon) {
      const gain = stake * opponentCount;
      if (gain > 0) {
        showToast(`You win! +${gain} pts`);
        addPoints(gain).catch(() => {});
      }
    } else if (stake > 0) {
      showToast(`You lost the wager — -${stake} pts`);
      addPoints(-stake).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  function castVote(targetId) {
    const others = players.filter((p) => !p.isMe);
    const botVotes = others.map((p) => randomExcept(players, [p.id]));
    const allVotes = [targetId, ...botVotes];
    const tally = {};
    allVotes.forEach((id) => {
      if (!id) return;
      tally[id] = (tally[id] || 0) + 1;
    });
    const maxVotes = Math.max(...Object.values(tally));
    const topChoices = Object.keys(tally).filter((id) => tally[id] === maxVotes);
    setVotedOutId(topChoices[Math.floor(Math.random() * topChoices.length)]);
    setPhase('result');
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>🕵️‍♀️ Spyfall</h3>

        {tooFewPlayers ? (
          <div className="empty-state">
            <div className="emoji">🕵️‍♀️</div>
            <h3>Not enough players</h3>
            <p>Spyfall needs at least {MIN_OTHERS} other people in the room.</p>
          </div>
        ) : stake === null ? (
          <WagerStep opponentCount={players.length - 1} onStart={setStake} />
        ) : (
          <>
            {phase === 'reveal' && (
              <div className={styles.intro}>
                {me.isSpy ? (
                  <>
                    <div className={styles.roleIcon}>🕵️‍♀️</div>
                    <div className={styles.roleLabel}>You are the Spy</div>
                    <p className={styles.roleDesc}>
                      Everyone else knows a secret location. Blend in, and don't get voted out.
                    </p>
                  </>
                ) : (
                  <>
                    <div className={styles.roleIcon}>📍</div>
                    <div className={styles.roleLabel}>{location}</div>
                    <p className={styles.roleDesc}>
                      That's the secret location — everyone knows it except the Spy. Find them.
                    </p>
                  </>
                )}
                <button
                  className="btn btn-primary"
                  style={{ width: '100%' }}
                  onClick={() => setPhase('vote')}
                >
                  Ready to vote
                </button>
              </div>
            )}

            {phase === 'vote' && (
              <div>
                <p className={styles.subtitle}>Who do you think is the Spy?</p>
                <div className={styles.playerGrid}>
                  {players
                    .filter((p) => !p.isMe)
                    .map((p) => (
                      <button key={p.id} className={styles.playerBtn} onClick={() => castVote(p.id)}>
                        <span className="avatar-sm">{p.avatarInitial}</span>
                        {p.displayName}
                      </button>
                    ))}
                </div>
              </div>
            )}

            {phase === 'result' && (
              <div className={styles.resultBlock}>
                <div className={styles.roleIcon}>{spyCaught ? '🎉' : '🕵️‍♀️'}</div>
                <div className={styles.roleLabel}>
                  {spyCaught ? 'The Spy was caught!' : 'The Spy got away'}
                </div>
                <p className={styles.summaryText}>
                  {spy.isMe ? 'You were' : `${spy.displayName} was`} the Spy. The location was{' '}
                  <b>{location}</b>.
                </p>
                {stake > 0 && (
                  <p className={styles.summaryText}>
                    {myTeamWon
                      ? `You won the wager — +${stake * (players.length - 1)} pts`
                      : `You lost the wager — -${stake} pts`}
                  </p>
                )}
                <button className="btn btn-primary" style={{ width: '100%' }} onClick={onClose}>
                  Done
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
