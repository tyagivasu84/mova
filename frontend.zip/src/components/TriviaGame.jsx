import { TRIVIA_QUESTIONS } from '../api/mock/fixtures/prompts';
import RoundQuizGame from './RoundQuizGame';

export default function TriviaGame({ participants, user, onClose }) {
  return (
    <RoundQuizGame
      title="Trivia"
      icon="🧠"
      questions={TRIVIA_QUESTIONS}
      achievementId="a13"
      participants={participants}
      user={user}
      onClose={onClose}
    />
  );
}
