import { useNavigate } from 'react-router-dom';
import { clickableDivProps } from '../utils/a11y';
import styles from './cards.module.css';

// Same card shell as PosterCard (movie titles), but with an original
// icon-on-gradient poster instead of a photo — these are real third-party
// games CLUB doesn't own art for, so the card is a color treatment built
// from `game.accent` plus its emoji, not any borrowed box art or logo.
// CLUB doesn't implement these games; clicking finds or hosts a Room for
// them, same as the rest of the Games sections.
export default function GamePosterCard({ game }) {
  const navigate = useNavigate();

  function handleClick() {
    navigate('/rooms', { state: { presetSearch: game.title } });
  }

  return (
    <div className={styles.poster} style={{ '--pa': game.accent || '#2a2a2a' }} {...clickableDivProps(handleClick)}>
      <div className={styles.posterIconBg}>{game.icon}</div>
      <div className={styles.posterScrim} />
      <div className={styles.trendTag}>
        <span className={styles.trendDot} style={{ background: 'var(--red)' }} />
        Trending
      </div>
      <div className={styles.posterBody}>
        <div className={styles.title}>
          {game.icon} {game.title}
        </div>
        <div className={styles.meta}>Find a room</div>
      </div>
    </div>
  );
}
