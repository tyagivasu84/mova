import { useEffect, useState } from 'react';
import { achievementsApi } from '../api/achievements';
import styles from './AchievementsGrid.module.css';

export default function AchievementsGrid() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    achievementsApi.list().then(setItems).catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 40 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (!items.length) {
    return (
      <div className="empty-state">
        <div className="emoji">🏆</div>
        <h3>No achievements yet</h3>
        <p>Keep using CLUB to start unlocking badges.</p>
      </div>
    );
  }

  return (
    <div className={styles.grid}>
      {items.map((a) => (
        <div
          key={a.id}
          className={`${styles.badge} ${a.unlocked ? styles.unlocked : styles.locked}`}
          title={a.desc}
        >
          <div className={styles.icon}>{a.icon}</div>
          <div className={styles.title}>{a.title}</div>
        </div>
      ))}
    </div>
  );
}
