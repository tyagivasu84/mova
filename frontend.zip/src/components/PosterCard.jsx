import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { platformDot, platformName } from '../api/platform';
import { asText } from '../utils/text';
import { clickableDivProps } from '../utils/a11y';
import WatchPartyCreateModal from './WatchPartyCreateModal';
import styles from './cards.module.css';

// Renders a title poster. `title` shape comes from the catalog API
// (title, genre, year, rating, accent, trend?).
export default function PosterCard({ title }) {
  const navigate = useNavigate();
  const [showWatchParty, setShowWatchParty] = useState(false);
  const metaLine = title.meta || [asText(title.genre), title.year].filter(Boolean).join(' · ');

  function handleWatchTogether(e) {
    e.stopPropagation();
    setShowWatchParty(true);
  }
  // Deterministic per-title placeholder art — CLUB hosts no real poster
  // art/third-party images, this is just decorative filler seeded by title
  // so the same card always gets the same picture.
  const imageSeed = encodeURIComponent(title.title || 'club');

  return (
    <div
      className={styles.poster}
      style={{ '--pa': title.accent || title.a }}
      {...clickableDivProps(() => navigate(`/movie/${encodeURIComponent(title.title)}`))}
    >
      <img
        className={styles.posterImg}
        src={`https://picsum.photos/seed/${imageSeed}/300/430`}
        alt=""
        loading="lazy"
      />
      <div className={styles.posterScrim} />
      <span className={styles.rating}>★ {title.rating}</span>
      {title.trend && (
        <div className={styles.trendTag}>
          <span
            className={styles.trendDot}
            style={{ background: platformDot(platformName(title.trend.platform)) }}
          />
          {asText(title.trend.label)}
        </div>
      )}
      <div className={`${styles.posterBody} ${styles.posterBodyAction}`}>
        <div className={styles.title}>{title.title}</div>
        <div className={styles.meta}>{metaLine}</div>
      </div>
      <button
        type="button"
        className={styles.watchBtn}
        onClick={handleWatchTogether}
        aria-label={`Create a Watch Party for ${title.title}`}
        title="Create Watch Party"
      >
        ▶
      </button>

      {showWatchParty && (
        <WatchPartyCreateModal initialTitle={title.title} onClose={() => setShowWatchParty(false)} />
      )}
    </div>
  );
}
