import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { roomsApi } from '../api/rooms';
import { clubsApi } from '../api/clubs';
import { useSocial } from '../context/SocialContext';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import { SUPPORTED_PROVIDERS, FUTURE_PROVIDERS, toEmbedUrl } from '../config/watchPartyProviders';
import styles from './WatchPartyCreateModal.module.css';

const STEPS = ['Provider', 'Party', 'Invite'];
const VISIBILITY_OPTIONS = [
  { id: 'public', label: 'Public', hint: 'Anyone can find and join' },
  { id: 'private', label: 'Private', hint: 'Visible, but must ask to join' },
  { id: 'invite_only', label: 'Invite Only', hint: 'Only people you invite can join' },
];

// Step 1 (the "🎬 Create Watch Party" entry click) happens wherever this
// modal is opened from. Everything after that — provider, party details,
// invite — lives here as one flow, ending with the caller navigating into
// the created room (Step 5, the room itself, is WatchPartyRoom).
export default function WatchPartyCreateModal({ initialTitle = '', onClose }) {
  const navigate = useNavigate();
  const { friends } = useSocial();
  const { showToast } = useToast();
  const cardRef = useRef(null);
  const fileInputRef = useRef(null);

  const [step, setStep] = useState(0);
  const [providerId, setProviderId] = useState(null);
  const [contentUrl, setContentUrl] = useState('');
  const [localFile, setLocalFile] = useState(null);

  const [name, setName] = useState(initialTitle ? `Watching ${initialTitle}` : '');
  const [description, setDescription] = useState('');
  const [visibility, setVisibility] = useState('public');
  const [maxParticipants, setMaxParticipants] = useState(8);
  const [enableVoice, setEnableVoice] = useState(true);
  const [enableVideo, setEnableVideo] = useState(false);
  const [enableChat, setEnableChat] = useState(true);
  const [creating, setCreating] = useState(false);

  const [room, setRoom] = useState(null);
  const [invitedIds, setInvitedIds] = useState([]);
  const [shareClubId, setShareClubId] = useState('');
  const [myClubs, setMyClubs] = useState(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  const provider = SUPPORTED_PROVIDERS.find((p) => p.id === providerId);
  const canContinueFromProvider = provider && (provider.inputKind === 'file' ? Boolean(localFile) : contentUrl.trim().length > 0);

  function loadClubsOnce() {
    if (myClubs !== null) return;
    clubsApi
      .list()
      .then((list) => setMyClubs(list.filter((c) => c.isMember)))
      .catch(() => setMyClubs([]));
  }

  async function handleCreateParty(e) {
    e.preventDefault();
    if (!name.trim()) return;
    let embedUrl = null;
    if (provider.inputKind === 'url') {
      embedUrl = toEmbedUrl(provider.id, contentUrl.trim());
      if (!embedUrl) {
        showToast(`That doesn't look like a valid ${provider.name} link — check the URL and try again`);
        return;
      }
    }
    setCreating(true);
    try {
      const created = await roomsApi.create({
        title: name.trim(),
        description: description.trim(),
        mode: 'instant',
        visibility,
        maxParticipants: Number(maxParticipants) || 8,
        isWatchParty: true,
        provider: provider.id,
        videoUrl: embedUrl,
        enableVoice,
        enableVideo,
        enableChat,
      });
      setRoom(created);
      setStep(2);
    } catch (err) {
      showToast(err.message || 'Could not create the party');
    } finally {
      setCreating(false);
    }
  }

  async function handleInviteFriend(friend) {
    try {
      await roomsApi.invite(room.id, [friend.id]);
      setInvitedIds((prev) => [...prev, friend.id]);
      showToast(`Invited ${friend.displayName}`);
    } catch (err) {
      showToast(err.message || 'Could not invite friend');
    }
  }

  function handleCopyLink() {
    const url = `${window.location.origin}/room/${room.id}`;
    navigator.clipboard?.writeText(url).then(
      () => showToast('Invite link copied'),
      () => showToast(url)
    );
  }

  async function handleShareToClub() {
    if (!shareClubId) return;
    const club = myClubs.find((c) => c.id === shareClubId);
    const channelId = club?.channels?.[0]?.id;
    if (!channelId) {
      showToast('That club has no text channel to post in');
      return;
    }
    try {
      await clubsApi.sendChannelMessage(channelId, `🎬 Watch Party started: "${room.title}" — join at /room/${room.id}`);
      showToast(`Shared to ${club.name}`);
    } catch (err) {
      showToast(err.message || 'Could not share to club');
    }
  }

  function handleEnter() {
    onClose();
    navigate(`/room/${room.id}`, localFile ? { state: { localVideoUrl: URL.createObjectURL(localFile) } } : undefined);
  }

  return (
    <div
      className={styles.overlay}
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div className={styles.card} onClick={(e) => e.stopPropagation()} ref={cardRef} role="dialog" aria-modal="true">
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3 className={styles.heading}>🎬 Create Watch Party</h3>

        <div className={styles.stepRow}>
          {STEPS.map((s, i) => (
            <div key={s} className={`${styles.stepDot} ${i <= step ? styles.stepDotActive : ''}`}>
              <span className={styles.stepNum}>{i + 1}</span>
              {s}
            </div>
          ))}
        </div>

        {step === 0 && (
          <div>
            <div className={styles.sectionLabel}>Supported Now</div>
            <div className={styles.providerGrid}>
              {SUPPORTED_PROVIDERS.map((p) => (
                <button
                  type="button"
                  key={p.id}
                  className={`${styles.providerCard} ${providerId === p.id ? styles.providerCardActive : ''}`}
                  onClick={() => {
                    setProviderId(p.id);
                    setContentUrl('');
                    setLocalFile(null);
                  }}
                >
                  <div className={styles.providerIcon}>{p.icon}</div>
                  <div className={styles.providerName}>{p.name}</div>
                  <div className={styles.providerDesc}>{p.description}</div>
                  <div className={styles.providerFeatures}>
                    {p.features.map((f) => (
                      <span key={f} className={styles.featureChip}>
                        ✓ {f}
                      </span>
                    ))}
                  </div>
                </button>
              ))}
            </div>

            {provider && (
              <div className={styles.contentInput}>
                <label className={styles.label}>{provider.inputLabel}</label>
                {provider.inputKind === 'file' ? (
                  <>
                    <button type="button" className="btn btn-ghost" onClick={() => fileInputRef.current?.click()}>
                      {localFile ? `📁 ${localFile.name}` : 'Choose a video file…'}
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="video/*"
                      style={{ display: 'none' }}
                      onChange={(e) => setLocalFile(e.target.files?.[0] || null)}
                    />
                  </>
                ) : (
                  <input
                    className={styles.input}
                    value={contentUrl}
                    onChange={(e) => setContentUrl(e.target.value)}
                    placeholder={provider.inputPlaceholder}
                  />
                )}
              </div>
            )}

            <div className={styles.sectionLabel} style={{ marginTop: 22 }}>
              Future Integrations
            </div>
            <div className={styles.futureGrid}>
              {FUTURE_PROVIDERS.map((p) => (
                <div key={p.id} className={styles.futureCard} title="Coming soon">
                  <span className={styles.futureIcon}>{p.icon}</span>
                  {p.name}
                  <span className={styles.comingSoonTag}>Soon</span>
                </div>
              ))}
            </div>

            <button
              className="btn btn-primary"
              style={{ width: '100%', marginTop: 20 }}
              disabled={!canContinueFromProvider}
              onClick={() => setStep(1)}
            >
              Continue
            </button>
          </div>
        )}

        {step === 1 && (
          <form onSubmit={handleCreateParty}>
            <label className={styles.label}>Party Name</label>
            <input
              className={styles.input}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Friday night watch party"
              autoFocus
              required
            />

            <label className={styles.label}>Description</label>
            <textarea
              className={styles.input}
              style={{ resize: 'vertical' }}
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What are you watching tonight?"
            />

            <label className={styles.label}>Visibility</label>
            <div className={styles.visibilityRow}>
              {VISIBILITY_OPTIONS.map((v) => (
                <button
                  type="button"
                  key={v.id}
                  className={`${styles.visibilityChip} ${visibility === v.id ? styles.visibilityChipActive : ''}`}
                  onClick={() => setVisibility(v.id)}
                >
                  <div>{v.label}</div>
                  <div className={styles.visibilityHint}>{v.hint}</div>
                </button>
              ))}
            </div>

            <label className={styles.label}>Maximum Participants</label>
            <input
              className={styles.input}
              type="number"
              min={2}
              max={50}
              value={maxParticipants}
              onChange={(e) => setMaxParticipants(e.target.value)}
            />

            <div className={styles.toggleGrid}>
              <label className={styles.toggleRow}>
                <input type="checkbox" checked={enableVoice} onChange={(e) => setEnableVoice(e.target.checked)} />
                🎙️ Enable Voice Chat
              </label>
              <label className={styles.toggleRow}>
                <input type="checkbox" checked={enableVideo} onChange={(e) => setEnableVideo(e.target.checked)} />
                📹 Enable Video Chat
              </label>
              <label className={styles.toggleRow}>
                <input type="checkbox" checked={enableChat} onChange={(e) => setEnableChat(e.target.checked)} />
                💬 Enable Live Chat
              </label>
            </div>

            <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
              <button type="button" className="btn btn-ghost" onClick={() => setStep(0)}>
                ← Back
              </button>
              <button className="btn btn-primary" style={{ flex: 1 }} disabled={creating}>
                {creating ? 'Creating…' : 'Create Party'}
              </button>
            </div>
          </form>
        )}

        {step === 2 && room && (
          <div>
            <div className={styles.inviteIntro}>
              <b>{room.title}</b> is live — pull people in before you press play.
            </div>

            <button className="btn btn-ghost" style={{ width: '100%', marginBottom: 10 }} onClick={handleCopyLink}>
              🔗 Copy Invite Link
            </button>

            {friends.length > 0 && (
              <>
                <div className={styles.label}>Invite Friends</div>
                <div className={styles.friendChipRow}>
                  {friends.map((f) => (
                    <button
                      type="button"
                      key={f.id}
                      className={`${styles.friendChip} ${invitedIds.includes(f.id) ? styles.friendChipActive : ''}`}
                      disabled={invitedIds.includes(f.id)}
                      onClick={() => handleInviteFriend(f)}
                    >
                      {invitedIds.includes(f.id) ? '✓ ' : ''}
                      {f.displayName}
                    </button>
                  ))}
                </div>
              </>
            )}

            <div className={styles.shareRow} onFocus={loadClubsOnce} onClick={loadClubsOnce}>
              <select
                className={styles.input}
                style={{ marginBottom: 0 }}
                value={shareClubId}
                onChange={(e) => setShareClubId(e.target.value)}
              >
                <option value="">Share to a club…</option>
                {(myClubs || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <button type="button" className="btn btn-ghost" disabled={!shareClubId} onClick={handleShareToClub}>
                Share
              </button>
            </div>

            <button className="btn btn-primary" style={{ width: '100%', marginTop: 20 }} onClick={handleEnter}>
              Enter Watch Party →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
