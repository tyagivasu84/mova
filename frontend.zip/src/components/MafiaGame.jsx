import { useEffect, useRef, useState } from 'react';
import { MOCK_USERS, mockUser } from '../api/mock/fixtures/users';
import { achievementsApi } from '../api/achievements';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import WagerStep from './WagerStep';
import styles from './MafiaGame.module.css';

const ROLE_INFO = {
  mafia: { label: 'Mafia', icon: '🔪', desc: 'Each night, secretly eliminate one player.' },
  detective: { label: 'Detective', icon: '🔍', desc: 'Each night, investigate one player.' },
  doctor: { label: 'Doctor', icon: '💉', desc: 'Each night, protect one player from elimination.' },
  villager: { label: 'Villager', icon: '👤', desc: 'No night action — find the Mafia during the day vote.' },
};

// Needs at least 3 other players (4 total) for a coherent round — with
// 1 Mafia, the game-over check ends things the moment only 2 players
// remain, so fewer than that can't produce a real round.
const MIN_OTHERS = 3;

function resolveOthers(participants) {
  if (participants?.length) {
    return participants.map((p) => mockUser(p.userId)).filter(Boolean);
  }
  return [...MOCK_USERS].sort(() => Math.random() - 0.5).slice(0, 5);
}

function assignRoles(total) {
  const roles = ['mafia'];
  if (total >= 4) roles.push('detective');
  if (total >= 6) roles.push('doctor');
  while (roles.length < total) roles.push('villager');
  return shuffle(roles);
}

function buildPlayers(user, participants) {
  const others = resolveOthers(participants);
  const roles = assignRoles(others.length + 1);
  const all = [
    { id: 'me', displayName: user?.displayName || 'You', avatarInitial: (user?.displayName || 'U').charAt(0).toUpperCase(), isMe: true },
    ...others.map((u) => ({ id: u.id, displayName: u.displayName, avatarInitial: u.avatarInitial, isMe: false })),
  ];
  return all.map((p, i) => ({ ...p, role: roles[i], alive: true }));
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function randomAliveExcept(players, excludeIds) {
  const pool = players.filter((p) => p.alive && !excludeIds.includes(p.id));
  if (!pool.length) return null;
  return pool[Math.floor(Math.random() * pool.length)].id;
}

function checkWinner(players) {
  const alive = players.filter((p) => p.alive);
  const mafiaAlive = alive.filter((p) => p.role === 'mafia').length;
  if (mafiaAlive === 0) return 'villagers';
  if (mafiaAlive >= alive.length - mafiaAlive) return 'mafia';
  return null;
}

// Single-player Mafia — you get one of 4 roles among 5 simulated
// participants; every other role/vote is simple bot logic. Simplified
// on purpose: one night action + one day vote per round, no voice/room
// codes/animated eliminations.
export default function MafiaGame({ user, participants, onClose }) {
  const { addPoints } = useAppState();
  const { showToast } = useToast();
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  const [players, setPlayers] = useState(() => buildPlayers(user, participants));
  const tooFewPlayers = players.length - 1 < MIN_OTHERS;
  const [stake, setStake] = useState(null);
  const [phase, setPhase] = useState('intro'); // intro -> night -> night-result -> day -> day-result -> game-over
  const [round, setRound] = useState(1);
  const [investigateResult, setInvestigateResult] = useState(null);
  const [nightSummary, setNightSummary] = useState('');
  const [daySummary, setDaySummary] = useState('');
  const [winner, setWinner] = useState(null);

  const me = players.find((p) => p.isMe);
  const alive = players.filter((p) => p.alive);
  const otherAlive = alive.filter((p) => !p.isMe);
  const myTeamWon = Boolean(winner && me && (winner === 'mafia') === (me.role === 'mafia'));

  useEffect(() => {
    if (phase === 'game-over' && stake !== null) {
      achievementsApi.unlock('a12').catch(() => {});
      const opponentCount = players.length - 1;
      if (myTeamWon) {
        const gain = stake * opponentCount;
        if (gain > 0) {
          showToast(`You win! +${gain} pts`);
          addPoints(gain).catch(() => {});
        }
      } else if (stake > 0) {
        showToast(`You lost the wager — -${stake} pts`);
        addPoints(-stake).catch(() => {});
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  function resolveNight(mafiaTargetId, protectId) {
    // Mafia is always alive when a night phase runs (the game ends the
    // moment they're not). Doctor may already be dead, though — in
    // that case no one protects anyone this round.
    const mafiaPlayer = players.find((p) => p.role === 'mafia');
    const doctorPlayer = players.find((p) => p.role === 'doctor');

    const finalMafiaTarget =
      me?.role === 'mafia' ? mafiaTargetId : randomAliveExcept(players, [mafiaPlayer?.id]);
    const finalProtect = !doctorPlayer?.alive
      ? null
      : me?.role === 'doctor'
        ? protectId
        : randomAliveExcept(players, []);

    let next = players;
    let summary;
    if (finalMafiaTarget && finalMafiaTarget === finalProtect) {
      summary = 'The Doctor saved everyone — no one was eliminated last night.';
    } else if (finalMafiaTarget) {
      next = players.map((p) => (p.id === finalMafiaTarget ? { ...p, alive: false } : p));
      const victim = players.find((p) => p.id === finalMafiaTarget);
      summary = `${victim.isMe ? 'You were' : `${victim.displayName} was`} eliminated during the night.`;
    } else {
      summary = 'A quiet night — no one was eliminated.';
    }
    setPlayers(next);
    setNightSummary(summary);
    setPhase('night-result');
  }

  function handleInvestigate(targetId) {
    const target = players.find((p) => p.id === targetId);
    setInvestigateResult(target);
  }

  function afterNightResult() {
    const w = checkWinner(players);
    if (w) {
      setWinner(w);
      setPhase('game-over');
    } else {
      setPhase('day');
    }
  }

  function castVote(targetId) {
    const botVotes = otherAlive.map((p) => randomAliveExcept(players, [p.id]));
    const allVotes = targetId ? [targetId, ...botVotes] : botVotes;
    const tally = {};
    allVotes.forEach((id) => {
      if (!id) return;
      tally[id] = (tally[id] || 0) + 1;
    });
    const maxVotes = Math.max(...Object.values(tally));
    const topChoices = Object.keys(tally).filter((id) => tally[id] === maxVotes);
    const eliminatedId = topChoices[Math.floor(Math.random() * topChoices.length)];
    const eliminated = players.find((p) => p.id === eliminatedId);
    const next = players.map((p) => (p.id === eliminatedId ? { ...p, alive: false } : p));
    setPlayers(next);
    setDaySummary(
      `${eliminated.isMe ? 'You were' : `${eliminated.displayName} was`} voted out — they were ${ROLE_INFO[eliminated.role].icon} ${ROLE_INFO[eliminated.role].label}.`
    );
    setPhase('day-result');
  }

  function afterDayResult() {
    const w = checkWinner(players);
    if (w) {
      setWinner(w);
      setPhase('game-over');
    } else {
      setRound((r) => r + 1);
      setInvestigateResult(null);
      setPhase('night');
    }
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>🕵️ Mafia</h3>

        {tooFewPlayers ? (
          <div className="empty-state">
            <div className="emoji">🕵️</div>
            <h3>Not enough players</h3>
            <p>Mafia needs at least {MIN_OTHERS} other people in the room.</p>
          </div>
        ) : stake === null ? (
          <WagerStep opponentCount={players.length - 1} onStart={setStake} />
        ) : (
          <>
        {phase === 'intro' && me && (
          <div className={styles.intro}>
            <div className={styles.roleIcon}>{ROLE_INFO[me.role].icon}</div>
            <div className={styles.roleLabel}>You are the {ROLE_INFO[me.role].label}</div>
            <p className={styles.roleDesc}>{ROLE_INFO[me.role].desc}</p>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => setPhase('night')}>
              Start Round 1
            </button>
          </div>
        )}

        {phase === 'night' && me && (
          <NightAction
            me={me}
            otherAlive={otherAlive}
            round={round}
            investigateResult={investigateResult}
            onInvestigate={handleInvestigate}
            onContinue={resolveNight}
          />
        )}

        {phase === 'night-result' && (
          <div className={styles.resultBlock}>
            <p className={styles.summaryText}>🌙 {nightSummary}</p>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={afterNightResult}>
              Continue
            </button>
          </div>
        )}

        {phase === 'day' && me?.alive && (
          <div>
            <p className={styles.subtitle}>Round {round} — vote to eliminate a suspect</p>
            <div className={styles.playerGrid}>
              {otherAlive.map((p) => (
                <button key={p.id} className={styles.playerBtn} onClick={() => castVote(p.id)}>
                  <span className="avatar-sm">{p.avatarInitial}</span>
                  {p.displayName}
                </button>
              ))}
            </div>
          </div>
        )}
        {phase === 'day' && !me?.alive && (
          <div className={styles.resultBlock}>
            <p className={styles.summaryText}>You've been eliminated — watching the rest play out.</p>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => castVote(null)}>
              Continue
            </button>
          </div>
        )}

        {phase === 'day-result' && (
          <div className={styles.resultBlock}>
            <p className={styles.summaryText}>☀️ {daySummary}</p>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={afterDayResult}>
              Continue
            </button>
          </div>
        )}

        {phase === 'game-over' && (
          <div className={styles.resultBlock}>
            <div className={styles.roleIcon}>{winner === 'mafia' ? '🔪' : '🏆'}</div>
            <div className={styles.roleLabel}>
              {winner === 'mafia' ? 'The Mafia wins' : 'The Villagers win'}
            </div>
            {stake > 0 && (
              <p className={styles.summaryText}>
                {myTeamWon ? `You won the wager — +${stake * (players.length - 1)} pts` : `You lost the wager — -${stake} pts`}
              </p>
            )}
            <div className={styles.reveal}>
              {players.map((p) => (
                <div key={p.id} className={styles.revealRow}>
                  <span>{p.isMe ? 'You' : p.displayName}</span>
                  <span>
                    {ROLE_INFO[p.role].icon} {ROLE_INFO[p.role].label}
                    {!p.alive ? ' · eliminated' : ''}
                  </span>
                </div>
              ))}
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={onClose}>
              Done
            </button>
          </div>
        )}
          </>
        )}
      </div>
    </div>
  );
}

function NightAction({ me, otherAlive, round, investigateResult, onInvestigate, onContinue }) {
  const [picked, setPicked] = useState(null);

  if (me.role === 'villager' || !me.alive) {
    return (
      <div className={styles.resultBlock}>
        <p className={styles.summaryText}>
          Round {round} — Night falls. Everyone is asleep. The night unfolds…
        </p>
        <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => onContinue(null, null)}>
          Continue
        </button>
      </div>
    );
  }

  if (me.role === 'detective') {
    return (
      <div>
        <p className={styles.subtitle}>Round {round} — choose someone to investigate</p>
        {investigateResult ? (
          <>
            <p className={styles.summaryText}>
              🔍 {investigateResult.displayName} is{' '}
              {investigateResult.role === 'mafia' ? 'the Mafia!' : 'not the Mafia.'}
            </p>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => onContinue(null, null)}>
              Continue
            </button>
          </>
        ) : (
          <div className={styles.playerGrid}>
            {otherAlive.map((p) => (
              <button key={p.id} className={styles.playerBtn} onClick={() => onInvestigate(p.id)}>
                <span className="avatar-sm">{p.avatarInitial}</span>
                {p.displayName}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  const label = me.role === 'mafia' ? 'choose someone to eliminate' : 'choose someone to protect';
  const pool = me.role === 'doctor' ? [me, ...otherAlive] : otherAlive;
  const activeClass = me.role === 'mafia' ? styles.playerBtnEliminate : styles.playerBtnProtect;

  return (
    <div>
      <p className={styles.subtitle}>
        Round {round} — {label}
      </p>
      <div className={styles.playerGrid}>
        {pool.map((p) => (
          <button
            key={p.id}
            className={`${styles.playerBtn} ${picked === p.id ? activeClass : ''}`}
            onClick={() => setPicked(p.id)}
          >
            <span className="avatar-sm">{p.avatarInitial}</span>
            {p.isMe ? 'Yourself' : p.displayName}
          </button>
        ))}
      </div>
      <button
        className="btn btn-primary"
        style={{ width: '100%', marginTop: 12 }}
        disabled={!picked}
        onClick={() => onContinue(me.role === 'mafia' ? picked : null, me.role === 'doctor' ? picked : null)}
      >
        Confirm
      </button>
    </div>
  );
}
