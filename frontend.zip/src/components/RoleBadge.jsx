const ROLE_STYLES = {
  owner: { label: 'Owner', color: '#ffd166' },
  admin: { label: 'Admin', color: '#e50914' },
  mod: { label: 'Mod', color: '#5865f2' },
  vip: { label: 'VIP', color: '#a855f7' },
  member: { label: 'Member', color: '#8a8a8a' },
};

export default function RoleBadge({ role }) {
  const style = ROLE_STYLES[role] || ROLE_STYLES.member;
  return (
    <span
      style={{
        fontSize: 10,
        fontWeight: 800,
        padding: '2px 8px',
        borderRadius: 100,
        color: style.color,
        border: `1px solid ${style.color}55`,
        background: `${style.color}1a`,
        whiteSpace: 'nowrap',
      }}
    >
      {style.label}
    </span>
  );
}
