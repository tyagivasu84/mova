import { useEffect, useRef, useState } from 'react';
import { NEVER_HAVE_I_EVER } from '../api/mock/fixtures/prompts';
import { achievementsApi } from '../api/achievements';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import styles from './NeverHaveIEverGame.module.css';

// Solo swipe-through-statements loop — tally "I Have" vs "Never",
// summary at the end. No scoring, just a fun reveal/tally.
export default function NeverHaveIEverGame({ onClose }) {
  const cardRef = useRef(null);
  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  const [index, setIndex] = useState(0);
  const [haveCount, setHaveCount] = useState(0);
  const [neverCount, setNeverCount] = useState(0);

  const finished = index >= NEVER_HAVE_I_EVER.length;

  useEffect(() => {
    if (finished) achievementsApi.unlock('a11').catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finished]);

  function answer(have) {
    if (have) setHaveCount((c) => c + 1);
    else setNeverCount((c) => c + 1);
    setIndex((i) => i + 1);
  }

  function skip() {
    setIndex((i) => i + 1);
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>🙈 Never Have I Ever</h3>

        {finished ? (
          <div className={styles.summary}>
            <div className={styles.tallyRow}>
              <div>
                <div className={styles.tallyNum}>{haveCount}</div>
                <div className={styles.tallyLabel}>I Have</div>
              </div>
              <div>
                <div className={styles.tallyNum}>{neverCount}</div>
                <div className={styles.tallyLabel}>Never</div>
              </div>
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={onClose}>
              Done
            </button>
          </div>
        ) : (
          <>
            <div className={styles.progress}>
              {index + 1} of {NEVER_HAVE_I_EVER.length}
            </div>
            <div className={styles.statementCard}>{NEVER_HAVE_I_EVER[index]}</div>
            <div className={styles.answerRow}>
              <button className={`${styles.answerBtn} ${styles.haveBtn}`} onClick={() => answer(true)}>
                I Have
              </button>
              <button className={`${styles.answerBtn} ${styles.neverBtn}`} onClick={() => answer(false)}>
                Never
              </button>
            </div>
            <button className="btn btn-ghost" style={{ width: '100%', marginTop: 8 }} onClick={skip}>
              Skip
            </button>
          </>
        )}
      </div>
    </div>
  );
}
