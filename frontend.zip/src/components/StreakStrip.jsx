import { useState } from 'react';
import { useAppState, deriveStreakView } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import styles from './StreakStrip.module.css';

export default function StreakStrip() {
  const { streak, claimStreak } = useAppState();
  const { showToast } = useToast();
  const [claiming, setClaiming] = useState(false);

  const view = deriveStreakView(streak);

  async function handleClaim() {
    setClaiming(true);
    try {
      const { reward, dayOfWeek } = await claimStreak();
      showToast(`+${reward} pts — day ${dayOfWeek} streak!`);
    } catch (err) {
      showToast(err.message || 'Already claimed today');
    } finally {
      setClaiming(false);
    }
  }

  return (
    <div className={styles.rewardStrip}>
      <div>
        <div className={styles.rsStreak}>{view.dayLabel}</div>
        <div className={styles.rsSub}>{view.sub}</div>
      </div>
      <div className={styles.rsDots}>
        {view.dots.map((d, i) => (
          <span
            key={i}
            className={`${styles.rsDot} ${d.done ? styles.rsDotDone : ''} ${
              d.today ? styles.rsDotToday : ''
            }`}
          />
        ))}
      </div>
      <button
        className="btn btn-primary"
        disabled={view.claimedToday || claiming}
        onClick={handleClaim}
      >
        {view.claimedToday ? 'Claimed' : `Claim +${view.claimReward}`}
      </button>
    </div>
  );
}
