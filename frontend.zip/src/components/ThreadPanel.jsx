import { useState } from 'react';
import { useEscapeKey } from '../hooks/useEscapeKey';
import styles from './ThreadPanel.module.css';

// Branches a single message into its own reply panel — shared by DM
// conversations and club channels. Has no backdrop/click-outside-to-close
// (it's a slide-in side panel, not an overlay), so Escape is its only
// non-mouse dismiss path.
export default function ThreadPanel({ message, onClose, onReply }) {
  const [value, setValue] = useState('');

  useEscapeKey(onClose);

  function submit(e) {
    e.preventDefault();
    if (!value.trim()) return;
    onReply(message.id, value.trim());
    setValue('');
  }

  return (
    <div className={styles.panel}>
      <div className={styles.header}>
        <span>Thread</span>
        <button onClick={onClose} aria-label="Close thread">
          ×
        </button>
      </div>

      <div className={styles.root}>{message.body}</div>

      <div className={styles.replies}>
        {message.replies?.length ? (
          message.replies.map((r) => (
            <div key={r.id} className={styles.reply}>
              {r.body}
            </div>
          ))
        ) : (
          <div className={styles.empty}>No replies yet</div>
        )}
      </div>

      <form className={styles.composer} onSubmit={submit}>
        <input
          className={styles.input}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Reply in thread…"
          autoFocus
        />
        <button className="btn btn-primary" style={{ fontSize: 12 }} type="submit">
          Reply
        </button>
      </form>
    </div>
  );
}
