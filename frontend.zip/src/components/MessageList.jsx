import MessageBubble from './MessageBubble';

export default function MessageList({ messages, onReact, onOpenThread }) {
  return (
    <div>
      {messages.map((m) => (
        <MessageBubble
          key={m.id}
          message={m}
          isMe={m.authorId === 'me'}
          onReact={onReact}
          onOpenThread={onOpenThread}
        />
      ))}
    </div>
  );
}
