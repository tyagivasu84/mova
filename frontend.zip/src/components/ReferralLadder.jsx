import { useEffect, useState } from 'react';
import { referralsApi } from '../api/referrals';
import { useToast } from '../context/ToastContext';
import styles from './ReferralLadder.module.css';

export default function ReferralLadder() {
  const { showToast } = useToast();
  const [code, setCode] = useState('');
  const [tiers, setTiers] = useState([]);
  const [referrals, setReferrals] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      referralsApi.getCode().then(setCode).catch(() => {}),
      referralsApi.getLadder().then(setTiers).catch(() => {}),
      referralsApi.getReferrals().then(setReferrals).catch(() => {}),
    ]).finally(() => setLoading(false));
  }, []);

  async function copyLink() {
    const link = `https://club.app/join?ref=${code}`;
    if (!navigator.clipboard?.writeText) {
      showToast('Could not copy — clipboard not available');
      return;
    }
    try {
      await navigator.clipboard.writeText(link);
      showToast('Referral link copied');
    } catch {
      showToast('Could not copy link');
    }
  }

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 40 }}>
        <div className="spinner" />
      </div>
    );
  }

  return (
    <div>
      <div className={styles.codeRow}>
        <div className={styles.codeBox}>{code || '···'}</div>
        <button className="btn btn-primary" onClick={copyLink} disabled={!code}>
          Copy invite link
        </button>
      </div>

      <div className={styles.ladder}>
        {tiers.map((t) => (
          <div key={t.tier} className={`${styles.tier} ${t.unlocked ? styles.tierUnlocked : ''}`}>
            <div className={styles.tierBadge}>{t.unlocked ? '✓' : t.tier}</div>
            <div>
              <div className={styles.tierTitle}>
                {t.referralsNeeded} referral{t.referralsNeeded > 1 ? 's' : ''}
              </div>
              <div className={styles.tierReward}>+{t.rewardPoints.toLocaleString()} pts</div>
            </div>
          </div>
        ))}
      </div>

      <div className={styles.list}>
        {referrals.length ? (
          referrals.map((r) => (
            <div key={r.userId} className={styles.listItem}>
              <span className="avatar-sm">{r.displayName.charAt(0)}</span>
              <span>{r.displayName}</span>
              <span className={styles.status}>{r.status}</span>
            </div>
          ))
        ) : (
          <div className="empty-state">
            <div className="emoji">🔗</div>
            <h3>No referrals yet</h3>
            <p>Share your link to start earning bonus points.</p>
          </div>
        )}
      </div>
    </div>
  );
}
