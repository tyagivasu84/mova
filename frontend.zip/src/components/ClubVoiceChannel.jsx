import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import SpeakingRing from './SpeakingRing';
import styles from './ClubVoiceChannel.module.css';

function buildParticipants(club, user) {
  const others = club.members.filter((m) => m.user).slice(0, 5);
  return [
    {
      id: 'me',
      displayName: user?.displayName || 'You',
      avatarInitial: (user?.displayName || 'U').charAt(0).toUpperCase(),
      isMe: true,
      micOn: true,
      speaking: false,
    },
    ...others.map((m) => ({
      id: m.userId,
      displayName: m.user.displayName,
      avatarInitial: m.user.avatarInitial,
      isMe: false,
      micOn: true,
      speaking: false,
    })),
  ];
}

// A lightweight voice room scoped to one club channel — same simulated
// speaking-ring pattern as LiveRoom, simplified (no host controls/kick,
// this is just "you're in the channel with these members").
export default function ClubVoiceChannel({ channel, club, onLeave }) {
  const { user } = useAuth();
  const [participants, setParticipants] = useState(() => buildParticipants(club, user));
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(false);
  const [sharingScreen, setSharingScreen] = useState(false);

  useEffect(() => {
    setParticipants(buildParticipants(club, user));
    setMicOn(true);
    setCamOn(false);
    setSharingScreen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channel.id]);

  useEffect(() => {
    const interval = setInterval(() => {
      setParticipants((prev) => {
        if (!prev.length) return prev;
        const idx = Math.floor(Math.random() * prev.length);
        return prev.map((p, i) => ({ ...p, speaking: i === idx && (p.isMe ? micOn : p.micOn) }));
      });
    }, 1800);
    return () => clearInterval(interval);
  }, [micOn]);

  return (
    <div className={styles.wrap}>
      <div className={styles.header}>
        <span>🔊 {channel.name}</span>
        <span className={styles.count}>{participants.length} in voice</span>
      </div>

      <div className={styles.grid}>
        {participants.map((p) => (
          <div key={p.id} className={styles.tile}>
            <SpeakingRing
              initial={p.avatarInitial}
              active={p.isMe ? micOn && p.speaking : p.micOn && p.speaking}
              muted={p.isMe ? !micOn : !p.micOn}
              size={64}
            />
            <div className={styles.tileName}>{p.isMe ? 'You' : p.displayName}</div>
            {p.isMe && sharingScreen && <div className={styles.tag}>🖥️ Sharing screen</div>}
            {p.isMe && camOn && <div className={styles.tag}>📹 Camera on</div>}
          </div>
        ))}
      </div>

      <div className={styles.controls}>
        <button
          className={`${styles.ctrlBtn} ${!micOn ? styles.ctrlOff : ''}`}
          onClick={() => setMicOn((v) => !v)}
          aria-label="Toggle microphone"
        >
          {micOn ? '🎙️' : '🔇'}
        </button>
        <button
          className={`${styles.ctrlBtn} ${!camOn ? styles.ctrlOff : ''}`}
          onClick={() => setCamOn((v) => !v)}
          aria-label="Toggle camera"
        >
          {camOn ? '📹' : '📷'}
        </button>
        <button
          className={`${styles.ctrlBtn} ${sharingScreen ? styles.ctrlActive : ''}`}
          onClick={() => setSharingScreen((v) => !v)}
          aria-label="Toggle screen share"
        >
          🖥️
        </button>
        <button className={`${styles.ctrlBtn} ${styles.leaveBtn}`} onClick={onLeave}>
          Leave
        </button>
      </div>
    </div>
  );
}
