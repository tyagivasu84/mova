import { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { NAV } from '../config/nav';
import styles from './BottomNav.module.css';

const MOBILE_ITEMS = NAV.filter((item) => !item.divider && item.mobile);

// Sliding indicator positioned from real measured pixel offsets
// (getBoundingClientRect) rather than percentage math, so it stays
// pixel-accurate under the icon regardless of container width.
export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const containerRef = useRef(null);
  const itemRefs = useRef({});
  const [indicator, setIndicator] = useState(null);

  const activeTo = MOBILE_ITEMS.find((i) => i.to === location.pathname)?.to;

  useEffect(() => {
    function measure() {
      const btn = itemRefs.current[activeTo];
      const container = containerRef.current;
      if (!btn || !container) {
        setIndicator(null);
        return;
      }
      const containerRect = container.getBoundingClientRect();
      const btnRect = btn.getBoundingClientRect();
      setIndicator({ left: btnRect.left - containerRect.left, width: btnRect.width });
    }
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, [activeTo]);

  return (
    <nav className={styles.nav} ref={containerRef}>
      {indicator && (
        <div
          className={styles.indicator}
          style={{ left: indicator.left, width: indicator.width }}
        />
      )}
      {MOBILE_ITEMS.map((item) => (
        <button
          key={item.to}
          ref={(el) => (itemRefs.current[item.to] = el)}
          className={`${styles.item} ${item.to === activeTo ? styles.itemActive : ''}`}
          onClick={() => navigate(item.to)}
          style={{ position: 'relative', zIndex: 1 }}
        >
          <item.icon size={20} strokeWidth={1.8} />
        </button>
      ))}
    </nav>
  );
}
