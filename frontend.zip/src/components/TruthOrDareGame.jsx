import { useRef, useState } from 'react';
import { TRUTHS, DARES } from '../api/mock/fixtures/prompts';
import { achievementsApi } from '../api/achievements';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import styles from './TruthOrDareGame.module.css';

const POINTS_PER_CARD = 5;

function randomFrom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// Solo prompt-reveal loop — pick Truth or Dare, reveal a card, mark it
// done, pick again. No win/lose state, just participation.
export default function TruthOrDareGame({ onClose }) {
  const { addPoints } = useAppState();
  const { showToast } = useToast();
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  const [prompt, setPrompt] = useState(null); // { kind, text } | null
  const [rounds, setRounds] = useState(0);

  function pick(kind) {
    const text = kind === 'truth' ? randomFrom(TRUTHS) : randomFrom(DARES);
    setPrompt({ kind, text });
  }

  function handleDone() {
    setRounds((r) => r + 1);
    showToast(`+${POINTS_PER_CARD} pts`);
    addPoints(POINTS_PER_CARD).catch(() => {});
    achievementsApi.unlock('a10').catch(() => {});
    setPrompt(null);
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>🃏 Truth or Dare</h3>

        {!prompt ? (
          <>
            <p className={styles.subtitle}>
              {rounds > 0 ? `${rounds} done — pick your next card` : 'Choose one to reveal a card'}
            </p>
            <div className={styles.pickRow}>
              <button className={`${styles.pickBtn} ${styles.truthBtn}`} onClick={() => pick('truth')}>
                Truth
              </button>
              <button className={`${styles.pickBtn} ${styles.dareBtn}`} onClick={() => pick('dare')}>
                Dare
              </button>
            </div>
          </>
        ) : (
          <>
            <div className={`${styles.promptCard} ${prompt.kind === 'dare' ? styles.promptDare : ''}`}>
              <div className={styles.promptKind}>{prompt.kind === 'truth' ? 'Truth' : 'Dare'}</div>
              <div className={styles.promptText}>{prompt.text}</div>
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={handleDone}>
              Next card
            </button>
          </>
        )}
      </div>
    </div>
  );
}
