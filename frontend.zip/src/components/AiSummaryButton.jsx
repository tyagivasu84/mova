import { useState } from 'react';
import { aiApi } from '../api/ai';
import styles from './AiSummaryButton.module.css';

export default function AiSummaryButton({ messages }) {
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  async function handleClick() {
    if (open) {
      setOpen(false);
      return;
    }
    setOpen(true);
    if (!summary) {
      setLoading(true);
      try {
        setSummary(await aiApi.summarize(messages));
      } finally {
        setLoading(false);
      }
    }
  }

  return (
    <div className={styles.wrap}>
      <button className="btn btn-ghost" style={{ fontSize: 12 }} onClick={handleClick}>
        ✨ Catch me up
      </button>
      {open && (
        <div className={styles.panel}>
          {loading ? <div className="spinner" /> : <p>{summary}</p>}
        </div>
      )}
    </div>
  );
}
