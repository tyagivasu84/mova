import { useState } from 'react';
import { clickableDivProps } from '../utils/a11y';
import styles from './TasteMatchCard.module.css';

export default function TasteMatchCard({ match, friendStatus, onAddFriend }) {
  const [open, setOpen] = useState(false);

  return (
    <div className={styles.card} {...clickableDivProps(() => setOpen((v) => !v))}>
      <div className={styles.ring} style={{ '--pct': match.percent }}>
        <div className={styles.ringInner}>{match.percent}%</div>
      </div>
      <div className={styles.name}>{match.displayName}</div>
      <div className={styles.shared}>
        {match.sharedTitles.length
          ? `Both like ${match.sharedTitles.slice(0, 2).join(', ')}`
          : 'New match'}
      </div>

      {onAddFriend && (
        <button
          className="btn btn-ghost"
          style={{ width: '100%', marginTop: 10, fontSize: 11.5, padding: '6px 10px' }}
          disabled={friendStatus === 'friend' || friendStatus === 'pending'}
          onClick={(e) => {
            e.stopPropagation();
            onAddFriend(match);
          }}
        >
          {friendStatus === 'friend' ? '✓ Friends' : friendStatus === 'pending' ? 'Requested' : '+ Add friend'}
        </button>
      )}

      {open && (
        <div className={styles.details}>
          {match.sharedGenres?.length > 0 && (
            <div className={styles.genreChips}>
              {match.sharedGenres.map((g) => (
                <span key={g} className={styles.genreChip}>
                  {g}
                </span>
              ))}
            </div>
          )}
          <div className={styles.detailRow}>
            <b>Blend:</b> {match.blendProfile}
          </div>
          <div className={styles.detailRow}>
            <b>Anthem:</b> {match.movieAnthem}
          </div>
        </div>
      )}
    </div>
  );
}
