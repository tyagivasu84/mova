import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { platformName } from '../api/platform';
import { roomsApi } from '../api/rooms';
import { useToast } from '../context/ToastContext';
import styles from './cards.module.css';

// Renders a live room — one Room primitive, no watch/game split. `room`
// shape comes from either the real catalog API (movie-watch rooms, which
// carry a real `platform` streaming-service name) or the mock hosted-rooms
// layer (which carries a freeform `tag` instead). `tag` wins when present;
// `platform` is the fallback so catalog rooms keep their service pill.
export default function RoomCard({ room }) {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [requestStatus, setRequestStatus] = useState(() => roomsApi.myJoinRequestStatus(room.id));
  const [requesting, setRequesting] = useState(false);
  const pillText = room.tag || platformName(room.platform);
  const isPrivate = Boolean(room.permission) && !room.hostedByMe;
  const isInviteOnly = room.visibility === 'invite_only' && !room.hostedByMe;

  async function handleJoinClick() {
    if (isInviteOnly) return;
    if (!isPrivate || requestStatus === 'approved') {
      navigate(`/room/${room.id}`);
      return;
    }
    if (requestStatus === 'pending' || requestStatus === 'denied') return;
    setRequesting(true);
    try {
      await roomsApi.requestJoin(room);
      setRequestStatus('pending');
      showToast(`Request sent to ${room.host || 'the host'}`);
    } catch (err) {
      showToast(err.message || 'Could not send request');
    } finally {
      setRequesting(false);
    }
  }

  const joinLabel = isInviteOnly
    ? 'Invite only'
    : !isPrivate
      ? 'Join'
      : requestStatus === 'approved'
        ? 'Join'
        : requestStatus === 'pending'
          ? 'Requested'
          : requestStatus === 'denied'
            ? 'Request denied'
            : 'Ask to join';

  return (
    <div className={styles.roomCard}>
      <div className={styles.roomTop}>
        <span className={styles.roomLive}>
          <span className={styles.liveDot} /> Live
        </span>
        {room.isWatchParty && <span className={styles.watchPartyPill}>🎬 Watch Party</span>}
        {pillText && <span className={styles.platformPill}>{pillText}</span>}
      </div>
      <h3>
        {room.title}
        {room.premium && <span className={styles.premiumTag}>★ Premium</span>}
      </h3>
      <div className={styles.roomDesc}>{room.desc}</div>
      {room.host && <div className={styles.hostLine}>Hosted by {room.host}</div>}
      {room.vibe && <span className={styles.vibeTag}>{room.vibe}</span>}
      <div className={styles.avatars}>
        {(room.avatars || []).map((a, i) => (
          <span key={i} className={a.startsWith('+') ? styles.more : ''}>
            {a}
          </span>
        ))}
      </div>
      <div className={styles.roomFooter}>
        <span className={styles.seats}>
          {room.seatsMax ? `${room.seatsCurrent}/${room.seatsMax}` : room.seatsCurrent} here
        </span>
        <button
          className={`${styles.joinBtn} ${
            requestStatus === 'pending'
              ? styles.joinBtnPending
              : requestStatus === 'denied'
                ? styles.joinBtnDenied
                : ''
          }`}
          onClick={handleJoinClick}
          disabled={isInviteOnly || requesting || requestStatus === 'pending' || requestStatus === 'denied'}
          title={
            isInviteOnly
              ? 'Only people the host invites can join'
              : requestStatus === 'denied'
                ? 'The host declined this request'
                : undefined
          }
        >
          {joinLabel}
        </button>
      </div>
    </div>
  );
}
