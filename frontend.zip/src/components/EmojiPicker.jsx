import styles from './EmojiPicker.module.css';

// Renders a club's custom 8-emoji set as quick-insert buttons for the
// channel composer.
export default function EmojiPicker({ emojiSet, onPick }) {
  if (!emojiSet?.length) return null;
  return (
    <div className={styles.row}>
      {emojiSet.map((e) => (
        <button key={e} type="button" className={styles.emojiBtn} onClick={() => onPick(e)}>
          {e}
        </button>
      ))}
    </div>
  );
}
