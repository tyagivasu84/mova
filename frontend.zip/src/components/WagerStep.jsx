import { useState } from 'react';
import { useAppState } from '../context/AppStateContext';
import styles from './WagerStep.module.css';

const PRESETS = [10, 25, 50];

// Shared "stake points before the game starts" prompt for competitive
// games (ones with a real winner). Win and take everyone else's stake;
// lose and forfeit yours. Simulated opponents don't have real balances,
// so the payout is modeled as stake × opponent count rather than pulling
// from anyone else's actual points.
export default function WagerStep({ opponentCount, onStart }) {
  const { points } = useAppState();
  const [stake, setStake] = useState(Math.min(10, points));

  return (
    <div className={styles.wrap}>
      <p className={styles.hint}>Stake points — winner takes the pot, loser forfeits their stake.</p>

      <div className={styles.presetRow}>
        {PRESETS.filter((p) => p <= points).map((p) => (
          <button
            key={p}
            className={`${styles.presetChip} ${stake === p ? styles.presetChipActive : ''}`}
            onClick={() => setStake(p)}
          >
            ★ {p}
          </button>
        ))}
        <button
          className={`${styles.presetChip} ${points > 0 && stake === points ? styles.presetChipActive : ''}`}
          onClick={() => setStake(points)}
          disabled={points === 0}
        >
          Max
        </button>
        <button
          className={`${styles.presetChip} ${stake === 0 ? styles.presetChipActive : ''}`}
          onClick={() => setStake(0)}
        >
          None
        </button>
      </div>

      <input
        type="number"
        min={0}
        max={points}
        value={stake}
        onChange={(e) => setStake(Math.max(0, Math.min(points, Number(e.target.value) || 0)))}
        className={styles.input}
      />
      <div className={styles.available}>★ {points.toLocaleString()} available</div>

      <div className={styles.payoutRow}>
        <span>
          Win <b className={styles.win}>+{(stake * opponentCount).toLocaleString()}</b>
        </span>
        <span>
          Lose <b className={styles.lose}>−{stake.toLocaleString()}</b>
        </span>
      </div>

      <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => onStart(stake)}>
        {stake > 0 ? `Start — wager ★ ${stake.toLocaleString()}` : 'Start — no wager'}
      </button>
    </div>
  );
}
