import { useEffect, useRef, useState } from 'react';
import { MOCK_USERS, mockUser } from '../api/mock/fixtures/users';
import { achievementsApi } from '../api/achievements';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import WagerStep from './WagerStep';
import styles from './RoundQuizGame.module.css';

const ROUNDS = 5;
const BOT_ACCURACY = 0.6;

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function resolvePlayers(user, participants) {
  const others = participants?.length
    ? participants.map((p) => mockUser(p.userId)).filter(Boolean)
    : [...MOCK_USERS].sort(() => Math.random() - 0.5).slice(0, 4);
  return [
    { id: 'me', displayName: user?.displayName || 'You', avatarInitial: (user?.displayName || 'U').charAt(0).toUpperCase(), isMe: true, score: 0 },
    ...others.map((u) => ({ id: u.id, displayName: u.displayName, avatarInitial: u.avatarInitial, isMe: false, score: 0 })),
  ];
}

// Generic "everyone answers the same multiple-choice round" engine —
// powers both Trivia and Emoji Charades, which only differ in their
// question deck and framing copy.
export default function RoundQuizGame({ title, icon, questions, participants, user, achievementId, onClose }) {
  const { addPoints } = useAppState();
  const { showToast } = useToast();
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  const [players, setPlayers] = useState(() => resolvePlayers(user, participants));
  const [stake, setStake] = useState(null);
  const [rounds] = useState(() => shuffle(questions).slice(0, Math.min(ROUNDS, questions.length)));
  const [roundIndex, setRoundIndex] = useState(0);
  const [myPick, setMyPick] = useState(null);
  const [roundCorrectIds, setRoundCorrectIds] = useState([]);

  const finished = roundIndex >= rounds.length;
  const me = players.find((p) => p.isMe);
  const topScore = finished ? Math.max(...players.map((p) => p.score)) : 0;
  const won = finished && me?.score === topScore;

  useEffect(() => {
    if (!finished || stake === null) return;
    achievementsApi.unlock(achievementId).catch(() => {});
    const opponentCount = players.length - 1;
    if (won) {
      const gain = stake * opponentCount;
      if (gain > 0) {
        showToast(`You won the wager! +${gain} pts`);
        addPoints(gain).catch(() => {});
      }
    } else if (stake > 0) {
      showToast(`You lost the wager — -${stake} pts`);
      addPoints(-stake).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finished]);

  function handlePick(i) {
    if (myPick !== null) return;
    setMyPick(i);
    const q = rounds[roundIndex];
    const correctIds = [];
    setPlayers((prev) =>
      prev.map((p) => {
        const gotIt = p.isMe ? i === q.correctIndex : Math.random() < BOT_ACCURACY;
        if (gotIt) correctIds.push(p.id);
        return gotIt ? { ...p, score: p.score + 1 } : p;
      })
    );
    setRoundCorrectIds(correctIds);
  }

  function handleNext() {
    setMyPick(null);
    setRoundCorrectIds([]);
    setRoundIndex((i) => i + 1);
  }

  const current = rounds[roundIndex];
  const ranked = finished ? [...players].sort((a, b) => b.score - a.score) : [];

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>
          {icon} {title}
        </h3>

        {stake === null ? (
          <WagerStep opponentCount={players.length - 1} onStart={setStake} />
        ) : finished ? (
          <div className={styles.summary}>
            <div className={styles.summaryScore}>{won ? '🏆 You won!' : `#${ranked.findIndex((p) => p.isMe) + 1} place`}</div>
            <div className={styles.leaderboard}>
              {ranked.map((p, i) => (
                <div key={p.id} className={styles.leaderRow}>
                  <span>{i + 1}. {p.isMe ? 'You' : p.displayName}</span>
                  <span>{p.score} pts</span>
                </div>
              ))}
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={onClose}>
              Done
            </button>
          </div>
        ) : (
          <>
            <div className={styles.progress}>
              Round {roundIndex + 1} of {rounds.length}
            </div>
            <div className={styles.prompt}>{current.prompt}</div>
            <div className={styles.choices}>
              {current.choices.map((c, i) => {
                const revealed = myPick !== null;
                const isCorrect = i === current.correctIndex;
                const isPicked = i === myPick;
                return (
                  <button
                    key={c}
                    className={`${styles.choiceBtn} ${revealed && isCorrect ? styles.choiceCorrect : ''} ${
                      revealed && isPicked && !isCorrect ? styles.choiceWrong : ''
                    }`}
                    onClick={() => handlePick(i)}
                    disabled={revealed}
                  >
                    {c}
                  </button>
                );
              })}
            </div>
            {myPick !== null && (
              <>
                <p className={styles.roundResult}>
                  {roundCorrectIds.length} of {players.length} got it right
                </p>
                <button className="btn btn-primary" style={{ width: '100%' }} onClick={handleNext}>
                  Next
                </button>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
