import { EMOJI_CHARADES } from '../api/mock/fixtures/prompts';
import RoundQuizGame from './RoundQuizGame';

export default function EmojiCharadesGame({ participants, user, onClose }) {
  return (
    <RoundQuizGame
      title="Emoji Charades"
      icon="🎬"
      questions={EMOJI_CHARADES}
      achievementId="a14"
      participants={participants}
      user={user}
      onClose={onClose}
    />
  );
}
