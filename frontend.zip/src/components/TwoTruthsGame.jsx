import { useEffect, useRef, useState } from 'react';
import { mockUser } from '../api/mock/fixtures/users';
import { achievementsApi } from '../api/achievements';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import WagerStep from './WagerStep';
import styles from './TwoTruthsGame.module.css';

const POINTS_PER_CORRECT = 10;

// Icebreaker for a room's participants — each has 3 seeded funFacts
// (one marked `lie: true` in mock/fixtures/users.js), the real user
// guesses which is the lie, correct guesses earn points.
export default function TwoTruthsGame({ participants, onClose }) {
  const { addPoints } = useAppState();
  const { showToast } = useToast();
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  const people = participants
    .map((p) => mockUser(p.userId))
    .filter((u) => u?.funFacts?.length);

  const [stake, setStake] = useState(null);
  const [index, setIndex] = useState(0);
  const [guess, setGuess] = useState(null);
  const [score, setScore] = useState(0);

  const finished = index >= people.length;
  const won = finished && score >= Math.ceil(people.length / 2);

  useEffect(() => {
    if (!finished || !people.length || stake === null) return;
    achievementsApi.unlock('a9').catch(() => {});
    if (won) {
      const gain = stake * people.length;
      if (gain > 0) {
        showToast(`You won the wager! +${gain} pts`);
        addPoints(gain).catch(() => {});
      }
    } else if (stake > 0) {
      showToast(`You lost the wager — -${stake} pts`);
      addPoints(-stake).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finished]);

  const current = people[index];
  const lieIndex = current?.funFacts.findIndex((f) => f.lie);

  function handleGuess(i) {
    if (guess !== null) return;
    setGuess(i);
    if (i === lieIndex) {
      setScore((s) => s + 1);
      showToast(`Correct! +${POINTS_PER_CORRECT} pts`);
      addPoints(POINTS_PER_CORRECT).catch(() => {});
    } else {
      showToast(`Not quite — the lie was: "${current.funFacts[lieIndex].text}"`);
    }
  }

  function handleNext() {
    setGuess(null);
    setIndex((i) => i + 1);
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>🎭 Two Truths and a Lie</h3>

        {!people.length ? (
          <div className="empty-state">
            <div className="emoji">🎭</div>
            <h3>No one to play with yet</h3>
            <p>This room needs at least one other participant.</p>
          </div>
        ) : stake === null ? (
          <WagerStep opponentCount={people.length} onStart={setStake} />
        ) : finished ? (
          <div className={styles.summary}>
            <div className={styles.resultIcon}>{won ? '🏆' : '🎭'}</div>
            <div className={styles.resultLabel}>{won ? 'Nice reading!' : 'Better luck next time'}</div>
            <div className={styles.summaryScore}>
              {score} / {people.length}
            </div>
            <p>correct guesses{stake > 0 && ` · ${won ? 'won' : 'lost'} the wager`}</p>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={onClose}>
              Done
            </button>
          </div>
        ) : (
          <>
            <div className={styles.progress}>
              Person {index + 1} of {people.length}
            </div>
            <div className={styles.personRow}>
              <span className="avatar-sm">{current.avatarInitial}</span>
              <span className={styles.personName}>{current.displayName}</span>
            </div>

            <div className={styles.statements}>
              {current.funFacts.map((f, i) => {
                const revealed = guess !== null;
                const isLie = i === lieIndex;
                const isPicked = i === guess;
                const isCorrectPick = isPicked && isLie;
                return (
                  <button
                    key={i}
                    className={`${styles.statementBtn} ${
                      revealed && isCorrectPick ? styles.statementCorrect : ''
                    } ${revealed && isLie && !isCorrectPick ? styles.statementLie : ''} ${
                      revealed && isPicked && !isLie ? styles.statementWrong : ''
                    }`}
                    onClick={() => handleGuess(i)}
                    disabled={revealed}
                  >
                    {f.text}
                  </button>
                );
              })}
            </div>

            {guess !== null && (
              <button className="btn btn-primary" style={{ width: '100%' }} onClick={handleNext}>
                Next
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}
