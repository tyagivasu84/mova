import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { useToast } from '../context/ToastContext';
import { roomsApi } from '../api/rooms';
import { watchPartyApi } from '../api/watchPartyApi';
import { catalogApi } from '../api/catalog';
import { MOCK_USERS, mockUser } from '../api/mock/fixtures/users';
import { SUPPORTED_PROVIDERS, toEmbedUrl } from '../config/watchPartyProviders';
import SpeakingRing from './SpeakingRing';
import MessageComposer from './MessageComposer';
import PollCard from './PollCard';
import WatchPartySummary from './WatchPartySummary';
import WatchPartyCreateModal from './WatchPartyCreateModal';
import styles from './WatchPartyRoom.module.css';

const QUICK_REACTIONS = ['❤️', '😂', '😮', '🔥', '👏', '😢'];
// "GIFs" from the spec fold into this same reaction bar — CLUB has no real
// GIF-search backend to wire up, and animated emoji bursts cover the same
// "quick non-text reaction" need without faking a fake integration.

function buildParticipants(user, invitedIds = []) {
  const invited = (invitedIds || []).map(mockUser).filter(Boolean);
  const invitedIdSet = new Set(invited.map((u) => u.id));
  const filler = MOCK_USERS.filter((u) => !invitedIdSet.has(u.id)).slice(0, Math.max(0, 4 - invited.length));
  const others = [...invited, ...filler];
  return [
    {
      userId: 'me',
      displayName: user?.displayName || 'You',
      avatarInitial: (user?.displayName || 'U').charAt(0).toUpperCase(),
      isMe: true,
      isHost: true,
      micOn: true,
      camOn: false,
      speaking: false,
      handRaised: false,
    },
    ...others.map((u) => ({
      userId: u.id,
      displayName: u.displayName,
      avatarInitial: u.avatarInitial,
      isMe: false,
      isHost: false,
      micOn: true,
      camOn: Math.random() > 0.6,
      speaking: false,
      handRaised: false,
    })),
  ];
}

const CHAT_FILLER = ['🔥 this scene!', 'lol', 'wait what', 'same', '😂😂😂', 'no way', 'called it', "I'm crying"];

function formatTime(s) {
  if (!Number.isFinite(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60)
    .toString()
    .padStart(2, '0');
  return `${m}:${sec}`;
}

export default function WatchPartyRoom({ room, isHost, locked, onToggleLock, onLeave, localVideoUrl }) {
  const { user } = useAuth();
  const { friends } = useSocial();
  const { showToast } = useToast();

  const [invited, setInvited] = useState(room.invited || []);
  const [participants, setParticipants] = useState(() => buildParticipants(user, room.invited?.map((u) => u.id)));
  const [rightTab, setRightTab] = useState('participants');
  const [invitePickerOpen, setInvitePickerOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [reactionPickerOpen, setReactionPickerOpen] = useState(false);
  const [bursts, setBursts] = useState([]);

  const [nowPlaying, setNowPlaying] = useState({
    title: room.title,
    provider: room.provider,
    videoUrl: room.videoUrl,
    localUrl: localVideoUrl || null,
  });
  const [playerKey, setPlayerKey] = useState(0);
  const [queue, setQueue] = useState([]);
  const [queueUrl, setQueueUrl] = useState('');
  const [history, setHistory] = useState([]);
  const [suggested, setSuggested] = useState([]);

  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(false);
  const [screenSharing, setScreenSharing] = useState(false);
  const [handRaised, setHandRaised] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const [playing, setPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const [chat, setChat] = useState([]);
  const [polls, setPolls] = useState([]);
  const [notes, setNotes] = useState('');
  const [pollDraft, setPollDraft] = useState(null);

  const [showSummary, setShowSummary] = useState(false);
  const [showScheduleAnother, setShowScheduleAnother] = useState(false);
  const [joinedAt] = useState(() => Date.now());

  const videoRef = useRef(null);
  const playerWrapRef = useRef(null);

  const providerInfo = SUPPORTED_PROVIDERS.find((p) => p.id === nowPlaying.provider);
  const isLocalVideo = nowPlaying.provider === 'upload';
  const isEmbed = providerInfo?.embeddable && nowPlaying.videoUrl;

  // Initial load: queue, chat, polls, notes, plus a couple of trending
  // titles as "Suggested Content."
  useEffect(() => {
    watchPartyApi.queue(room.id).then(setQueue).catch(() => {});
    watchPartyApi.chat(room.id).then(setChat).catch(() => {});
    watchPartyApi.polls(room.id).then(setPolls).catch(() => {});
    watchPartyApi.notes(room.id).then(setNotes).catch(() => {});
    catalogApi
      .titles()
      .then((titles) => setSuggested(titles.slice(0, 4)))
      .catch(() => {});
  }, [room.id]);

  // Simulate reconnect + a one-time "Synchronizing…" moment shortly after
  // joining, per the spec's "show Synchronizing... if someone reconnects."
  useEffect(() => {
    const t = setTimeout(() => {
      setSyncing(true);
      showToast(`${participants[1]?.displayName || 'Someone'} reconnected — synchronizing…`);
      setTimeout(() => setSyncing(false), 1600);
    }, 4000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Simulated speaking + occasional live chat, same lightweight pattern
  // LiveRoom already uses for its participant grid.
  useEffect(() => {
    const speakInterval = setInterval(() => {
      setParticipants((prev) => {
        if (!prev.length) return prev;
        const idx = Math.floor(Math.random() * prev.length);
        return prev.map((p, i) => ({ ...p, speaking: i === idx && (p.isMe ? micOn : p.micOn) }));
      });
    }, 2000);

    const chatInterval = setInterval(() => {
      if (!room.enableChat) return;
      if (Math.random() > 0.35) return;
      const others = participants.filter((p) => !p.isMe);
      if (!others.length) return;
      const from = others[Math.floor(Math.random() * others.length)];
      const line = CHAT_FILLER[Math.floor(Math.random() * CHAT_FILLER.length)];
      watchPartyApi.sendChat(room.id, line, from.userId).then((msg) => setChat((prev) => [...prev, msg]));
    }, 9000);

    return () => {
      clearInterval(speakInterval);
      clearInterval(chatInterval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [micOn, participants.length]);

  useEffect(() => {
    setParticipants((prev) => prev.map((p) => (p.isMe ? { ...p, micOn, camOn, handRaised } : p)));
  }, [micOn, camOn, handRaised]);

  async function handleInviteFriend(friend) {
    try {
      const updated = await roomsApi.invite(room.id, [friend.id]);
      setInvited(updated.invited || []);
      showToast(`Invited ${friend.displayName}`);
    } catch (err) {
      showToast(err.message || 'Could not invite friend');
    }
  }

  function handleCopyLink() {
    const url = `${window.location.origin}/room/${room.id}`;
    navigator.clipboard?.writeText(url).then(
      () => showToast('Invite link copied'),
      () => showToast(url)
    );
  }

  async function handleEndParty() {
    if (!window.confirm("End this Watch Party for everyone? This can't be undone.")) return;
    setSettingsOpen(false);
    try {
      await roomsApi.end(room.id);
      showToast('Watch Party ended');
      onLeave();
    } catch (err) {
      showToast(err.message || 'Could not end the party');
    }
  }

  async function handleAddToQueue(e) {
    e.preventDefault();
    const url = queueUrl.trim();
    if (!url || !providerInfo) return;
    const embedUrl = toEmbedUrl(providerInfo.id, url);
    if (!embedUrl) {
      showToast(`That doesn't look like a valid ${providerInfo.name} link — check the URL and try again`);
      return;
    }
    try {
      const item = await watchPartyApi.addToQueue(room.id, {
        title: url,
        provider: providerInfo.id,
        videoUrl: embedUrl,
      });
      setQueue((prev) => [...prev, item]);
      setQueueUrl('');
    } catch (err) {
      showToast(err.message || 'Could not add to queue');
    }
  }

  function handleRemoveFromQueue(itemId) {
    watchPartyApi.removeFromQueue(room.id, itemId).then(() => {
      setQueue((prev) => prev.filter((q) => q.id !== itemId));
    });
  }

  function playFromQueue(item) {
    setHistory((prev) => [...prev, nowPlaying.title]);
    setNowPlaying({ title: item.title, provider: item.provider, videoUrl: item.videoUrl, localUrl: null });
    setPlayerKey((k) => k + 1);
    setCurrentTime(0);
    setPlaying(true);
    handleRemoveFromQueue(item.id);
    triggerSync();
  }

  function handleSkip() {
    if (!isHost) return;
    if (!queue.length) {
      showToast('Queue is empty');
      return;
    }
    playFromQueue(queue[0]);
  }

  function handleReplay() {
    setPlayerKey((k) => k + 1);
    setCurrentTime(0);
    if (videoRef.current) videoRef.current.currentTime = 0;
    triggerSync();
  }

  function triggerSync() {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 1200);
  }

  function handleTogglePlay() {
    if (!isLocalVideo || !videoRef.current) return;
    if (playing) videoRef.current.pause();
    else videoRef.current.play();
  }

  function handleSeek(e) {
    if (!isLocalVideo || !videoRef.current) return;
    const t = Number(e.target.value);
    videoRef.current.currentTime = t;
    setCurrentTime(t);
  }

  function handleSendChat(body) {
    watchPartyApi.sendChat(room.id, body).then((msg) => setChat((prev) => [...prev, msg]));
  }

  function handleReact(emoji) {
    watchPartyApi.sendReaction(room.id, emoji);
    const burstId = `${Date.now()}-${Math.random()}`;
    setBursts((prev) => [...prev, { id: burstId, emoji, left: 10 + Math.random() * 80 }]);
    setTimeout(() => setBursts((prev) => prev.filter((b) => b.id !== burstId)), 1800);
    setReactionPickerOpen(false);
  }

  function handleFullscreen() {
    if (!playerWrapRef.current) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else playerWrapRef.current.requestFullscreen?.();
  }

  async function handleCreatePoll(question, options) {
    const poll = await watchPartyApi.createPoll(room.id, question, options);
    setPolls((prev) => [...prev, poll]);
    setPollDraft(null);
  }

  function handleVotePoll(pollId, optionId) {
    watchPartyApi.vote(room.id, pollId, optionId).then((updated) => {
      setPolls((prev) => prev.map((p) => (p.id === pollId ? updated : p)));
    });
  }

  function handleSaveNotes(text) {
    setNotes(text);
    watchPartyApi.saveNotes(room.id, text);
  }

  function requestLeave() {
    setShowSummary(true);
  }

  async function buildSummaryStats() {
    const log = await watchPartyApi.reactions(room.id).catch(() => []);
    const tally = {};
    log.forEach((r) => {
      tally[r.emoji] = (tally[r.emoji] || 0) + 1;
    });
    const favorite = Object.entries(tally).sort((a, b) => b[1] - a[1])[0];
    return {
      partyName: room.title,
      participantCount: participants.length,
      watchTimeSeconds: Math.round((Date.now() - joinedAt) / 1000),
      reactionCount: log.length,
      favoriteMoment: favorite ? { emoji: favorite[0], count: favorite[1] } : null,
      chatHighlights: chat.slice(-3).map((m) => ({
        id: m.id,
        name: m.isMe || m.authorId === 'me' ? 'You' : m.author?.displayName || 'Guest',
        body: m.body,
      })),
    };
  }

  const [summaryStats, setSummaryStats] = useState(null);
  useEffect(() => {
    if (showSummary) buildSummaryStats().then(setSummaryStats);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showSummary]);

  return (
    <div className={styles.wrap}>
      {/* ---------- top nav ---------- */}
      <div className={styles.topNav}>
        <div className={styles.topNavInfo}>
          <div className={styles.partyName}>
            🎬 {room.title}
            {locked && <span className={styles.lockedTag}>🔒</span>}
          </div>
          <div className={styles.nowPlayingLine}>
            {providerInfo?.icon} {nowPlaying.title}
            <span className={styles.providerTag}>{providerInfo?.name || nowPlaying.provider}</span>
          </div>
        </div>
        <div className={styles.topNavActions}>
          <div className={styles.popoverWrap}>
            <button className="btn btn-ghost" onClick={() => setInvitePickerOpen((v) => !v)}>
              ➕ Invite
            </button>
            {invitePickerOpen && (
              <div className={styles.popover}>
                <button className={styles.popoverItem} onClick={handleCopyLink}>
                  🔗 Copy invite link
                </button>
                {friends
                  .filter((f) => !invited.some((u) => u.id === f.id))
                  .map((f) => (
                    <button key={f.id} className={styles.popoverItem} onClick={() => handleInviteFriend(f)}>
                      {f.displayName}
                    </button>
                  ))}
              </div>
            )}
          </div>
          {isHost && (
            <div className={styles.popoverWrap}>
              <button className="btn btn-ghost" onClick={() => setSettingsOpen((v) => !v)}>
                ⚙️ Settings
              </button>
              {settingsOpen && (
                <div className={styles.popover}>
                  <div className={styles.settingsRow}>
                    Visibility <b>{room.visibility || 'public'}</b>
                  </div>
                  <div className={styles.settingsRow}>
                    Max participants <b>{room.maxParticipants || '—'}</b>
                  </div>
                  <button className={styles.popoverItem} onClick={() => onToggleLock()}>
                    {locked ? '🔓 Unlock room' : '🔒 Lock room'}
                  </button>
                  <button
                    className={`${styles.popoverItem} ${styles.popoverItemDanger}`}
                    onClick={handleEndParty}
                  >
                    🔴 End party for everyone
                  </button>
                </div>
              )}
            </div>
          )}
          <button className="btn btn-primary" style={{ background: 'var(--red)' }} onClick={requestLeave}>
            Leave Party
          </button>
        </div>
      </div>

      <div className={styles.body}>
        {/* ---------- left sidebar ---------- */}
        <div className={styles.leftSidebar}>
          <div className={styles.sidebarSection}>
            <div className={styles.sidebarTitle}>Queue</div>
            {isHost && providerInfo?.inputKind === 'url' && (
              <form className={styles.queueForm} onSubmit={handleAddToQueue}>
                <input
                  className={styles.queueInput}
                  value={queueUrl}
                  onChange={(e) => setQueueUrl(e.target.value)}
                  placeholder={`Paste a ${providerInfo.name} link…`}
                />
                <button className="btn btn-ghost" type="submit">
                  +
                </button>
              </form>
            )}
            {queue.length ? (
              queue.map((item) => (
                <div key={item.id} className={styles.queueItem}>
                  <span className={styles.queueItemTitle} title={item.title}>
                    {item.title}
                  </span>
                  {isHost && (
                    <div className={styles.queueItemActions}>
                      <button onClick={() => playFromQueue(item)} title="Play now">
                        ▶
                      </button>
                      <button onClick={() => handleRemoveFromQueue(item.id)} title="Remove">
                        ×
                      </button>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className={styles.sidebarEmpty}>Nothing queued yet</div>
            )}
          </div>

          <div className={styles.sidebarSection}>
            <div className={styles.sidebarTitle}>Suggested Content</div>
            {suggested.map((t) => (
              <div key={t.title} className={styles.suggestedItem} title="Search for it on your provider to queue it">
                {t.title}
              </div>
            ))}
          </div>

          <div className={styles.sidebarSection}>
            <div className={styles.sidebarTitle}>Watch History</div>
            {history.length ? (
              history
                .slice()
                .reverse()
                .map((h, i) => (
                  <div key={i} className={styles.suggestedItem}>
                    {h}
                  </div>
                ))
            ) : (
              <div className={styles.sidebarEmpty}>Nothing played yet</div>
            )}
          </div>
        </div>

        {/* ---------- center player ---------- */}
        <div className={styles.center}>
          <div className={styles.playerWrap} ref={playerWrapRef}>
            {isLocalVideo && nowPlaying.localUrl ? (
              <video
                key={playerKey}
                ref={videoRef}
                className={styles.videoEl}
                src={nowPlaying.localUrl}
                autoPlay
                onPlay={() => setPlaying(true)}
                onPause={() => setPlaying(false)}
                onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
              />
            ) : isEmbed ? (
              <iframe
                key={playerKey}
                className={styles.iframeEl}
                src={nowPlaying.videoUrl}
                title={nowPlaying.title}
                allow="autoplay; fullscreen; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <div className={styles.playerPlaceholder}>
                <div style={{ fontSize: 40 }}>{providerInfo?.icon || '🎬'}</div>
                <div>Waiting on the host's video…</div>
              </div>
            )}

            {bursts.map((b) => (
              <span key={b.id} className={styles.burst} style={{ left: `${b.left}%` }}>
                {b.emoji}
              </span>
            ))}
          </div>

          {/* ---------- bottom controls ---------- */}
          <div className={styles.controls}>
            {isLocalVideo && (
              <>
                <button className={styles.ctrlBtn} onClick={handleTogglePlay} aria-label="Play/pause">
                  {playing ? '⏸' : '▶'}
                </button>
                <input
                  className={styles.seekBar}
                  type="range"
                  min={0}
                  max={duration || 0}
                  value={currentTime}
                  onChange={handleSeek}
                />
                <span className={styles.timeLabel}>
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              </>
            )}

            <span className={`${styles.syncStatus} ${syncing ? styles.syncing : ''}`}>
              {syncing ? '⏳ Synchronizing…' : '✓ Synced'}
            </span>

            {isHost && (
              <>
                <button className={styles.ctrlBtn} onClick={handleSkip} aria-label="Skip">
                  ⏭
                </button>
                <button className={styles.ctrlBtn} onClick={handleReplay} aria-label="Replay">
                  🔁
                </button>
              </>
            )}

            {room.enableVoice && (
              <button
                className={`${styles.ctrlBtn} ${!micOn ? styles.ctrlOff : ''}`}
                onClick={() => setMicOn((v) => !v)}
                aria-label="Toggle microphone"
              >
                {micOn ? '🎙️' : '🔇'}
              </button>
            )}
            {room.enableVideo && (
              <button
                className={`${styles.ctrlBtn} ${!camOn ? styles.ctrlOff : ''}`}
                onClick={() => setCamOn((v) => !v)}
                aria-label="Toggle camera"
              >
                {camOn ? '📹' : '📷'}
              </button>
            )}
            <button
              className={`${styles.ctrlBtn} ${screenSharing ? styles.ctrlActive : ''}`}
              onClick={() => setScreenSharing((v) => !v)}
              aria-label="Toggle screen share"
            >
              🖥️
            </button>
            <button
              className={`${styles.ctrlBtn} ${handRaised ? styles.ctrlActive : ''}`}
              onClick={() => setHandRaised((v) => !v)}
              aria-label="Raise hand"
            >
              ✋
            </button>

            <div className={styles.popoverWrap}>
              <button className={styles.ctrlBtn} onClick={() => setReactionPickerOpen((v) => !v)} aria-label="Reactions">
                😀
              </button>
              {reactionPickerOpen && (
                <div className={`${styles.popover} ${styles.reactionPopover}`}>
                  {QUICK_REACTIONS.map((e) => (
                    <button key={e} className={styles.reactionBtn} onClick={() => handleReact(e)}>
                      {e}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {room.enableChat && (
              <button
                className={`${styles.ctrlBtn} ${rightTab === 'chat' ? styles.ctrlActive : ''}`}
                onClick={() => setRightTab((t) => (t === 'chat' ? 'participants' : 'chat'))}
                aria-label="Toggle chat"
              >
                💬
              </button>
            )}
            <button className={styles.ctrlBtn} onClick={handleFullscreen} aria-label="Fullscreen">
              ⛶
            </button>
          </div>
        </div>

        {/* ---------- right sidebar ---------- */}
        <div className={styles.rightSidebar}>
          <div className={styles.rightTabs}>
            {['participants', 'chat', 'polls', 'notes'].map((t) => (
              <button
                key={t}
                className={`${styles.rightTab} ${rightTab === t ? styles.rightTabActive : ''}`}
                onClick={() => setRightTab(t)}
              >
                {t === 'participants' ? `👥 ${participants.length}` : t === 'chat' ? '💬' : t === 'polls' ? '📊' : '📝'}
              </button>
            ))}
          </div>

          {rightTab === 'participants' && (
            <div className={styles.participantList}>
              {participants.map((p) => (
                <div key={p.userId} className={styles.participantRow}>
                  <SpeakingRing initial={p.avatarInitial} active={p.speaking} muted={!p.micOn} size={36} />
                  <div className={styles.participantBody}>
                    <div className={styles.participantName}>
                      {p.isMe ? 'You' : p.displayName}
                      {p.isHost && <span className={styles.hostBadge}>Host</span>}
                      {p.handRaised && ' ✋'}
                    </div>
                    <div className={styles.participantStatus}>
                      <span className={styles.onlineDot} /> Online
                      {p.camOn && ' · 📹'}
                    </div>
                  </div>
                  <span className={styles.micIcon}>{p.micOn ? '🎙️' : '🔇'}</span>
                </div>
              ))}
            </div>
          )}

          {rightTab === 'chat' && (
            <div className={styles.chatPanel}>
              <div className={styles.chatScroll}>
                {chat.length ? (
                  chat.map((m) => (
                    <div key={m.id} className={styles.chatLine}>
                      <b>{m.authorId === 'me' ? 'You' : m.author?.displayName || 'Guest'}:</b> {m.body}
                    </div>
                  ))
                ) : (
                  <div className={styles.sidebarEmpty}>Say something 👋</div>
                )}
              </div>
              {room.enableChat ? (
                <MessageComposer onSend={handleSendChat} placeholder="Chat with the party…" />
              ) : (
                <div className={styles.sidebarEmpty}>Live chat is off for this party</div>
              )}
            </div>
          )}

          {rightTab === 'polls' && (
            <div className={styles.pollsPanel}>
              {polls.map((p) => (
                <PollCard key={p.id} poll={p} onVote={handleVotePoll} />
              ))}
              {isHost &&
                (pollDraft ? (
                  <PollDraftForm onCancel={() => setPollDraft(null)} onCreate={handleCreatePoll} />
                ) : (
                  <button className="btn btn-ghost" style={{ width: '100%' }} onClick={() => setPollDraft(true)}>
                    + New Poll
                  </button>
                ))}
              {!polls.length && !isHost && <div className={styles.sidebarEmpty}>No polls yet</div>}
            </div>
          )}

          {rightTab === 'notes' && (
            <div className={styles.notesPanel}>
              <textarea
                className={styles.notesArea}
                value={notes}
                onChange={(e) => handleSaveNotes(e.target.value)}
                placeholder="Shared watch notes — timestamps, thoughts, spoilers…"
              />
            </div>
          )}
        </div>
      </div>

      {showSummary && summaryStats && (
        <WatchPartySummary
          stats={summaryStats}
          onContinue={() => setShowSummary(false)}
          onScheduleAnother={() => {
            setShowSummary(false);
            setShowScheduleAnother(true);
          }}
          onDone={onLeave}
        />
      )}

      {showScheduleAnother && (
        <WatchPartyCreateModal onClose={() => setShowScheduleAnother(false)} />
      )}
    </div>
  );
}

function PollDraftForm({ onCancel, onCreate }) {
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);

  function updateOption(i, value) {
    setOptions((prev) => prev.map((o, idx) => (idx === i ? value : o)));
  }

  function submit(e) {
    e.preventDefault();
    const cleanOptions = options.map((o) => o.trim()).filter(Boolean);
    if (!question.trim() || cleanOptions.length < 2) return;
    onCreate(question.trim(), cleanOptions);
  }

  return (
    <form onSubmit={submit} className={styles.pollDraft}>
      <input
        className={styles.queueInput}
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Ask the party…"
        autoFocus
      />
      {options.map((o, i) => (
        <input
          key={i}
          className={styles.queueInput}
          value={o}
          onChange={(e) => updateOption(i, e.target.value)}
          placeholder={`Option ${i + 1}`}
        />
      ))}
      <div style={{ display: 'flex', gap: 8 }}>
        <button
          type="button"
          className="btn btn-ghost"
          style={{ fontSize: 11 }}
          onClick={() => setOptions((prev) => [...prev, ''])}
        >
          + Option
        </button>
        <button type="button" className="btn btn-ghost" style={{ fontSize: 11 }} onClick={onCancel}>
          Cancel
        </button>
        <button className="btn btn-primary" style={{ fontSize: 11, flex: 1 }}>
          Post
        </button>
      </div>
    </form>
  );
}
