export default function EventCard({ event }) {
  return (
    <div
      style={{
        display: 'flex',
        gap: 16,
        alignItems: 'center',
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: 12,
        padding: 16,
        marginBottom: 10,
      }}
    >
      <div
        style={{
          textAlign: 'center',
          minWidth: 54,
          padding: '8px 4px',
          background: 'var(--bg-raised)',
          borderRadius: 10,
          border: '1px solid var(--border)',
        }}
      >
        <div style={{ fontSize: 10, color: 'var(--text-dim)' }}>{event.month}</div>
        <div style={{ fontFamily: 'Archivo Black', fontSize: 20 }}>{event.day}</div>
      </div>
      <div style={{ flex: 1 }}>
        <h3 style={{ fontSize: 15, marginBottom: 3 }}>{event.title}</h3>
        <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>{event.meta}</div>
      </div>
      <div style={{ fontSize: 11.5, color: 'var(--gold)', fontWeight: 700 }}>{event.countdown}</div>
    </div>
  );
}
