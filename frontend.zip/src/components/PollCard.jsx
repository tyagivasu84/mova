import styles from './PollCard.module.css';

export default function PollCard({ poll, onVote }) {
  const totalVotes = poll.options.reduce((sum, o) => sum + o.votes.length, 0);

  return (
    <div className={styles.card}>
      <div className={styles.question}>{poll.question}</div>
      {poll.options.map((o) => {
        const pct = totalVotes ? Math.round((o.votes.length / totalVotes) * 100) : 0;
        const mine = o.votes.includes('me');
        return (
          <button key={o.id} className={styles.option} onClick={() => onVote(poll.id, o.id)}>
            <div className={styles.optionBar} style={{ width: `${pct}%` }} />
            <span className={styles.optionText}>
              {o.text} {mine && '✓'}
            </span>
            <span className={styles.optionPct}>{pct}%</span>
          </button>
        );
      })}
      <div className={styles.votesCount}>{totalVotes} votes</div>
    </div>
  );
}
