import { useEffect, useRef, useState } from 'react';
import { verificationApi } from '../api/verification';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import styles from './VerifyModal.module.css';

// Simulated pose-match selfie flow — no camera permission is ever
// requested, this is a fully mocked animation standing in for the real
// capture/match step until a backend exists.
export default function VerifyModal({ onClose, onVerified }) {
  const [step, setStep] = useState('intro'); // intro -> posing -> matching -> done
  const [progress, setProgress] = useState(0);
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  useEffect(() => {
    if (step !== 'matching') return;
    setProgress(0);
    const id = setInterval(() => {
      setProgress((p) => Math.min(p + 4, 100));
    }, 60);
    return () => clearInterval(id);
  }, [step]);

  useEffect(() => {
    if (step === 'matching' && progress >= 100) {
      verificationApi.submit().then(() => setStep('done'));
    }
  }, [step, progress]);

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>

        {step === 'intro' && (
          <>
            <div className={styles.emoji}>🪪</div>
            <h3>Get verified</h3>
            <p>Match a simple pose so people know it's really you. No photo is stored.</p>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => setStep('posing')}>
              Start verification
            </button>
          </>
        )}

        {step === 'posing' && (
          <>
            <div className={styles.poseRing}>
              <div className={styles.poseFace}>🙂</div>
            </div>
            <h3>Match the pose</h3>
            <p>Tilt your head slightly and hold still for a moment.</p>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => setStep('matching')}>
              I'm holding the pose
            </button>
          </>
        )}

        {step === 'matching' && (
          <>
            <div className={styles.poseRing}>
              <div className={styles.poseFace}>🙂</div>
            </div>
            <h3>Matching…</h3>
            <p>Hold still — verifying now.</p>
            <div className={styles.progressTrack}>
              <div className={styles.progressFill} style={{ width: `${progress}%` }} />
            </div>
          </>
        )}

        {step === 'done' && (
          <>
            <div className={styles.emoji}>✅</div>
            <h3>You're verified</h3>
            <p>Your badge now appears next to your name.</p>
            <button
              className="btn btn-primary"
              style={{ width: '100%' }}
              onClick={() => {
                onVerified?.();
                onClose();
              }}
            >
              Done
            </button>
          </>
        )}
      </div>
    </div>
  );
}
