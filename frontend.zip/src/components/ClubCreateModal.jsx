import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { clubsApi, CLUB_CATEGORIES } from '../api/clubs';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import styles from './ClubCreateModal.module.css';

// One straightforward form, not a multi-step wizard — name, description,
// category, and privacy is everything the mock club model actually needs.
export default function ClubCreateModal({ initialCategory, onClose }) {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState(initialCategory || CLUB_CATEGORIES[0]);
  const [isPrivate, setIsPrivate] = useState(false);
  const [busy, setBusy] = useState(false);
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      const club = await clubsApi.create({ name, description, category, private: isPrivate });
      showToast(`${club.name} created 🎉`);
      onClose();
      navigate(`/clubs/${club.id}`);
    } catch (err) {
      showToast(err.message || 'Could not create club');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>Create your Club</h3>

        <form onSubmit={handleSubmit}>
          <label className={styles.label}>Club name</label>
          <input
            className={styles.input}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Midnight Movie Club"
            autoFocus
            required
          />

          <label className={styles.label}>Description</label>
          <textarea
            className={styles.input}
            style={{ resize: 'vertical' }}
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What's this club about?"
          />

          <label className={styles.label}>Category</label>
          <select className={styles.input} value={category} onChange={(e) => setCategory(e.target.value)}>
            {CLUB_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4, cursor: 'pointer' }}>
            <input type="checkbox" checked={isPrivate} onChange={(e) => setIsPrivate(e.target.checked)} />
            <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>
              Private club (invite link required to join)
            </span>
          </label>

          <button className="btn btn-primary" style={{ width: '100%', marginTop: 18 }} disabled={busy}>
            {busy ? 'Creating…' : 'Create Club'}
          </button>
        </form>
      </div>
    </div>
  );
}
