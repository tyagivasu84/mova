import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import { roomsApi, VIBES } from '../api/rooms';
import styles from './HostRoomModal.module.css';

const TITLE_EXAMPLES = [
  'Marigold House finale',
  'Minecraft base build',
  'vent about my day',
  'study for finals',
  'debate club',
];

// One Room primitive — no fixed watch/game category. The host just types
// whatever the room is about; everything else (vibe, privacy) is the same
// regardless of topic. Friends are invited from inside the room once it's
// live (LiveRoom's ➕ control), not up front here.
export default function HostRoomModal({ onClose, initialTitle = '', initialTag = '', autoOpenGame = null }) {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [titlePlaceholder] = useState(
    () => TITLE_EXAMPLES[Math.floor(Math.random() * TITLE_EXAMPLES.length)]
  );
  const [title, setTitle] = useState(initialTitle);
  const [tag, setTag] = useState(initialTag);
  const [vibe, setVibe] = useState(VIBES[0]);
  const [isPrivate, setIsPrivate] = useState(false);
  const [busy, setBusy] = useState(false);
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!title.trim()) return;
    setBusy(true);
    try {
      const room = await roomsApi.create({
        title: title.trim(),
        tag: tag.trim(),
        vibe,
        mode: 'instant',
        private: isPrivate,
      });
      showToast('Room created — joining now');
      onClose();
      navigate(`/room/${room.id}`, autoOpenGame ? { state: { autoOpenGame } } : undefined);
    } catch (err) {
      showToast(err.message || 'Could not host room');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>Host a room</h3>

        <form onSubmit={handleSubmit}>
          <label className={styles.label}>What's this room about?</label>
          <input
            className={styles.input}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={titlePlaceholder}
            autoFocus
            required
          />

          <label className={styles.label}>Tag (optional)</label>
          <input
            className={styles.input}
            value={tag}
            onChange={(e) => setTag(e.target.value)}
            placeholder="Minecraft, Movie Night, Study Group…"
          />

          <label className={styles.label}>Vibe</label>
          <select className={styles.input} value={vibe} onChange={(e) => setVibe(e.target.value)}>
            {VIBES.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>

          <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={isPrivate}
              onChange={(e) => setIsPrivate(e.target.checked)}
            />
            <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>
              Private room (people must ask to join)
            </span>
          </label>

          <button className="btn btn-primary" style={{ width: '100%', marginTop: 18 }} disabled={busy}>
            {busy ? 'Starting…' : 'Start room'}
          </button>
        </form>
      </div>
    </div>
  );
}
