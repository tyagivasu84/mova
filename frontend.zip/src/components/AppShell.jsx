import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAppState } from '../context/AppStateContext';
import { useSocial } from '../context/SocialContext';
import { useCall } from '../context/CallContext';
import { useToast } from '../context/ToastContext';
import { notifApi } from '../api/notifications';
import { messagesApi } from '../api/messages';
import { roomsApi } from '../api/rooms';
import { settingsApi } from '../api/settings';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { clickableDivProps } from '../utils/a11y';
import { NAV } from '../config/nav';
import BottomNav from './BottomNav';
import styles from './AppShell.module.css';

export default function AppShell({ children }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const { points } = useAppState();
  const { acceptRequest, declineRequest } = useSocial();
  const { activeRoom } = useCall();
  const { showToast } = useToast();

  const [bellOpen, setBellOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifs, setNotifs] = useState([]);
  const [messageUnread, setMessageUnread] = useState(0);
  const bellRef = useRef(null);
  const menuRef = useRef(null);
  const contentRef = useRef(null);

  const initial = (user?.displayName || 'U').charAt(0).toUpperCase();
  const unreadCount = notifs.filter((n) => !n.read).length;

  useEffect(() => {
    notifApi.list().then(setNotifs).catch(() => {});
  }, []);

  // Apply persisted accessibility settings at boot — AppShell is always
  // mounted for the authenticated app, so this covers every route, not
  // just whichever page the user happens to load first.
  useEffect(() => {
    document.body.classList.toggle('reduce-motion', Boolean(settingsApi.get().reduceMotion));
  }, []);

  // .content is its own scroll container (sidebar/topbar stay fixed), so
  // React Router doesn't reset it on navigation the way window scroll
  // would — do it ourselves or every new page opens wherever the last
  // page happened to be scrolled to.
  useEffect(() => {
    contentRef.current?.scrollTo(0, 0);
  }, [location.pathname]);

  // Re-check unread DMs on every navigation — cheap localStorage read, and
  // it's how the badge clears after visiting /messages (which marks the
  // opened conversation read) without needing a shared messages context.
  useEffect(() => {
    messagesApi.unreadCount().then(setMessageUnread).catch(() => {});
  }, [location.pathname]);

  async function handleMarkAllRead() {
    setNotifs(await notifApi.markAllRead());
  }

  async function handleAcceptFriendNotif(n) {
    try {
      await acceptRequest(n.meta.requestId);
      setNotifs(await notifApi.markRead(n.id));
      showToast('Friend request accepted');
    } catch (err) {
      showToast(err.message || 'Could not accept request');
    }
  }

  async function handleDeclineFriendNotif(n) {
    await declineRequest(n.meta.requestId);
    setNotifs(await notifApi.markRead(n.id));
  }

  async function handleAcceptRoomJoinNotif(n) {
    try {
      await roomsApi.approveJoinRequest(n.meta.requestId);
      setNotifs(await notifApi.markRead(n.id));
      showToast('Join request approved');
    } catch (err) {
      showToast(err.message || 'Could not approve request');
    }
  }

  async function handleDeclineRoomJoinNotif(n) {
    try {
      await roomsApi.denyJoinRequest(n.meta.requestId);
      setNotifs(await notifApi.markRead(n.id));
    } catch (err) {
      showToast(err.message || 'Could not decline request');
    }
  }

  useEffect(() => {
    function onClick(e) {
      if (bellRef.current && !bellRef.current.contains(e.target)) setBellOpen(false);
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  useEscapeKey(() => {
    setBellOpen(false);
    setMenuOpen(false);
  });

  async function handleLogout() {
    await logout();
    showToast('Logged out');
  }

  return (
    <div className={styles.app}>
      <nav className={styles.sidebar}>
        <div
          className={`display ${styles.brand}`}
          {...clickableDivProps(() => navigate('/'))}
        >
          CLUB
        </div>
        <div className={styles.navItems}>
          {NAV.map((item, i) =>
            item.divider ? (
              <div key={i} className={styles.navDivider} />
            ) : (
              <button
                key={item.to}
                className={`${styles.navBtn} ${
                  location.pathname === item.to ? styles.navBtnActive : ''
                }`}
                title={item.tip}
                onClick={() => navigate(item.to)}
              >
                <item.icon size={19} strokeWidth={1.8} />
                {item.to === '/messages' && messageUnread > 0 && (
                  <span className={styles.badge}>{messageUnread}</span>
                )}
              </button>
            )
          )}
        </div>
      </nav>

      <div className={styles.main}>
        <header className={styles.topbar}>
          <div className={styles.points}>
            <span className={styles.pointsGold}>★</span> {points.toLocaleString()}
          </div>

          {activeRoom && (
            <button
              className={styles.inRoomPill}
              onClick={() =>
                navigate(activeRoom.type === 'call' ? `/call/${activeRoom.id}` : `/room/${activeRoom.id}`)
              }
            >
              🔴 {activeRoom.title}
            </button>
          )}

          <div className={styles.bellWrap} ref={bellRef}>
            <button
              className={styles.iconBtn}
              onClick={() => setBellOpen((v) => !v)}
              aria-label="Notifications"
            >
              🔔
              {unreadCount > 0 && <span className={styles.badge}>{unreadCount}</span>}
            </button>
            {bellOpen && (
              <div className={styles.dropdown}>
                {notifs.length > 0 && (
                  <div className={styles.dropdownHeader}>
                    <span>Notifications</span>
                    <button className={styles.markAllBtn} onClick={handleMarkAllRead}>
                      Mark all read
                    </button>
                  </div>
                )}
                {notifs.length ? (
                  notifs.map((n) => (
                    <div
                      key={n.id}
                      className={`${styles.notifItem} ${n.read ? '' : styles.notifUnread}`}
                    >
                      <div className={styles.notifIcon}>{n.icon || '🔔'}</div>
                      <div className={styles.notifBody}>
                        {n.text}
                        <div className={styles.notifTime}>{n.time}</div>
                        {n.type === 'friend_request' && n.meta?.requestId && (
                          <div className={styles.notifActions}>
                            <button
                              className="btn btn-primary"
                              style={{ fontSize: 11, padding: '5px 10px' }}
                              onClick={() => handleAcceptFriendNotif(n)}
                            >
                              Accept
                            </button>
                            <button
                              className="btn btn-ghost"
                              style={{ fontSize: 11, padding: '5px 10px' }}
                              onClick={() => handleDeclineFriendNotif(n)}
                            >
                              Decline
                            </button>
                          </div>
                        )}
                        {n.type === 'room_join_request' && n.meta?.requestId && (
                          <div className={styles.notifActions}>
                            <button
                              className="btn btn-primary"
                              style={{ fontSize: 11, padding: '5px 10px' }}
                              onClick={() => handleAcceptRoomJoinNotif(n)}
                            >
                              Approve
                            </button>
                            <button
                              className="btn btn-ghost"
                              style={{ fontSize: 11, padding: '5px 10px' }}
                              onClick={() => handleDeclineRoomJoinNotif(n)}
                            >
                              Decline
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className={styles.notifEmpty}>You're all caught up</div>
                )}
              </div>
            )}
          </div>

          <div className={styles.avatarMenuWrap} ref={menuRef}>
            <button
              className="avatar-sm"
              onClick={() => setMenuOpen((v) => !v)}
              style={{ cursor: 'pointer', border: 'none' }}
            >
              {initial}
            </button>
            {menuOpen && (
              <div className={styles.avatarDropdown}>
                <button className={styles.avatarMenuItem} onClick={() => navigate('/profile')}>
                  Profile
                </button>
                <button className={styles.avatarMenuItem} onClick={() => navigate('/settings')}>
                  Settings
                </button>
                <button
                  className={`${styles.avatarMenuItem} ${styles.danger}`}
                  onClick={handleLogout}
                >
                  Log out
                </button>
              </div>
            )}
          </div>
        </header>

        <main className={styles.content} ref={contentRef}>{children}</main>
      </div>

      <BottomNav />
    </div>
  );
}
