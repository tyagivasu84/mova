import { useState } from 'react';
import styles from './MessageComposer.module.css';

export default function MessageComposer({ onSend, placeholder }) {
  const [value, setValue] = useState('');

  function submit(e) {
    e.preventDefault();
    if (!value.trim()) return;
    onSend(value.trim());
    setValue('');
  }

  return (
    <form className={styles.composer} onSubmit={submit}>
      <input
        className={styles.input}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={placeholder || 'Message… wrap text in ||spoiler|| to blur it'}
      />
      <button className="btn btn-primary" type="submit">
        Send
      </button>
    </form>
  );
}
