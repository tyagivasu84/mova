import { useEffect, useRef, useState } from 'react';
import { giftsApi } from '../api/gifts';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import { useEscapeKey } from '../hooks/useEscapeKey';
import { useFocusTrap } from '../hooks/useFocusTrap';
import { ageProfileApi } from '../api/ageProfile';
import styles from './GiftModal.module.css';

// Gifting spends real points — routed through the same addPoints() call
// the rewards system uses, just with a negative amount, so the balance
// shown in the topbar/Profile/Rewards stays a single source of truth.
export default function GiftModal({ toName, onClose, onSent }) {
  const { points, addPoints } = useAppState();
  const { showToast } = useToast();
  const [catalog, setCatalog] = useState([]);
  const [sendingId, setSendingId] = useState(null);
  const blocked = ageProfileApi.get() === 'teen';
  const cardRef = useRef(null);

  useEscapeKey(onClose);
  useFocusTrap(cardRef);

  useEffect(() => {
    giftsApi.catalog().then(setCatalog).catch(() => {});
  }, []);

  async function handleSend(gift) {
    if (blocked) {
      showToast('Gifting is limited for age-appropriate accounts');
      return;
    }
    if (points < gift.price) {
      showToast('Not enough points');
      return;
    }
    setSendingId(gift.id);
    try {
      await addPoints(-gift.price);
      showToast(`Sent ${gift.icon} ${gift.name} to ${toName}`);
      onSent?.(gift);
      onClose();
    } catch (err) {
      showToast(err.message || 'Could not send gift');
    } finally {
      setSendingId(null);
    }
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.card}
        onClick={(e) => e.stopPropagation()}
        ref={cardRef}
        role="dialog"
        aria-modal="true"
      >
        <button className={styles.close} onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>Send a gift to {toName}</h3>

        {blocked && (
          <div className={styles.notice}>
            Gifting is limited for age-appropriate accounts (13–17).
          </div>
        )}

        <div className={styles.grid}>
          {catalog.map((g) => (
            <button
              key={g.id}
              className={styles.giftBtn}
              disabled={blocked || points < g.price || sendingId === g.id}
              onClick={() => handleSend(g)}
            >
              <div className={styles.giftIcon}>{g.icon}</div>
              <div className={styles.giftName}>{g.name}</div>
              <div className={styles.giftPrice}>★ {g.price}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
