export default function VerifiedBadge({ size = 14, style }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      style={{ flexShrink: 0, ...style }}
      role="img"
      aria-label="Verified"
    >
      <title>Verified</title>
      <path
        d="M12 2l2.4 2.1 3.1-.5 1 3 2.9 1.4-.9 3.1.9 3.1-2.9 1.4-1 3-3.1-.5L12 22l-2.4-2.1-3.1.5-1-3-2.9-1.4.9-3.1-.9-3.1 2.9-1.4 1-3 3.1.5z"
        fill="#5865f2"
      />
      <path
        d="M8.5 12.3l2.3 2.3 4.7-4.9"
        stroke="#fff"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}
