import { useState } from 'react';
import styles from './MessageBubble.module.css';

const QUICK_REACTIONS = ['❤️', '😂', '😮', '👍'];

function Spoiler({ text }) {
  const [revealed, setRevealed] = useState(false);
  return (
    <span
      className={`${styles.spoiler} ${revealed ? styles.spoilerRevealed : ''}`}
      onClick={(e) => {
        e.stopPropagation();
        setRevealed(true);
      }}
    >
      {text}
    </span>
  );
}

// Splits `body` on ||spoiler|| segments and renders each as a
// blur-until-tap span, leaving everything else as plain text.
function renderBody(body) {
  const parts = body.split(/(\|\|.+?\|\|)/g);
  return parts.map((part, i) =>
    part.startsWith('||') && part.endsWith('||') ? (
      <Spoiler key={i} text={part.slice(2, -2)} />
    ) : (
      <span key={i}>{part}</span>
    )
  );
}

export default function MessageBubble({ message, isMe, onReact, onOpenThread }) {
  const [showPicker, setShowPicker] = useState(false);

  return (
    <div className={`${styles.row} ${isMe ? styles.rowMe : ''}`}>
      {!isMe && (
        <span className="avatar-sm" style={{ width: 28, height: 28, fontSize: 11 }}>
          {message.author?.avatarInitial || '?'}
        </span>
      )}
      <div className={styles.bubbleWrap}>
        {message.type === 'gift' && message.gift ? (
          <div className={styles.giftBubble}>
            <span className={styles.giftIcon}>{message.gift.icon}</span>
            <span className={styles.giftName}>Sent {message.gift.name}</span>
          </div>
        ) : message.type === 'image' && message.image ? (
          <img className={styles.imageBubble} src={message.image} alt="" loading="lazy" />
        ) : (
          <div className={`${styles.bubble} ${isMe ? styles.bubbleMe : ''}`}>
            {renderBody(message.body)}
          </div>
        )}
        <div className={styles.actions}>
          <button onClick={() => setShowPicker((v) => !v)}>😀 React</button>
          <button onClick={() => onOpenThread(message)}>
            💬 {message.replies?.length > 0 ? `${message.replies.length} replies` : 'Reply in thread'}
          </button>
          {showPicker && (
            <div className={styles.picker}>
              {QUICK_REACTIONS.map((e) => (
                <button
                  key={e}
                  onClick={() => {
                    onReact(message.id, e);
                    setShowPicker(false);
                  }}
                >
                  {e}
                </button>
              ))}
            </div>
          )}
        </div>
        {message.reactions?.length > 0 && (
          <div className={styles.reactionsRow}>
            {message.reactions.map((r) => (
              <span
                key={r.emoji}
                className={styles.reactionChip}
                onClick={() => onReact(message.id, r.emoji)}
              >
                {r.emoji} {r.userIds.length}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
