import styles from './SpeakingRing.module.css';

// Shared conic-gradient "speaking" ring primitive used by Live Room and
// Active Call to highlight whoever is currently talking.
export default function SpeakingRing({ initial, active, muted, size = 64, fontSize }) {
  return (
    <div className={`${styles.ring} ${active ? styles.active : ''}`} style={{ width: size, height: size }}>
      <div className={styles.inner} style={{ fontSize: fontSize || size * 0.32 }}>
        {initial}
      </div>
      {muted && <span className={styles.mutedBadge}>🔇</span>}
    </div>
  );
}
