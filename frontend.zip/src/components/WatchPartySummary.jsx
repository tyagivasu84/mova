import styles from './WatchPartySummary.module.css';

function formatDuration(s) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m ${s % 60}s`;
}

// After Party screen — shown when someone leaves a Watch Party, before the
// room actually unmounts. Lets them cancel back in, jump straight into
// scheduling another one, or just leave.
export default function WatchPartySummary({ stats, onContinue, onScheduleAnother, onDone }) {
  return (
    <div className={styles.overlay}>
      <div className={styles.card}>
        <div className={styles.emoji}>🎬</div>
        <h2>That's a wrap!</h2>
        <p className={styles.sub}>{stats.partyName}</p>

        <div className={styles.statGrid}>
          <div className={styles.stat}>
            <div className={styles.statNum}>{stats.participantCount}</div>
            <div className={styles.statLabel}>Participants</div>
          </div>
          <div className={styles.stat}>
            <div className={styles.statNum}>{formatDuration(stats.watchTimeSeconds)}</div>
            <div className={styles.statLabel}>Watch Time</div>
          </div>
          <div className={styles.stat}>
            <div className={styles.statNum}>{stats.reactionCount}</div>
            <div className={styles.statLabel}>Reactions</div>
          </div>
        </div>

        {stats.favoriteMoment && (
          <div className={styles.section}>
            <div className={styles.sectionLabel}>Favorite Moment</div>
            <div className={styles.favoriteMoment}>
              <span className={styles.favoriteEmoji}>{stats.favoriteMoment.emoji}</span>
              reacted {stats.favoriteMoment.count}× by the party
            </div>
          </div>
        )}

        {stats.chatHighlights?.length > 0 && (
          <div className={styles.section}>
            <div className={styles.sectionLabel}>Chat Highlights</div>
            {stats.chatHighlights.map((c) => (
              <div key={c.id} className={styles.chatLine}>
                <b>{c.name}:</b> {c.body}
              </div>
            ))}
          </div>
        )}

        <div className={styles.actions}>
          <button className="btn btn-ghost" onClick={onContinue}>
            ↩ Continue Watching
          </button>
          <button className="btn btn-ghost" onClick={onScheduleAnother}>
            📅 Schedule Another
          </button>
          <button className="btn btn-primary" onClick={onDone}>
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
