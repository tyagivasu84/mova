import { useEffect, useState } from 'react';
import { catalogApi } from '../api/catalog';
import { useAppState } from '../context/AppStateContext';
import { useToast } from '../context/ToastContext';
import styles from './ShopGrid.module.css';

export default function ShopGrid() {
  const { points, shopOwned, redeemShopItem } = useAppState();
  const { showToast } = useToast();
  const [shop, setShop] = useState([]);
  const [busyId, setBusyId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    catalogApi.shop().then(setShop).catch(() => {}).finally(() => setLoading(false));
  }, []);

  async function handleRedeem(item) {
    setBusyId(item.id);
    try {
      await redeemShopItem(item.id);
      showToast(`Redeemed ${item.name} 🎁`);
    } catch (err) {
      showToast(err.message || 'Could not redeem');
    } finally {
      setBusyId(null);
    }
  }

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', padding: 40 }}>
        <div className="spinner" />
      </div>
    );
  }

  if (!shop.length) {
    return (
      <div className="empty-state">
        <div className="emoji">🛍️</div>
        <h3>Shop is empty</h3>
        <p>Check back soon for new items.</p>
      </div>
    );
  }

  return (
    <div className={styles.grid}>
      {shop.map((item) => {
        const owned = shopOwned.includes(item.id);
        const canAfford = points >= item.price;
        return (
          <div key={item.id} className={styles.item}>
            <div className={styles.icon}>{item.icon}</div>
            <h4 className={styles.name}>{item.name}</h4>
            <p className={styles.desc}>{item.desc}</p>
            <div className={styles.price}>★ {item.price.toLocaleString()} pts</div>
            <button
              className={owned ? 'btn btn-ghost' : 'btn btn-primary'}
              style={{ width: '100%', fontSize: 12, padding: 8 }}
              disabled={owned || !canAfford || busyId === item.id}
              onClick={() => handleRedeem(item)}
            >
              {owned ? 'Owned ✓' : canAfford ? 'Redeem' : 'Not enough pts'}
            </button>
          </div>
        );
      })}
    </div>
  );
}
