import { Routes, Route } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import AuthOverlay from './components/AuthOverlay';
import AppShell from './components/AppShell';
import Home from './pages/Home';
import Rooms from './pages/Rooms';
import LiveRoom from './pages/LiveRoom';
import Clubs from './pages/Clubs';
import ClubDetail from './pages/ClubDetail';
import Messages from './pages/Messages';
import ActiveCall from './pages/ActiveCall';
import Friends from './pages/Friends';
import Profile from './pages/Profile';
import Premium from './pages/Premium';
import Settings from './pages/Settings';
import MovieDetail from './pages/MovieDetail';
import NotFound from './pages/NotFound';

export default function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', minHeight: '100vh' }}>
        <div className="spinner" />
      </div>
    );
  }

  // Not signed in -> full-screen auth overlay (matches original behavior).
  if (!user) return <AuthOverlay />;

  // Signed in -> routed app inside the sidebar/topbar shell.
  return (
    <AppShell>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/rooms" element={<Rooms />} />
        <Route path="/room/:id" element={<LiveRoom />} />
        <Route path="/clubs" element={<Clubs />} />
        <Route path="/clubs/:id" element={<ClubDetail />} />
        <Route path="/messages" element={<Messages />} />
        <Route path="/call/:id" element={<ActiveCall />} />
        <Route path="/friends" element={<Friends />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/profile/:userId" element={<Profile />} />
        <Route path="/premium" element={<Premium />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/movie/:name" element={<MovieDetail />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AppShell>
  );
}
