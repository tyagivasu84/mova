'use strict';

/**
 * Seeds a demo account so the frontend has something to log into immediately.
 * Run with: npm run seed
 */
const { connectDatabase, disconnectDatabase } = require('./config/database');
const User = require('./models/User');
const UserState = require('./models/UserState');

async function seed() {
  await connectDatabase();

  const email = 'rosaline@club.local';
  let user = await User.findOne({ email });
  if (!user) {
    user = new User({ email, provider: 'password', displayName: 'Rosaline', username: '@rosaline' });
    await user.setPassword('password123');
    await user.save();
    console.log('[seed] created demo user:', email, '/ password123');
  } else {
    console.log('[seed] demo user already exists:', email);
  }

  let state = await UserState.findOne({ user: user._id });
  if (!state) {
    state = await UserState.create({ user: user._id, points: 2140 });
    console.log('[seed] created demo user state');
  }

  await disconnectDatabase();
  console.log('[seed] done');
}

seed().catch((err) => {
  console.error('[seed] failed:', err);
  process.exit(1);
});
