'use strict';

const mongoose = require('mongoose');
const env = require('./env');

/**
 * Handles the MongoDB connection lifecycle.
 * Kept separate from the express app so it can be reused (e.g. by the seed script).
 */
async function connectDatabase() {
  mongoose.set('strictQuery', true);
  await mongoose.connect(env.mongoUri);
  console.log(`[db] connected to ${env.mongoUri}`);
  return mongoose.connection;
}

async function disconnectDatabase() {
  await mongoose.disconnect();
  console.log('[db] disconnected');
}

module.exports = { connectDatabase, disconnectDatabase };
