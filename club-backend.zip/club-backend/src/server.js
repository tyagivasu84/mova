'use strict';

const createApp = require('./app');
const env = require('./config/env');
const { connectDatabase } = require('./config/database');

async function start() {
  try {
    await connectDatabase();
    const app = createApp();
    app.listen(env.port, () => {
      console.log(`[server] CLUB API listening on http://localhost:${env.port}`);
      console.log(`[server] environment: ${env.nodeEnv}`);
    });
  } catch (err) {
    console.error('[server] failed to start:', err.message);
    process.exit(1);
  }
}

// Graceful shutdown.
process.on('SIGINT', () => process.exit(0));
process.on('SIGTERM', () => process.exit(0));

start();
