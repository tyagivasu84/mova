'use strict';

const express = require('express');
const catalogController = require('../controllers/catalogController');

const router = express.Router();

// Streaming / third-party discovery data (static responses).
router.get('/platforms', catalogController.platforms);
router.get('/titles', catalogController.titles);
router.get('/titles/:name', catalogController.title);
router.get('/trending-apps', catalogController.trendingApps);
router.get('/games', catalogController.games);
router.get('/rooms', catalogController.rooms);
router.get('/rooms/:id', catalogController.room);
router.get('/shop', catalogController.shop);
router.get('/notifications', catalogController.notifications);
router.get('/events', catalogController.events);

module.exports = router;
