'use strict';

const express = require('express');
const authRoutes = require('./authRoutes');
const stateRoutes = require('./stateRoutes');
const catalogRoutes = require('./catalogRoutes');

const router = express.Router();

router.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

router.use('/auth', authRoutes);
router.use('/state', stateRoutes);
router.use('/catalog', catalogRoutes);

module.exports = router;
