'use strict';

const express = require('express');
const stateController = require('../controllers/stateController');
const { requireAuth } = require('../middleware/authMiddleware');

const router = express.Router();

// Every state route requires a logged-in user.
router.use(requireAuth);

router.get('/', stateController.get);
router.put('/', stateController.sync);
router.post('/points', stateController.addPoints);
router.post('/streak/claim', stateController.claimStreak);
router.post('/shop/redeem', stateController.redeemShopItem);

module.exports = router;
