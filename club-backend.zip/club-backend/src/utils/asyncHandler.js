'use strict';

/**
 * Wraps an async express handler so rejected promises are forwarded to next().
 * Removes repetitive try/catch from every controller.
 */
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

module.exports = asyncHandler;
