'use strict';

const jwt = require('jsonwebtoken');
const env = require('../config/env');

/**
 * Thin abstraction over the JWT library. Controllers/services depend on this
 * interface (sign/verify) rather than on jsonwebtoken directly, so the
 * implementation can be swapped without touching callers (DIP).
 */
const tokenService = {
  sign(payload) {
    return jwt.sign(payload, env.jwtSecret, { expiresIn: env.jwtExpiresIn });
  },
  verify(token) {
    return jwt.verify(token, env.jwtSecret);
  },
};

module.exports = tokenService;
