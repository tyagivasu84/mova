'use strict';

const asyncHandler = require('../utils/asyncHandler');
const catalogService = require('../services/catalogService');

const catalogController = {
  platforms: asyncHandler(async (req, res) => {
    res.json({ platforms: catalogService.listPlatforms() });
  }),

  titles: asyncHandler(async (req, res) => {
    const { platform, genre } = req.query;
    res.json({ titles: catalogService.listTitles({ platform, genre }) });
  }),

  title: asyncHandler(async (req, res) => {
    res.json({ title: catalogService.getTitle(req.params.name) });
  }),

  trendingApps: asyncHandler(async (req, res) => {
    res.json({ apps: catalogService.trendingApps() });
  }),

  games: asyncHandler(async (req, res) => {
    res.json({ games: catalogService.listGames() });
  }),

  rooms: asyncHandler(async (req, res) => {
    const { type, platform } = req.query;
    res.json({ rooms: catalogService.listRooms({ type, platform }) });
  }),

  room: asyncHandler(async (req, res) => {
    res.json({ room: catalogService.getRoom(req.params.id) });
  }),

  shop: asyncHandler(async (req, res) => {
    res.json({ items: catalogService.shopItems() });
  }),

  notifications: asyncHandler(async (req, res) => {
    res.json({ notifications: catalogService.notifications() });
  }),

  events: asyncHandler(async (req, res) => {
    res.json({ events: catalogService.events() });
  }),
};

module.exports = catalogController;
