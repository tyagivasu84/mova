'use strict';

const asyncHandler = require('../utils/asyncHandler');
const stateService = require('../services/stateService');
const catalogService = require('../services/catalogService');

const stateController = {
  // GET /api/state -> replaces Firestore.loadCloudState()
  get: asyncHandler(async (req, res) => {
    const state = await stateService.get(req.user.id);
    res.json(state);
  }),

  // PUT /api/state -> replaces Firestore syncCloudState() (merge write)
  sync: asyncHandler(async (req, res) => {
    const state = await stateService.sync(req.user.id, req.body || {});
    res.json(state);
  }),

  // POST /api/state/points  { amount }  -> buyPoints()
  addPoints: asyncHandler(async (req, res) => {
    const state = await stateService.addPoints(req.user.id, Number(req.body.amount));
    res.json(state);
  }),

  // POST /api/state/streak/claim -> claimStreak()
  claimStreak: asyncHandler(async (req, res) => {
    const result = await stateService.claimStreak(req.user.id);
    res.json(result);
  }),

  // POST /api/state/shop/redeem  { itemId } -> buyShopItem()
  redeemShopItem: asyncHandler(async (req, res) => {
    const result = await stateService.redeemShopItem(
      req.user.id,
      req.body.itemId,
      catalogService.shopItems()
    );
    res.json(result);
  }),
};

module.exports = stateController;
