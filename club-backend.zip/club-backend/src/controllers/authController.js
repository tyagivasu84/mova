'use strict';

const asyncHandler = require('../utils/asyncHandler');
const authService = require('../services/authService');

const authController = {
  register: asyncHandler(async (req, res) => {
    const result = await authService.register(req.body);
    res.status(201).json(result);
  }),

  login: asyncHandler(async (req, res) => {
    const result = await authService.login(req.body);
    res.json(result);
  }),

  // Mock of the old Firebase Google popup sign-in.
  google: asyncHandler(async (req, res) => {
    const result = await authService.googleMock(req.body || {});
    res.json(result);
  }),

  me: asyncHandler(async (req, res) => {
    const user = await authService.getById(req.user.id);
    res.json({ user: user.toPublic() });
  }),

  updateProfile: asyncHandler(async (req, res) => {
    const user = await authService.updateProfile(req.user.id, req.body);
    res.json({ user });
  }),

  // Stateless JWT: logout is a client-side token discard. Endpoint provided
  // for symmetry with the frontend's logOut() flow.
  logout: asyncHandler(async (req, res) => {
    res.json({ ok: true });
  }),
};

module.exports = authController;
