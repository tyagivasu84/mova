'use strict';

const User = require('../models/User');

/**
 * Data-access for users. Services depend on these methods, not on Mongoose
 * model directly, keeping persistence details in one place.
 */
const userRepository = {
  findById(id) {
    return User.findById(id);
  },
  findByEmail(email) {
    return User.findOne({ email: String(email).toLowerCase().trim() });
  },
  create(data) {
    return User.create(data);
  },
  save(userDoc) {
    return userDoc.save();
  },
};

module.exports = userRepository;
