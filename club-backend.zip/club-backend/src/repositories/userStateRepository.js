'use strict';

const UserState = require('../models/UserState');

const userStateRepository = {
  findByUserId(userId) {
    return UserState.findOne({ user: userId });
  },

  /** Get existing state or create a fresh default one for the user. */
  async findOrCreateByUserId(userId) {
    let state = await UserState.findOne({ user: userId });
    if (!state) {
      state = await UserState.create({ user: userId });
    }
    return state;
  },

  /** Merge-update (mirrors the frontend's Firestore `set(..., {merge:true})`). */
  async upsertByUserId(userId, patch) {
    const state = await this.findOrCreateByUserId(userId);
    if (patch.points !== undefined) state.points = patch.points;
    if (patch.streak !== undefined) state.streak = patch.streak;
    if (patch.shopOwned !== undefined) state.shopOwned = patch.shopOwned;
    await state.save();
    return state;
  },
};

module.exports = userStateRepository;
