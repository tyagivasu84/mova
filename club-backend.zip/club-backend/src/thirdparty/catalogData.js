'use strict';

/**
 * Static third-party catalog data (mock discovery/streaming/games responses).
 *
 * NOTE: The exact real-world contents of this file were not visible in the
 * original screenshots (its file tab was never opened). This is placeholder
 * sample data matching the shape every consumer expects:
 *   - catalogService.js filters TITLES by `platforms` (array) and `genre`
 *   - catalogService.js filters ROOMS by `type` and `platform`, looks up by `id`
 *   - catalogService.js looks up TITLES by `title` (case-insensitive)
 *   - stateService.js redeemShopItem() matches SHOP_ITEMS by `id` and reads `price`
 * Replace with your real catalog whenever you have it.
 */

const STREAMING_PLATFORMS = [
  { id: 'netflix', name: 'Netflix' },
  { id: 'prime', name: 'Prime Video' },
  { id: 'disney', name: 'Disney+' },
  { id: 'hbo', name: 'HBO Max' },
];

const TITLES = [
  { title: 'Nebula Drift', genre: 'Sci-Fi', platforms: ['netflix', 'prime'] },
  { title: 'Quiet Harbor', genre: 'Drama', platforms: ['hbo'] },
  { title: 'Neon Circuit', genre: 'Action', platforms: ['netflix', 'disney'] },
  { title: 'The Long Orchard', genre: 'Drama', platforms: ['prime'] },
  { title: 'Static Kingdom', genre: 'Sci-Fi', platforms: ['hbo', 'netflix'] },
];

const TRENDING_APPS = [
  { id: 'app-1', name: 'Nebula Drift', category: 'Streaming' },
  { id: 'app-2', name: 'Neon Circuit', category: 'Streaming' },
  { id: 'app-3', name: 'Static Kingdom', category: 'Streaming' },
];

const GAMES = [
  { id: 'game-1', name: 'Pixel Sprint', platform: 'mobile' },
  { id: 'game-2', name: 'Orbit Runner', platform: 'console' },
  { id: 'game-3', name: 'Tidepool', platform: 'pc' },
];

const ROOMS = [
  { id: 'room-1', type: 'movie', platform: 'netflix', name: 'Nebula Drift Watch Party' },
  { id: 'room-2', type: 'game', platform: 'pc', name: 'Tidepool Co-op' },
  { id: 'room-3', type: 'movie', platform: 'hbo', name: 'Quiet Harbor Night' },
];

const SHOP_ITEMS = [
  { id: 'shop-badge-gold', name: 'Gold Badge', price: 500 },
  { id: 'shop-theme-neon', name: 'Neon Theme', price: 800 },
  { id: 'shop-avatar-frame', name: 'Avatar Frame', price: 300 },
  { id: 'shop-sticker-pack', name: 'Sticker Pack', price: 150 },
];

const NOTIFICATIONS = [
  { id: 'notif-1', message: 'Your streak is about to reset — claim today!', read: false },
  { id: 'notif-2', message: 'New title added: Static Kingdom', read: false },
];

const EVENTS = [
  { id: 'event-1', name: 'Double Points Weekend', startsAt: null, endsAt: null },
  { id: 'event-2', name: 'Nebula Drift Premiere Watch Party', startsAt: null, endsAt: null },
];

module.exports = {
  STREAMING_PLATFORMS,
  TITLES,
  TRENDING_APPS,
  GAMES,
  ROOMS,
  SHOP_ITEMS,
  NOTIFICATIONS,
  EVENTS,
};
