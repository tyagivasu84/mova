'use strict';

const tokenService = require('../utils/tokenService');
const ApiError = require('../utils/ApiError');

/**
 * Requires a valid Bearer JWT. Attaches { id, email } to req.user.
 */
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return next(ApiError.unauthorized('Missing or malformed Authorization header'));
  }

  try {
    const payload = tokenService.verify(token);
    req.user = { id: payload.sub, email: payload.email };
    return next();
  } catch (err) {
    return next(ApiError.unauthorized('Invalid or expired token'));
  }
}

module.exports = { requireAuth };
