'use strict';

const data = require('../thirdparty/catalogData');
const ApiError = require('../utils/ApiError');

/**
 * Read access to the static third-party catalog. Each method returns a fixed
 * (static) response, optionally filtered. Swapping this module for one that
 * calls real provider APIs would require no controller changes (DIP / OCP).
 */
const catalogService = {
  listPlatforms() {
    return data.STREAMING_PLATFORMS;
  },

  listTitles({ platform, genre } = {}) {
    let titles = data.TITLES;
    if (platform) {
      titles = titles.filter((t) => t.platforms.includes(platform));
    }
    if (genre) {
      titles = titles.filter((t) => t.genre.toLowerCase() === genre.toLowerCase());
    }
    return titles;
  },

  getTitle(name) {
    const title = data.TITLES.find(
      (t) => t.title.toLowerCase() === String(name).toLowerCase()
    );
    if (!title) throw ApiError.notFound('Title not found');
    return title;
  },

  trendingApps() {
    return data.TRENDING_APPS;
  },

  listGames() {
    return data.GAMES;
  },

  listRooms({ type, platform } = {}) {
    let rooms = data.ROOMS;
    if (type) rooms = rooms.filter((r) => r.type === type);
    if (platform) rooms = rooms.filter((r) => r.platform === platform);
    return rooms;
  },

  getRoom(id) {
    const room = data.ROOMS.find((r) => r.id === id);
    if (!room) throw ApiError.notFound('Room not found');
    return room;
  },

  shopItems() {
    return data.SHOP_ITEMS;
  },

  notifications() {
    return data.NOTIFICATIONS;
  },

  events() {
    return data.EVENTS;
  },
};

module.exports = catalogService;
