'use strict';

const userStateRepository = require('../repositories/userStateRepository');
const ApiError = require('../utils/ApiError');

// Day 1..7 rewards; day 7 is the big weekly bonus. Mirrors the frontend.
const STREAK_REWARDS = [50, 75, 100, 125, 150, 200, 400];

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function daysBetween(a, b) {
  return Math.round((new Date(b) - new Date(a)) / 86400000);
}

/**
 * All server-side state logic (the source of truth that used to live in the
 * browser + Firestore). Keeping the streak/points rules here means the client
 * can't be trusted to award itself points.
 */
const stateService = {
  async get(userId) {
    const state = await userStateRepository.findOrCreateByUserId(userId);
    return state.toClientShape();
  },

  /** Merge-sync from client (points/streak/shopOwned), like the old Firestore sync. */
  async sync(userId, patch) {
    const clean = {};
    if (typeof patch.points === 'number') clean.points = patch.points;
    if (patch.streak && typeof patch.streak === 'object') clean.streak = patch.streak;
    if (Array.isArray(patch.shopOwned)) clean.shopOwned = patch.shopOwned;
    const state = await userStateRepository.upsertByUserId(userId, clean);
    return state.toClientShape();
  },

  /** Add purchased points to the balance. */
  async addPoints(userId, amount) {
    if (typeof amount !== 'number' || amount <= 0) {
      throw ApiError.badRequest('amount must be a positive number');
    }
    const state = await userStateRepository.findOrCreateByUserId(userId);
    state.points += amount;
    await state.save();
    return state.toClientShape();
  },

  /**
   * Claim the daily streak reward. Enforces the same rules the frontend used:
   * one claim per day, streak resets to 1 if a day was missed.
   */
  async claimStreak(userId) {
    const state = await userStateRepository.findOrCreateByUserId(userId);
    const today = todayStr();
    const last = state.streak.lastClaimDate;
    const gap = last ? daysBetween(last, today) : Infinity;

    if (gap === 0) {
      throw ApiError.badRequest('Already claimed today — come back tomorrow!');
    }

    const newStreak = gap > 1 || !last ? 1 : state.streak.streak + 1;
    const reward = STREAK_REWARDS[(newStreak - 1) % 7];

    state.streak = { streak: newStreak, lastClaimDate: today };
    state.points += reward;
    await state.save();

    return {
      reward,
      dayOfWeek: ((newStreak - 1) % 7) + 1,
      state: state.toClientShape(),
    };
  },

  /**
   * Redeem a shop item: validates affordability, deducts points, records ownership.
   * `catalog` is injected so this service doesn't depend on the shop data source.
   */
  async redeemShopItem(userId, itemId, catalog) {
    const item = catalog.find((i) => i.id === itemId);
    if (!item) throw ApiError.notFound('Shop item not found');

    const state = await userStateRepository.findOrCreateByUserId(userId);
    if (state.shopOwned.includes(itemId)) {
      throw ApiError.conflict('You already own this item');
    }
    if (state.points < item.price) {
      throw ApiError.badRequest('Not enough points');
    }

    state.points -= item.price;
    state.shopOwned = [...state.shopOwned, itemId];
    await state.save();

    return { item, state: state.toClientShape() };
  },
};

module.exports = stateService;
module.exports.STREAK_REWARDS = STREAK_REWARDS;
