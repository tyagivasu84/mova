'use strict';

const userRepository = require('../repositories/userRepository');
const userStateRepository = require('../repositories/userStateRepository');
const tokenService = require('../utils/tokenService');
const ApiError = require('../utils/ApiError');

/**
 * Authentication business logic. Depends on repositories + tokenService
 * (injected via require here for simplicity; swappable for testing).
 */
const authService = {
  async register({ email, password, displayName, username }) {
    if (!email || !password) {
      throw ApiError.badRequest('Email and password are required');
    }
    if (String(password).length < 6) {
      throw ApiError.badRequest('Password must be at least 6 characters');
    }
    const existing = await userRepository.findByEmail(email);
    if (existing) {
      throw ApiError.conflict('An account with this email already exists');
    }

    const user = new (require('../models/User'))({
      email,
      provider: 'password',
      displayName: displayName || undefined,
      username: username || undefined,
    });
    await user.setPassword(password);
    await userRepository.save(user);

    // Give the user a starting state document (points/streak/shop).
    await userStateRepository.findOrCreateByUserId(user._id);

    return this._issue(user);
  },

  async login({ email, password }) {
    if (!email || !password) {
      throw ApiError.badRequest('Email and password are required');
    }
    const user = await userRepository.findByEmail(email);
    if (!user) throw ApiError.unauthorized('Invalid email or password');

    const ok = await user.verifyPassword(password);
    if (!ok) throw ApiError.unauthorized('Invalid email or password');

    return this._issue(user);
  },

  /**
   * Mock "Sign in with Google". The real frontend used a Google popup; here we
   * accept an email and provision/return a user so the flow works end-to-end
   * without a real OAuth provider.
   */
  async googleMock({ email, displayName }) {
    const targetEmail = email || `guest_${Date.now()}@club.local`;
    let user = await userRepository.findByEmail(targetEmail);
    if (!user) {
      user = await userRepository.create({
        email: targetEmail,
        provider: 'google',
        displayName: displayName || 'Google User',
      });
      await userStateRepository.findOrCreateByUserId(user._id);
    }
    return this._issue(user);
  },

  async getById(id) {
    const user = await userRepository.findById(id);
    if (!user) throw ApiError.notFound('User not found');
    return user;
  },

  async updateProfile(userId, { displayName, username }) {
    const user = await this.getById(userId);
    if (displayName !== undefined) user.displayName = displayName;
    if (username !== undefined) user.username = username;
    await userRepository.save(user);
    return user.toPublic();
  },

  /** Sign a JWT and return the token + public user. */
  _issue(user) {
    const token = tokenService.sign({ sub: user._id.toString(), email: user.email });
    return { token, user: user.toPublic() };
  },
};

module.exports = authService;
