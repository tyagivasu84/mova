'use strict';

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    passwordHash: {
      type: String,
      required: function () {
        // Not required for OAuth-style users (e.g. Google mock).
        return this.provider === 'password';
      },
    },
    provider: {
      type: String,
      enum: ['password', 'google'],
      default: 'password',
    },
    displayName: { type: String, default: 'Rosaline', trim: true },
    username: { type: String, default: '@rosaline', trim: true },
  },
  { timestamps: true }
);

/** Set/replace the password (hashes it). */
userSchema.methods.setPassword = async function setPassword(plain) {
  const salt = await bcrypt.genSalt(10);
  this.passwordHash = await bcrypt.hash(plain, salt);
};

/** Compare a plaintext password against the stored hash. */
userSchema.methods.verifyPassword = function verifyPassword(plain) {
  if (!this.passwordHash) return Promise.resolve(false);
  return bcrypt.compare(plain, this.passwordHash);
};

/** Public representation (never leaks the hash). */
userSchema.methods.toPublic = function toPublic() {
  return {
    id: this._id.toString(),
    email: this.email,
    displayName: this.displayName,
    username: this.username,
    provider: this.provider,
    createdAt: this.createdAt,
  };
};

module.exports = mongoose.model('User', userSchema);
