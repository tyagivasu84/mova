'use strict';

const mongoose = require('mongoose');

/**
 * Per-user app state. Mirrors the shape the frontend previously synced to
 * Firestore's `clubUsers` document: points, login streak, and owned shop items.
 */
const streakSchema = new mongoose.Schema(
  {
    streak: { type: Number, default: 0 },
    lastClaimDate: { type: String, default: null }, // 'YYYY-MM-DD'
  },
  { _id: false }
);

const userStateSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
      index: true,
    },
    points: { type: Number, default: 2140 },
    streak: { type: streakSchema, default: () => ({}) },
    shopOwned: { type: [String], default: [] },
  },
  { timestamps: true }
);

userStateSchema.methods.toClientShape = function toClientShape() {
  return {
    points: this.points,
    streak: { streak: this.streak.streak, lastClaimDate: this.streak.lastClaimDate },
    shopOwned: this.shopOwned,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model('UserState', userStateSchema);
