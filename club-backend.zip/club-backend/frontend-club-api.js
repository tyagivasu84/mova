/**
 * CLUB front-end API client (drop-in).
 *
 * Include AFTER setting window.CLUB_API_BASE, e.g.:
 *   <script>window.CLUB_API_BASE = 'http://localhost:4000/api';</script>
 *   <script src="frontend-club-api.js"></script>
 *
 * Exposes window.clubApi. The JWT is stored in localStorage('club_token').
 *
 * WIRING into the existing index.html (minimal changes):
 *
 *   // replace the body of handleAuthSubmit(...) with:
 *   const email = document.getElementById('authEmail').value;
 *   const password = document.getElementById('authPassword').value;
 *   const isSignup = document.getElementById('authConfirm').style.display !== 'none';
 *   (isSignup ? clubApi.register(email, password) : clubApi.login(email, password))
 *     .then(() => { enterApp(); loadCloudState(); })
 *     .catch(err => showToast(err.message || 'Sign-in failed'));
 *
 *   // handleGoogleAuth():  clubApi.googleSignIn().then(()=>{enterApp();loadCloudState();})
 *
 *   // syncCloudState():  if(!clubApi.isLoggedIn()) return;
 *   //   clubApi.syncState({ points: ptsBalance, streak: loadStreakState(), shopOwned: loadOwnedShopItems() });
 *
 *   // loadCloudState():  if(!clubApi.isLoggedIn()) return;
 *   //   clubApi.getState().then(d => { ...same mapping as the Firestore version... });
 */
(function () {
  'use strict';

  var BASE = window.CLUB_API_BASE || 'http://localhost:4000/api';
  var TOKEN_KEY = 'club_token';

  function getToken() {
    try { return localStorage.getItem(TOKEN_KEY); } catch (e) { return null; }
  }
  function setToken(t) {
    try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch (e) {}
  }

  async function request(path, { method = 'GET', body, auth = false } = {}) {
    var headers = { 'Content-Type': 'application/json' };
    if (auth) {
      var token = getToken();
      if (token) headers.Authorization = 'Bearer ' + token;
    }
    var res = await fetch(BASE + path, {
      method: method,
      headers: headers,
      body: body ? JSON.stringify(body) : undefined,
    });
    var data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      var msg = (data && data.error && data.error.message) || ('Request failed (' + res.status + ')');
      throw new Error(msg);
    }
    return data;
  }

  var clubApi = {
    isLoggedIn: function () { return !!getToken(); },
    logoutLocal: function () { setToken(null); },

    // ---- auth ----
    register: async function (email, password, extra) {
      var d = await request('/auth/register', { method: 'POST', body: Object.assign({ email: email, password: password }, extra || {}) });
      setToken(d.token);
      return d;
    },
    login: async function (email, password) {
      var d = await request('/auth/login', { method: 'POST', body: { email: email, password: password } });
      setToken(d.token);
      return d;
    },
    googleSignIn: async function (email, displayName) {
      var d = await request('/auth/google', { method: 'POST', body: { email: email, displayName: displayName } });
      setToken(d.token);
      return d;
    },
    logout: async function () {
      try { await request('/auth/logout', { method: 'POST', auth: true }); } catch (e) {}
      setToken(null);
    },
    me: function () { return request('/auth/me', { auth: true }); },
    updateProfile: function (patch) { return request('/auth/profile', { method: 'PATCH', body: patch, auth: true }); },

    // ---- state (points / streak / shop) ----
    getState: function () { return request('/state', { auth: true }); },
    syncState: function (patch) { return request('/state', { method: 'PUT', body: patch, auth: true }); },
    addPoints: function (amount) { return request('/state/points', { method: 'POST', body: { amount: amount }, auth: true }); },
    claimStreak: function () { return request('/state/streak/claim', { method: 'POST', auth: true }); },
    redeemShopItem: function (itemId) { return request('/state/shop/redeem', { method: 'POST', body: { itemId: itemId }, auth: true }); },

    // ---- catalog (third-party static data) ----
    platforms: function () { return request('/catalog/platforms'); },
    titles: function (q) { return request('/catalog/titles' + (q ? ('?' + new URLSearchParams(q)) : '')); },
    title: function (name) { return request('/catalog/titles/' + encodeURIComponent(name)); },
    trendingApps: function () { return request('/catalog/trending-apps'); },
    games: function () { return request('/catalog/games'); },
    rooms: function (q) { return request('/catalog/rooms' + (q ? ('?' + new URLSearchParams(q)) : '')); },
    room: function (id) { return request('/catalog/rooms/' + encodeURIComponent(id)); },
    shop: function () { return request('/catalog/shop'); },
    notifications: function () { return request('/catalog/notifications'); },
    events: function () { return request('/catalog/events'); },
  };

  window.clubApi = clubApi;
})();
